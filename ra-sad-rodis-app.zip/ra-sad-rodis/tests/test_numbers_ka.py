"""Spec §2 cardinals (every table row), ordinal words and the 0–1,000,000 sweep."""
import re

import pytest

from app.speech import numbers_ka as nk
from app.speech.normalize_ka import normalize

CARDINALS = [
    ("0", "ნული"),
    ("7", "შვიდი"),
    ("15", "თხუთმეტი"),
    ("20", "ოცი"),
    ("21", "ოცდაერთი"),
    ("30", "ოცდაათი"),
    ("37", "ოცდაჩვიდმეტი"),
    ("40", "ორმოცი"),
    ("55", "ორმოცდათხუთმეტი"),
    ("68", "სამოცდარვა"),
    ("80", "ოთხმოცი"),
    ("99", "ოთხმოცდაცხრამეტი"),
    ("100", "ასი"),
    ("101", "ას ერთი"),
    ("200", "ორასი"),
    ("345", "სამას ორმოცდახუთი"),
    ("800", "რვაასი"),
    ("1000", "ათასი"),
    ("1001", "ათას ერთი"),
    ("1921", "ათას ცხრაას ოცდაერთი"),
    ("2000", "ორი ათასი"),
    ("2024", "ორი ათას ოცდაოთხი"),
    ("15 000", "თხუთმეტი ათასი"),
    ("1 000 000", "მილიონი"),
    ("2 500 000", "ორი მილიონ ხუთასი ათასი"),
    ("3,5", "სამი მთელი ხუთი მეათედი"),
    ("0.25", "ნული მთელი ოცდახუთი მეასედი"),
    ("007", "ნული ნული შვიდი"),
]


@pytest.mark.parametrize("text, expected", CARDINALS)
def test_cardinal_table(text, expected):
    assert normalize(text) == expected


@pytest.mark.parametrize("text, expected", [
    ("1,500", "ათას ხუთასი"),  # comma thousands: ^\d{1,3}(,\d{3})+$
    ("1,5", "ერთი მთელი ხუთი მეათედი"),
    ("1,000,000", "მილიონი"),
    ("2,125", "ორი ათას ას ოცდახუთი"),
    ("0,125", "ნული მთელი ას ოცდახუთი მეათასედი"),
    ("-5", "მინუს ხუთი"),
    ("ტემპერატურა -5", "ტემპერატურა მინუს ხუთი"),
    ("10-5", "ათი – ხუთი"),  # minus between two numbers is a range dash
    ("1 000 000 000", "მილიარდი"),
    ("3 000 000 001", "სამი მილიარდ ერთი"),
])
def test_number_rules(text, expected):
    assert normalize(text) == expected


@pytest.mark.parametrize("n, expected", [
    (1, "პირველი"), (2, "მეორე"), (8, "მერვე"), (9, "მეცხრე"), (20, "მეოცე"), (21, "ოცდამეერთე"),
    (30, "ოცდამეათე"), (40, "მეორმოცე"), (100, "მეასე"), (101, "ას პირველი"), (1000, "მეათასე"),
])
def test_ordinal(n, expected):
    assert nk.ordinal(n) == expected


@pytest.mark.parametrize("words, suffix, expected", [
    ("მეოცე", "ის", "მეოცის"),  # spec §4: ordinal drops ე before a suffix starting with ი
    ("მეოცე", "ში", "მეოცეში"),
    ("პირველი", "ს", "პირველს"),
])
def test_ordinal_suffix(words, suffix, expected):
    assert nk.attach_suffix(words, suffix) == expected


def test_digits_and_huge_numbers():
    assert nk.digits("120") == "ერთი ორი ნული"
    assert normalize("1234567890123") == nk.digits("1234567890123")


def test_sweep_zero_to_one_million_has_no_digits():
    digit = re.compile(r"\d")
    for start in range(0, 1_000_001, 100_000):
        block = "\n".join(nk.cardinal(n) for n in range(start, min(start + 100_000, 1_000_001)))
        assert not digit.search(block), start
        assert block.count("\n") == min(100_000, 1_000_001 - start) - 1
    assert nk.cardinal(999_999) == "ცხრაას ოთხმოცდაცხრამეტი ათას ცხრაას ოთხმოცდაცხრამეტი"


def test_sweep_through_normalizer_sample():
    for n in range(0, 1_000_001, 997):
        spoken = normalize(f"{n}-ში და {n} წელს")
        assert not re.search(r"\d", spoken), n
