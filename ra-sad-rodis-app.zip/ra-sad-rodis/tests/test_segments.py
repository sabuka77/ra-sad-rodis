"""Spec §6: sentence split with offsets, per-sentence normalization, number sub-segments, preview API."""
import json

from app.speech.segments import build_segments, split_sentences


def _sentences(text, dictionary=None):
    return [text[a:b] for a, b in split_sentences(text, dictionary)]


def test_split_keeps_offsets_of_original_text():
    text = "  პირველი წინადადება. მეორე?! მესამე… ბოლო"
    spans = split_sentences(text)
    assert [text[a:b] for a, b in spans] == ["პირველი წინადადება.", "მეორე?!", "მესამე…", "ბოლო"]
    assert spans[0] == (2, 21)


def test_split_skips_abbreviations():
    text = "ეს მოხდა 1921 წ. თებერვალში. ე.წ. ოქროს ხანა XII ს. დაიწყო. ი. ჭავჭავაძე წერდა და ა.შ. ბოლოს."
    assert _sentences(text) == [
        "ეს მოხდა 1921 წ. თებერვალში.",
        "ე.წ. ოქროს ხანა XII ს. დაიწყო.",
        "ი. ჭავჭავაძე წერდა და ა.შ. ბოლოს.",
    ]


def test_split_needs_whitespace_after_dot_and_honours_user_abbreviations():
    assert _sentences("რიცხვი 3.5 არის. ბოლო") == ["რიცხვი 3.5 არის.", "ბოლო"]
    assert _sentences("ნახე გვ. ოცი.") == ["ნახე გვ.", "ოცი."]
    assert _sentences("ნახე გვ. ოცი.", [{"written": "გვ.", "spoken": "გვერდი"}]) == ["ნახე გვ. ოცი."]


def test_segments_number_emphasis():
    text = "ომი 1914 წელს დაიწყო. 5 კაცმა კი 75%-ით მოიგო; დასასრული."
    segs = build_segments(text, sentence_pause_ms=600, number_pause_ms=250)
    assert [(s.spoken, s.is_number) for s in segs] == [
        ("ომი", False),
        ("ათას ცხრაას თოთხმეტ წელს", True),
        ("დაიწყო.", False),
        ("ხუთმა კაცმა", True),
        ("კი", False),
        ("სამოცდათხუთმეტი პროცენტით", True),
        ("მოიგო;", False),
        ("დასასრული.", False),
    ]
    first_end = text.index(".") + 1
    assert all((s.start, s.end) == (0, first_end) for s in segs[:3])
    assert all((s.start, s.end) == (first_end + 1, len(text)) for s in segs[3:])
    assert [s.pause_after_ms for s in segs] == [250, 250, 600, 250, 250, 250, 300, 0]


def test_segments_without_emphasis_one_per_sentence():
    segs = build_segments("1921 წელს. XX ს. ბოლოს.", number_emphasis=False)
    assert [s.spoken for s in segs] == ["ათას ცხრაას ოცდაერთ წელს.", "მეოცე საუკუნე ბოლოს."]
    assert not any(s.is_number for s in segs)


def test_punctuation_after_number_stays_with_it():
    segs = build_segments("ქულა იყო 5.")
    assert [(s.spoken, s.is_number) for s in segs] == [("ქულა იყო", False), ("ხუთი.", True)]


def test_segments_are_json_serializable():
    segs = build_segments("მე-20 საუკუნე.")
    data = json.loads(json.dumps([s.to_dict() for s in segs]))
    assert data == [{"spoken": "მეოცე საუკუნე.", "start": 0, "end": 14, "is_number": True, "pause_after_ms": 0}]


def test_preview_endpoint_applies_settings_dictionary(client):
    put = client.put("/api/settings", json={"pronunciation_dict": [{"written": "ФИФА", "spoken": "ფიფა"}]})
    assert put.status_code == 200
    res = client.get("/api/speech/preview", params={"text": "ФИФА 1904 წელს შეიქმნა. ქ. პარიზში."})
    assert res.status_code == 200
    body = res.json()
    assert body["spoken"] == "ფიფა ათას ცხრაას ოთხ წელს შეიქმნა. ქალაქი პარიზში."
    assert body["segments"][1] == {
        "spoken": "ათას ცხრაას ოთხ წელს", "start": 0, "end": 23, "is_number": True, "pause_after_ms": 250,
    }
    assert body["segments"][-1]["start"] == 24


def test_preview_endpoint_validation(client):
    assert client.get("/api/speech/preview").status_code == 422
    assert client.get("/api/speech/preview", params={"text": ""}).json() == {"spoken": "", "segments": []}
