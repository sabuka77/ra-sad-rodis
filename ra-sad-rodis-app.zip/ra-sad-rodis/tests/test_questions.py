import sqlite3

import pytest

from app.db import content_hash

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 32


@pytest.fixture
def package(client):
    return client.post("/api/packages", json={"title": "პირველი პაკეტი"}).json()


def make(client, package_id, text="რომელ წელს დაარსდა თბილისი?", answer="458 წელს", **extra):
    res = client.post("/api/questions", json={"package_id": package_id, "text": text, "answer": answer, **extra})
    assert res.status_code == 201, res.text
    return res.json()


def ids(client, **params):
    return [q["id"] for q in client.get("/api/questions", params=params).json()]


def test_create_get_and_all_fields_round_trip(client, package):
    sources = [{"text": "ვიკიპედია", "url": "https://ka.wikipedia.org/wiki/თბილისი"}, {"text": "წიგნი", "url": None}]
    created = make(client, package["id"], tour="I ტური", number_label="1", accepted="458", comment="იხ. [1]",
                   sources=sources, author="ნინო", handout_text="რუკა", spoken_override="წასაკითხი ტექსტი")
    assert created["position"] == 1
    assert created["duplicates"] == []
    assert created["content_hash"] == content_hash("რომელ წელს დაარსდა თბილისი?")
    fetched = client.get(f"/api/questions/{created['id']}").json()
    assert fetched["sources"] == sources
    assert fetched["tour"] == "I ტური" and fetched["spoken_override"] == "წასაკითხი ტექსტი"
    assert fetched["played_at"] is None


def test_positions_increase_and_blank_optional_fields_become_null(client, package):
    first = make(client, package["id"], tour="  ")
    second = make(client, package["id"], text="მეორე კითხვა", answer="პასუხი")
    assert (first["position"], second["position"]) == (1, 2)
    assert first["tour"] is None


@pytest.mark.parametrize("body", [
    {"text": "", "answer": "x"}, {"text": "კითხვა", "answer": "   "}, {"text": "კითხვა"},
    {"text": "კითხვა", "answer": "x", "sources": [{"text": "", "url": ""}]},
    {"text": "კითხვა", "answer": "x", "sources": [{"text": "a", "url": "javascript:alert(1)"}]},
    {"text": "კითხვა", "answer": "x", "handout_image": "../quiz.db"},
    {"text": "კითხვა", "answer": "x", "unknown": 1},
])
def test_create_rejects_invalid(client, package, body):
    assert client.post("/api/questions", json={"package_id": package["id"], **body}).status_code == 422
    assert ids(client) == []


def test_source_url_without_scheme_gets_https(client, package):
    q = make(client, package["id"], sources=[{"text": "საიტი", "url": "www.example.ge"}])
    assert q["sources"][0]["url"] == "https://www.example.ge"


def test_unknown_package_or_question_is_404(client, package):
    body = {"package_id": 999, "text": "კ", "answer": "პ"}
    assert client.post("/api/questions", json=body).status_code == 404
    assert client.get("/api/questions/999").status_code == 404
    assert client.put("/api/questions/999", json=body | {"package_id": package["id"]}).status_code == 404
    assert client.delete("/api/questions/999").status_code == 404


def test_update_and_duplicate_warning(client, package):
    q1 = make(client, package["id"], text="ვინ დაწერა „ვეფხისტყაოსანი“?", answer="რუსთაველმა", number_label="7")
    q2 = make(client, package["id"], text="სხვა კითხვა", answer="სხვა")
    # same words, different case, spacing and punctuation → duplicate
    body = {"package_id": package["id"], "text": "ვინ  დაწერა ვეფხისტყაოსანი", "answer": "შოთამ"}
    res = client.put(f"/api/questions/{q2['id']}", json=body)
    assert res.status_code == 200
    saved = res.json()
    assert saved["answer"] == "შოთამ" and saved["content_hash"] == q1["content_hash"]
    assert saved["duplicates"] == [{"id": q1["id"], "package_id": package["id"],
                                    "package_title": "პირველი პაკეტი", "number_label": "7"}]


def test_search_by_question_and_answer_text(client, package):
    other = client.post("/api/packages", json={"title": "მეორე"}).json()
    a = make(client, package["id"], text="ქართული ანბანი", answer="33 ასო")
    b = make(client, package["id"], text="Mount Everest", answer="ჩომოლუნგმა")
    c = make(client, other["id"], text="ანბანის ავტორი", answer="ფარნავაზი")
    assert ids(client, q="ანბან") == [a["id"], c["id"]]
    assert ids(client, q="ჩომოლუნგმა") == [b["id"]]
    assert ids(client, q="everest") == [b["id"]]  # case-insensitive
    assert ids(client, q="ანბან", package_id=other["id"]) == [c["id"]]
    assert ids(client, package_id=package["id"]) == [a["id"], b["id"]]


def test_move_up_and_down(client, package):
    q = [make(client, package["id"], text=f"კითხვა {i}", answer="პ")["id"] for i in range(3)]
    assert client.post(f"/api/questions/{q[2]}/move", json={"direction": "up"}).json() == [q[0], q[2], q[1]]
    assert client.post(f"/api/questions/{q[0]}/move", json={"direction": "down"}).json() == [q[2], q[0], q[1]]
    assert client.post(f"/api/questions/{q[2]}/move", json={"direction": "up"}).json() == [q[2], q[0], q[1]]  # top stays
    assert ids(client, package_id=package["id"]) == [q[2], q[0], q[1]]
    assert client.post(f"/api/questions/{q[0]}/move", json={"direction": "left"}).status_code == 422


def test_moving_to_another_package_appends_at_its_end(client, package):
    other = client.post("/api/packages", json={"title": "მეორე"}).json()
    existing = make(client, other["id"])
    moved = make(client, package["id"], text="გადასატანი", answer="პ")
    body = {"package_id": other["id"], "text": "გადასატანი", "answer": "პ"}
    assert client.put(f"/api/questions/{moved['id']}", json=body).json()["position"] == existing["position"] + 1
    assert ids(client, package_id=other["id"]) == [existing["id"], moved["id"]]


def test_reset_played(client, package, data_dir):
    q = make(client, package["id"])
    with sqlite3.connect(data_dir / "quiz.db") as conn:
        conn.execute("UPDATE questions SET played_at = datetime('now')")
    assert client.get(f"/api/questions/{q['id']}").json()["played_at"]
    assert client.post(f"/api/questions/{q['id']}/reset-played").json()["played_at"] is None


def test_mark_played_keeps_first_time_and_counts(client, package, data_dir):
    q = make(client, package["id"])
    marked = client.post(f"/api/questions/{q['id']}/mark-played")
    assert marked.status_code == 200
    first = marked.json()["played_at"]
    assert first and marked.json()["updated_at"] == q["updated_at"]
    with sqlite3.connect(data_dir / "quiz.db") as conn:
        conn.execute("UPDATE questions SET played_at = '2000-01-01 00:00:00'")
    again = client.post(f"/api/questions/{q['id']}/mark-played").json()
    assert again["played_at"] == "2000-01-01 00:00:00"
    assert client.get("/api/packages").json()[0]["played_count"] == 1
    assert client.post("/api/questions/999/mark-played").status_code == 404


def test_delete_question(client, package):
    q = make(client, package["id"])
    assert client.delete(f"/api/questions/{q['id']}").status_code == 204
    assert client.get(f"/api/questions/{q['id']}").status_code == 404


def test_handout_image_upload_serve_and_cleanup(client, package, data_dir):
    res = client.post("/api/uploads", files={"file": ("რუკა.png", PNG, "image/png")})
    assert res.status_code == 200
    name = res.json()["name"]
    assert (data_dir / "uploads" / name).is_file()
    got = client.get(f"/api/uploads/{name}")
    assert got.status_code == 200 and got.content == PNG and got.headers["content-type"] == "image/png"
    q1 = make(client, package["id"], handout_image=name)
    q2 = make(client, package["id"], text="ასლი", answer="პ", handout_image=name)
    client.delete(f"/api/questions/{q1['id']}")
    assert (data_dir / "uploads" / name).is_file()  # still used by q2
    client.delete(f"/api/questions/{q2['id']}")
    assert not (data_dir / "uploads" / name).exists()


def test_upload_rejects_non_images_and_bad_names(client):
    assert client.post("/api/uploads", files={"file": ("x.png", b"not an image", "image/png")}).status_code == 415
    assert client.get("/api/uploads/..%2Fquiz.db").status_code == 404
    assert client.get("/api/uploads/" + "0" * 40 + ".png").status_code == 404
