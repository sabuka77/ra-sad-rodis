import asyncio
import hashlib

import pytest

from app.speech import cache
from app.speech.providers import PROVIDERS, ProviderError, rate_string
from app.speech.providers.edge import EdgeProvider

TEST_SENTENCE = "2024 წლის 15 მარტს ჩვენმა გუნდმა მე-3 ადგილი დაიკავა და ქულების 75% მოაგროვა."
MP3 = b"ID3fake-mp3"


class FakeProvider:
    """Mocked provider: counts calls, can fail the first N calls or sleep."""

    name = "edge"

    def __init__(self, fail_times=0, delay=0.0):
        self.calls = []
        self.fail_times = fail_times
        self.delay = delay
        self.active = self.max_active = 0

    async def synthesize(self, text, voice, rate_pct):
        self.calls.append((text, voice, rate_pct))
        self.active += 1
        self.max_active = max(self.max_active, self.active)
        try:
            if self.delay:
                await asyncio.sleep(self.delay)
            if len(self.calls) <= self.fail_times:
                raise ConnectionError("network down")
            return MP3 + text.encode("utf-8")
        finally:
            self.active -= 1


@pytest.fixture
def fake(monkeypatch):
    provider = FakeProvider()
    monkeypatch.setitem(PROVIDERS, "edge", provider)
    monkeypatch.setattr(cache, "RETRY_DELAY_S", 0)
    return provider


def prepare(client, **body):
    res = client.post("/api/tts/prepare", json=body)
    assert res.status_code == 200, res.text
    return res.json()


# ---------- cache key and rate ----------

def test_cache_key_is_sha1_of_provider_voice_rate_text():
    key = cache.cache_key("edge", "ka-GE-EkaNeural", -25, "ერთი")
    assert key == hashlib.sha1("edge|ka-GE-EkaNeural|-25%|ერთი".encode("utf-8")).hexdigest()
    assert key == cache.cache_key("edge", "ka-GE-EkaNeural", -25, "ერთი")


@pytest.mark.parametrize("change", [("azure", "ka-GE-EkaNeural", -25, "ერთი"),
                                    ("edge", "ka-GE-GiorgiNeural", -25, "ერთი"),
                                    ("edge", "ka-GE-EkaNeural", -40, "ერთი"),
                                    ("edge", "ka-GE-EkaNeural", -25, "ორი")])
def test_cache_key_changes_with_every_part(change):
    assert cache.cache_key(*change) != cache.cache_key("edge", "ka-GE-EkaNeural", -25, "ერთი")


def test_rate_string():
    assert rate_string(-25) == "-25%"
    assert rate_string(0) == "+0%"


# ---------- prepare ----------

def test_prepare_text_gives_segments_with_urls_and_slower_numbers(client, fake):
    data = prepare(client, text=TEST_SENTENCE)
    assert data["provider"] == "edge" and data["text"] == TEST_SENTENCE
    segments = data["segments"]
    assert [s["i"] for s in segments] == list(range(len(segments)))
    assert all(s["url"].startswith("/api/tts/audio/") and s["url"].endswith(".mp3") for s in segments)
    assert {s["rate_pct"] for s in segments if s["is_number"]} == {-40}  # -25 base + -15 for numbers
    assert {s["rate_pct"] for s in segments if not s["is_number"]} == {-25}
    spoken = " ".join(s["spoken"] for s in segments)
    assert not any(c.isdigit() for c in spoken)
    assert "ორი ათას ოცდაოთხი" in spoken and "მესამე" in spoken and "სამოცდათხუთმეტი პროცენტი" in spoken
    assert fake.calls == []  # nothing is synthesized before the audio is requested


def test_prepare_uses_settings_and_clamps_rate(client, fake):
    client.put("/api/settings", json={"voice": "ka-GE-GiorgiNeural", "rate_pct": -50, "number_rate_pct": -50})
    data = prepare(client, text="5 კაცი მოვიდა.")
    assert data["voice"] == "ka-GE-GiorgiNeural"
    assert data["segments"][0]["is_number"] and data["segments"][0]["rate_pct"] == -75


def test_prepare_question_uses_spoken_override_and_answer(client, fake):
    pkg = client.post("/api/packages", json={"title": "პ"}).json()
    q = client.post("/api/questions", json={"package_id": pkg["id"], "text": "დაწერილი.", "answer": "458 წელს",
                                            "spoken_override": "წასაკითხი."}).json()
    assert prepare(client, question_id=q["id"])["text"] == "წასაკითხი."
    answer = prepare(client, question_id=q["id"], field="answer")
    assert answer["text"] == "458 წელს" and "ოთხას ორმოცდათვრამეტ" in answer["segments"][0]["spoken"]
    assert client.post("/api/tts/prepare", json={"question_id": 99999}).status_code == 404


@pytest.mark.parametrize("body", [{}, {"text": "ა", "question_id": 1}, {"text": ""}, {"text": "ა", "field": "x"}])
def test_prepare_validation(client, body):
    assert client.post("/api/tts/prepare", json=body).status_code == 422


def test_browser_provider_gives_no_urls(client, fake):
    client.put("/api/settings", json={"tts_provider": "browser"})
    data = prepare(client, text="ერთი წინადადება.")
    assert data["provider"] == "browser" and data["segments"][0]["url"] is None


# ---------- audio: lazy synthesis, cache, retries, timeout ----------

def test_audio_is_synthesized_once_then_served_from_cache(client, fake, data_dir):
    url = prepare(client, text="მე-3 ადგილი.")["segments"][0]["url"]
    first = client.get(url)
    assert first.status_code == 200 and first.headers["content-type"] == "audio/mpeg"
    assert first.content.startswith(MP3)
    assert fake.calls == [("მესამე ადგილი.", "ka-GE-EkaNeural", -40)]
    assert client.get(url).content == first.content
    assert len(fake.calls) == 1  # second request: cache hit
    key = url.rsplit("/", 1)[1]
    assert (data_dir / "audio" / key).is_file()
    assert client.get("/api/tts/cache").json() == {"files": 1, "bytes": len(first.content)}


def test_audio_retries_twice_then_succeeds(client, fake):
    fake.fail_times = 2
    url = prepare(client, text="ტესტი.")["segments"][0]["url"]
    assert client.get(url).status_code == 200
    assert len(fake.calls) == 3


def test_audio_reports_provider_failure(client, fake):
    fake.fail_times = 99
    url = prepare(client, text="ტესტი.")["segments"][0]["url"]
    res = client.get(url)
    assert res.status_code == 503 and res.json()["detail"]["code"] == "tts_failed"
    assert len(fake.calls) == 3  # first try + 2 retries


def test_audio_timeout(client, fake, monkeypatch):
    monkeypatch.setattr(cache, "TIMEOUT_S", 0.05)
    fake.delay = 1
    url = prepare(client, text="ნელი.")["segments"][0]["url"]
    assert client.get(url).status_code == 503


def test_empty_audio_counts_as_failure(monkeypatch):
    class Silent:
        async def synthesize(self, *args):
            return b""

    monkeypatch.setitem(PROVIDERS, "edge", Silent())
    monkeypatch.setattr(cache, "RETRY_DELAY_S", 0)
    with pytest.raises(ProviderError):
        asyncio.run(cache.synthesize(cache.Job("edge", "ka-GE-EkaNeural", -25, "ა")))


def test_concurrency_is_limited_to_three(fake):
    fake.delay = 0.02

    async def run():
        jobs = [cache.Job("edge", "ka-GE-EkaNeural", -25, f"ტექსტი {i}") for i in range(8)]
        await asyncio.gather(*(cache.synthesize(job) for job in jobs))

    asyncio.run(run())
    assert len(fake.calls) == 8 and fake.max_active == 3


@pytest.mark.parametrize("url", ["/api/tts/audio/" + "0" * 40 + ".mp3", "/api/tts/audio/notakey.mp3"])
def test_unknown_audio_is_404(client, url):
    assert client.get(url).status_code == 404


def test_clear_cache(client, fake):
    for text in ("ერთი.", "ორი."):
        client.get(prepare(client, text=text)["segments"][0]["url"])
    assert client.get("/api/tts/cache").json()["files"] == 2
    assert client.delete("/api/tts/cache").json() == {"deleted": 2, "files": 0, "bytes": 0}
    url = prepare(client, text="ერთი.")["segments"][0]["url"]
    assert client.get(url).status_code == 200  # synthesized again after clearing
    assert len(fake.calls) == 3


# ---------- edge provider (edge_tts mocked) ----------

def test_edge_provider_passes_voice_and_rate_and_joins_chunks(monkeypatch):
    seen = {}

    class FakeCommunicate:
        def __init__(self, text, voice, *, rate):
            seen.update(text=text, voice=voice, rate=rate)

        async def stream(self):
            for chunk in ({"type": "audio", "data": b"ab"}, {"type": "WordBoundary"}, {"type": "audio", "data": b"cd"}):
                yield chunk

    monkeypatch.setattr("app.speech.providers.edge.edge_tts.Communicate", FakeCommunicate)
    audio = asyncio.run(EdgeProvider().synthesize("ტექსტი", "ka-GE-GiorgiNeural", -25))
    assert audio == b"abcd"
    assert seen == {"text": "ტექსტი", "voice": "ka-GE-GiorgiNeural", "rate": "-25%"}
