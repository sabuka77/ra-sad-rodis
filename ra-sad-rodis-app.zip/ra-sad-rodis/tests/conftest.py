import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def data_dir(tmp_path, monkeypatch):
    monkeypatch.setenv("RSR_DATA_DIR", str(tmp_path))
    return tmp_path


@pytest.fixture
def client(data_dir):
    from app.main import app

    with TestClient(app) as test_client:  # runs the lifespan, which creates the schema
        yield test_client
