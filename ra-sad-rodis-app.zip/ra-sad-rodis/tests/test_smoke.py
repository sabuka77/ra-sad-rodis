import json
import sqlite3

import pytest

from app import db
from app.models import Settings

TAB_IDS = ["tab-play", "tab-questions", "tab-import", "tab-settings"]


def test_index_has_georgian_title_and_four_tabs(client):
    res = client.get("/")
    assert res.status_code == 200
    assert "<title>რა? სად? როდის?</title>" in res.text
    for tab_id in TAB_IDS:
        assert f'id="{tab_id}"' in res.text


@pytest.mark.parametrize(
    "path", ["/static/css/app.css", "/static/js/app.js", "/static/js/i18n.js",
             "/static/js/api.js", "/static/js/settings.js", "/static/js/dialog.js",
             "/static/js/editor.js", "/static/js/questions.js", "/static/js/dictionary.js", "/static/js/offline.js",
             "/static/js/scoreboard.js", "/static/js/player.js",
             "/static/js/webspeech.js", "/static/js/listen.js", "/static/js/play.js", "/static/js/timer.js",
             "/static/js/answer.js", "/static/js/playkeys.js", "/static/css/play.css", "/static/js/importer.js",
             "/static/js/importtable.js", "/static/css/import.css", "/static/i18n/ka.json"],
)
def test_static_assets_are_served(client, path):
    assert client.get(path).status_code == 200


def test_every_data_i18n_key_exists_in_ka_json(client):
    import re

    strings = client.get("/static/i18n/ka.json").json()
    keys = re.findall(r'data-i18n(?:-[a-z]+)?="([^"]+)"', client.get("/").text)
    assert keys
    for key in keys:
        node = strings
        for part in key.split("."):
            node = node[part]
        assert isinstance(node, str) and node.strip(), key


def test_schema_created_and_init_is_idempotent(client, data_dir):
    db.init_db()  # second run must not fail
    with sqlite3.connect(data_dir / "quiz.db") as conn:
        tables = {row[0] for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {"packages", "questions", "settings"} <= tables
    assert (data_dir / "audio").is_dir() and (data_dir / "uploads").is_dir()


def test_settings_defaults(client):
    res = client.get("/api/settings")
    assert res.status_code == 200
    data = res.json()
    assert data == Settings().model_dump()
    assert data["rate_pct"] == -25
    assert data["timer_default_s"] == 60
    assert data["voice"] == "ka-GE-EkaNeural"


def test_settings_partial_update_persists(client):
    res = client.put("/api/settings", json={"rate_pct": -35, "theme": "light"})
    assert res.status_code == 200
    data = client.get("/api/settings").json()
    assert data["rate_pct"] == -35
    assert data["theme"] == "light"
    assert data["timer_default_s"] == 60  # untouched keys keep their defaults


def test_settings_store_georgian_text(client):
    entry = {"written": "ე.წ.", "spoken": "ეგრეთ წოდებული"}
    assert client.put("/api/settings", json={"pronunciation_dict": [entry]}).status_code == 200
    assert client.get("/api/settings").json()["pronunciation_dict"] == [entry]


@pytest.mark.parametrize(
    "changes",
    [{"rate_pct": 20}, {"voice": "en-US-JennyNeural"}, {"timer_presets": [1]},
     {"no_such_setting": 1}, {"theme": "purple"}],
)
def test_settings_rejects_invalid_values(client, changes):
    res = client.put("/api/settings", json=changes)
    assert res.status_code == 422
    assert client.get("/api/settings").json() == Settings().model_dump()


def test_settings_reset(client):
    client.put("/api/settings", json={"font_size_px": 60})
    assert client.post("/api/settings/reset").json() == Settings().model_dump()
    assert client.get("/api/settings").json()["font_size_px"] == 36


def test_corrupt_stored_setting_falls_back_to_default(client, data_dir):
    with sqlite3.connect(data_dir / "quiz.db") as conn:
        conn.execute("INSERT INTO settings VALUES ('rate_pct', ?)", (json.dumps(999),))
        conn.execute("INSERT INTO settings VALUES ('theme', ?)", (json.dumps("light"),))
    data = client.get("/api/settings").json()
    assert data["rate_pct"] == -25
    assert data["theme"] == "light"
