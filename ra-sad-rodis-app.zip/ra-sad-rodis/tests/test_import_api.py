"""Import API (parse → check → commit), the generated sample package and the dump CLI."""
import importlib.util
import sqlite3
from pathlib import Path

import pytest

from app.importer import dump
from tests.import_fixtures import docx_bytes

ROOT = Path(__file__).resolve().parent.parent
DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
COMMIT_FIELDS = ("tour", "number_label", "text", "answer", "accepted", "not_accepted", "comment", "sources",
                 "author", "handout_text")


@pytest.fixture(scope="module")
def sample(tmp_path_factory) -> bytes:
    spec = importlib.util.spec_from_file_location("make_sample", ROOT / "scripts" / "make_sample.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.build(tmp_path_factory.mktemp("sample") / "sample_package.docx").read_bytes()


def question_count(data_dir) -> int:
    with sqlite3.connect(data_dir / "quiz.db") as conn:
        return conn.execute("SELECT COUNT(*) FROM questions").fetchone()[0]


def upload(client, *files, legacy=None):
    data = {"legacy": legacy} if legacy else None
    return client.post("/api/import/parse", files=[("files", f) for f in files], data=data)


def commit_rows(rows):
    return [{k: r[k] for k in COMMIT_FIELDS} for r in rows]


def test_sample_package_parses_cleanly_without_writing(client, data_dir, sample):
    res = upload(client, ("sample_package.docx", sample, DOCX))
    assert res.status_code == 200
    body = res.json()
    (info,) = body["files"]
    assert info["error"] is None and info["count"] == 5
    assert info["title"] == "დემო პაკეტი: სადემონსტრაციო კითხვები"
    assert info["legacy"] == {"by_font": True, "detected": True, "applied": True}
    assert [r["warnings"] for r in body["rows"]] == [[]] * 5
    assert body["rows"][4]["text"] == "რამდენი ასოა თანამედროვე ქართულ ანბანში?"  # typed in AcadNusx
    assert body["rows"][4]["sources"][0]["url"] == "https://en.wikipedia.org/wiki/Georgian_scripts"
    assert question_count(data_dir) == 0
    assert client.get("/api/packages").json() == []


def test_legacy_toggle_off(client, sample):
    rows = upload(client, ("s.docx", sample, DOCX), legacy=["off"]).json()["rows"]
    # without conversion "SekiTxva 5." is no label, so question 5 runs into question 4
    assert len(rows) == 4 and "SekiTxva 5." in rows[3]["author"]


def test_several_files_with_errors(client):
    good = docx_bytes("შეკითხვა 1. საკმარისად გრძელი ტექსტი", "პასუხი: ა")
    res = upload(client, ("old.doc", b"\xd0\xcf\x11\xe0", "application/msword"), ("good.docx", good, DOCX),
                 ("bad.pdf", b"nope", "application/pdf"))
    files = res.json()["files"]
    assert [f["error"] for f in files] == ["doc_format", None, "unreadable"]
    assert [r["file"] for r in res.json()["rows"]] == [1]


def test_commit_new_package_then_duplicates_are_flagged(client, data_dir, sample):
    rows = upload(client, ("sample_package.docx", sample, DOCX)).json()["rows"]
    res = client.post("/api/import/commit", json={"package": {"title": "დემო", "source_file": "sample_package.docx"},
                                                   "rows": commit_rows(rows)})
    assert res.status_code == 201
    package = res.json()["package"]
    assert (res.json()["added"], package["question_count"], package["title"]) == (5, 5, "დემო")
    saved = client.get(f"/api/questions?package_id={package['id']}").json()
    assert [q["number_label"] for q in saved] == ["1", "2", "3", "4", "5"]
    assert saved[1]["sources"][1] == {"text": "საქართველოს ისტორია, ტ. IV, გვ. 120", "url": None}
    assert saved[0]["tour"] == "1" and saved[0]["handout_text"] is None
    again = upload(client, ("sample_package.docx", sample, DOCX)).json()["rows"]
    assert again[0]["warnings"] == [{"code": "duplicate_db", "package": "დემო", "number": "1", "count": 1}]


def test_commit_appends_to_existing_package(client):
    pkg = client.post("/api/packages", json={"title": "არსებული"}).json()
    client.post("/api/questions", json={"package_id": pkg["id"], "text": "ძველი კითხვა", "answer": "ა"})
    rows = [{"text": "ახალი კითხვა საკმარისად გრძელი", "answer": "ბ", "sources": [{"text": "www.a.ge", "url": "www.a.ge"}]}]
    res = client.post("/api/import/commit", json={"package_id": pkg["id"], "rows": rows})
    assert res.json()["package"]["question_count"] == 2
    saved = client.get(f"/api/questions?package_id={pkg['id']}").json()
    assert saved[1]["position"] == 2 and saved[1]["sources"][0]["url"] == "https://www.a.ge"


@pytest.mark.parametrize("body", [
    {"package": {"title": "x"}, "rows": [{"text": "კითხვა", "answer": ""}]},
    {"package": {"title": "x"}, "package_id": 1, "rows": [{"text": "კითხვა", "answer": "ა"}]},
    {"rows": [{"text": "კითხვა", "answer": "ა"}]},
    {"package": {"title": "x"}, "rows": []},
])
def test_commit_validation(client, data_dir, body):
    res = client.post("/api/import/commit", json=body)
    assert res.status_code == 422
    assert question_count(data_dir) == 0 and client.get("/api/packages").json() == []


def test_commit_reports_rows_without_answer(client):
    rows = [{"text": "კარგი კითხვა", "answer": "ა"}, {"text": "უპასუხო კითხვა", "answer": " "}]
    detail = client.post("/api/import/commit", json={"package": {"title": "x"}, "rows": rows}).json()["detail"]
    assert [d["loc"][:3] for d in detail] == [["body", "rows", 1]]


def test_commit_unknown_package(client):
    res = client.post("/api/import/commit", json={"package_id": 99, "rows": [{"text": "ტ", "answer": "ა"}]})
    assert res.status_code == 404


def test_check_endpoint(client):
    rows = [{"text": "საკმარისად გრძელი ტექსტი", "answer": "ა", "number_label": "1", "file": 0, "warnings": []},
            {"text": "საკმარისად გრძელი ტექსტი", "answer": "", "number_label": "3", "file": 0}]
    warnings = client.post("/api/import/check", json={"rows": rows}).json()["warnings"]
    assert [[w["code"] for w in found] for found in warnings] == [
        [], ["no_answer", "duplicate_batch", "numbering_gap"]]


def test_dump_cli(tmp_path, capsys, sample):
    path = tmp_path / "s.docx"
    path.write_bytes(sample)
    assert dump.main([str(path)]) == 0
    out = capsys.readouterr().out
    assert "questions: 5" in out and "AcadNusx" in out and "answer: 33 ასო" in out
    old = tmp_path / "old.doc"
    old.write_bytes(b"x")
    assert dump.main([str(old)]) == 1
    assert "doc_format" in capsys.readouterr().out
