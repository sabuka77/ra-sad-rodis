"""Importer units and the spec §7 fixture cases (readers → legacy fonts → cleanup → segmenter)."""
import codecs

import pytest
from docx import Document

from app.importer import ImportFailure, checks, pipeline
from app.importer.cleanup import clean_text
from app.importer.legacy_fonts import convert_text, looks_like_acadnusx
from app.importer.pdf_reader import join_lines
from app.importer.segmenter import load_labels, parse_sources
from tests.import_fixtures import docx_bytes, needs_georgian_font, pdf_bytes, save, scanned_pdf_bytes


def parse(name, data, legacy=None):
    return pipeline.parse(name, data, legacy)


def txt(text: str) -> bytes:
    return text.encode("utf-8")


# ---------- units ----------

@pytest.mark.parametrize("latin, georgian", [
    ("saqarTvelo", "საქართველო"), ("Tbilisi", "თბილისი"), ("Aa", "აა"),
    ("1918 w. 26 maiss", "1918 წ. 26 მაისს"),
    ("naxe https://en.wikipedia.org/wiki/Tbilisi.", "ნახე https://en.wikipedia.org/wiki/Tbilisi."),
])
def test_acadnusx_conversion(latin, georgian):
    assert convert_text(latin) == georgian


def test_acadnusx_guess_without_font_info():
    assert looks_like_acadnusx("ra aris saqarTvelos dedaqalaqi")
    assert not looks_like_acadnusx("The capital of France is Paris")
    assert not looks_like_acadnusx("saqarTvelo aris და ebi")  # already has Georgian letters


def test_cleanup():
    assert clean_text("ა\u00a0\u00a0ბ\u00adგ\u200b\t დ \r\n  ე  ") == "ა ბგ დ\nე"
    assert clean_text("„ციტატა“ — ტირე") == "„ციტატა“ — ტირე"


@pytest.mark.parametrize("line, expected", [
    ("შეკითხვა 1.", ("question", "1", "")),
    ("კითხვა №12: ტექსტი", ("question", "12", "ტექსტი")),
    ("Вопрос 3. Текст", ("question", "3", "Текст")),
    ("პასუხი: 1812", ("answer", None, "1812")),
    ("პასუხი", ("answer", None, "")),
    ("არ ჩაითვლება: მცხეთა", ("not_accepted", None, "მცხეთა")),
    ("ასევე ჩაითვლება — X", ("accepted", None, "X")),
    ("ჩაითვლება: Y", ("accepted", None, "Y")),
    ("ANSWER: z", ("answer", None, "z")),
    ("პასუხისმგებლობა დიდია", None),
    ("კითხვა რომელიც ლეიბლი არ არის", None),
])
def test_label_matching(line, expected):
    assert load_labels().match(line) == expected


def test_parse_sources():
    assert parse_sources("1. https://ka.wikipedia.org/wiki/X_(Y).\n2) წიგნი, გვ. 5") == [
        {"text": "https://ka.wikipedia.org/wiki/X_(Y).", "url": "https://ka.wikipedia.org/wiki/X_(Y)"},
        {"text": "წიგნი, გვ. 5", "url": None}]
    assert [s["url"] for s in parse_sources("www.a.ge/x; https://b.com/y")] == ["www.a.ge/x", "https://b.com/y"]
    assert len(parse_sources("წიგნი; სტატია https://c.com")) == 1  # not every part has a URL


def test_pdf_hyphen_join_only_between_georgian_letters():
    joined = join_lines([[("საქარ-", "F")], [("თველო და well-", "F")], [("known", "F")]])
    assert "".join(t for t, _ in joined) == "საქართველო და well-\nknown"
    legacy = join_lines([[("saqar-", "AcadNusx")], [("Tvelo", "AcadNusx")]])
    assert "".join(t for t, _ in legacy) == "saqarTvelo"


# ---------- spec §7 cases ----------

CANONICAL = [
    "ჩემპიონატის პაკეტი", "რედაქტორი: ნინო ბერიძე", "შესავალი ტექსტი.", "ტური 1",
    "შეკითხვა 1.", "პირველი კითხვის პირველი აბზაცი, საკმარისად გრძელი.", "მეორე აბზაცი.",
    "პასუხისმგებლობა ლეიბლი არ არის.",
    "პასუხი: თბილისი", "ჩაითვლება: ტფილისი", "არ ჩაითვლება: მცხეთა",
    "კომენტარი: პირველი აბზაცი [1].", "კომენტარის მეორე აბზაცი [2].",
    "წყარო:", "1. https://ka.wikipedia.org/wiki/Tbilisi.", "2) საქართველოს ისტორია, გვ. 5", "ავტორი: გიორგი",
    "შეკითხვა 2: მეორე კითხვის ტექსტი ლეიბლის ხაზზე.", "პასუხი: 1812", "ასევე ჩაითვლება: ათას რვაას თორმეტი",
    "ტური 2",
    "კითხვა №3", "მესამე კითხვის ტექსტი, საკმარისად გრძელი.", "პასუხი — მესამე პასუხი",
    "წყაროები: www.example.ge/page; https://example.com/a",
]


def test_canonical_docx_with_tours_header_comment_sources_and_accepted():  # cases 1, 5, 6, 7
    result = parse("paket.docx", docx_bytes(*CANONICAL, styles={0: "Title"}))
    assert result["title"] == "ჩემპიონატის პაკეტი"
    assert result["editor"] == "ნინო ბერიძე"
    q1, q2, q3 = result["questions"]
    assert (q1["number_label"], q1["tour"]) == ("1", "1")
    assert q1["text"] == ("პირველი კითხვის პირველი აბზაცი, საკმარისად გრძელი.\nმეორე აბზაცი.\n"
                          "პასუხისმგებლობა ლეიბლი არ არის.")
    assert (q1["answer"], q1["accepted"], q1["not_accepted"]) == ("თბილისი", "ტფილისი", "მცხეთა")
    assert q1["comment"] == "პირველი აბზაცი [1].\nკომენტარის მეორე აბზაცი [2]."
    assert q1["sources"] == [
        {"text": "https://ka.wikipedia.org/wiki/Tbilisi.", "url": "https://ka.wikipedia.org/wiki/Tbilisi"},
        {"text": "საქართველოს ისტორია, გვ. 5", "url": None}]
    assert q1["author"] == "გიორგი"
    assert (q2["number_label"], q2["text"], q2["answer"]) == ("2", "მეორე კითხვის ტექსტი ლეიბლის ხაზზე.", "1812")
    assert q2["accepted"] == "ათას რვაას თორმეტი"
    assert (q3["number_label"], q3["tour"], q3["answer"]) == ("3", "2", "მესამე პასუხი")
    assert [s["url"] for s in q3["sources"]] == ["www.example.ge/page", "https://example.com/a"]
    assert checks.compute(result["questions"]) == [[], [], []]


def test_numbered_txt_without_question_labels():  # case 2
    text = ("ვიქტორინა\n1. პირველი კითხვა საკმარისად გრძელი ტექსტით.\nპასუხი: ერთი\nწყარო:\n"
            "1. https://a.ge\n2. წიგნი\n2) მეორე კითხვა საკმარისად გრძელი ტექსტით.\nგაგრძელება.\nპასუხი: ორი\n")
    result = parse("quiz.txt", txt(text))
    assert result["title"] == "ვიქტორინა"
    q1, q2 = result["questions"]
    assert (q1["number_label"], q1["answer"], len(q1["sources"])) == ("1", "ერთი", 2)
    assert (q2["number_label"], q2["text"]) == ("2", "მეორე კითხვა საკმარისად გრძელი ტექსტით.\nგაგრძელება.")


def test_docx_auto_numbering():  # case 2
    paragraphs = ["პაკეტი", "პირველი კითხვა ავტონუმერაციით.", "პასუხი: ა", "კომენტარი:", "პუნქტი ერთი",
                  "პუნქტი ორი", "მეორე კითხვა ავტონუმერაციით.", "პასუხი: ბ"]
    styles = {1: "List Number", 4: "List Bullet", 5: "List Bullet", 6: "List Number"}
    q1, q2 = parse("auto.docx", docx_bytes(*paragraphs, styles=styles))["questions"]
    assert (q1["number_label"], q1["text"], q1["comment"]) == ("1", "პირველი კითხვა ავტონუმერაციით.",
                                                               "პუნქტი ერთი\nპუნქტი ორი")
    assert (q2["number_label"], q2["answer"]) == ("2", "ბ")


def test_docx_table_format():  # case 3
    document = Document()
    document.add_paragraph("ცხრილის პაკეტი")
    other = document.add_table(rows=1, cols=2)  # not a question table: its cells are normal paragraphs
    other.cell(0, 0).text, other.cell(0, 1).text = "თარიღი", "2024"
    table = document.add_table(rows=3, cols=5)
    rows = [["№", "კითხვა", "პასუხი", "წყარო", "თემა"],
            ["1", "ცხრილის პირველი კითხვა, საკმარისად გრძელი.", "პასუხი ერთი", "https://a.ge/1", "ისტორია"],
            ["2", "ცხრილის მეორე კითხვა, საკმარისად გრძელი.", "პასუხი ორი", "", ""]]
    for r, values in enumerate(rows):
        for c, value in enumerate(values):
            table.cell(r, c).text = value
    result = parse("table.docx", save(document))
    q1, q2 = result["questions"]
    assert (q1["number_label"], q1["text"], q1["answer"]) == ("1", rows[1][1], "პასუხი ერთი")
    assert q1["sources"] == [{"text": "https://a.ge/1", "url": "https://a.ge/1"}]
    assert q1["comment"] == "თემა: ისტორია"
    assert (q2["number_label"], q2["answer"], q2["sources"], q2["comment"]) == ("2", "პასუხი ორი", [], "")
    assert result["title"] == "ცხრილის პაკეტი"


def test_acadnusx_runs_mixed_with_unicode():  # case 4
    data = docx_bytes("შეკითხვა 1.", (("ქალაქი ", None), ("Tbilisi", "AcadNusx"), (" დედაქალაქია. რომელი?", None)),
                      (("პასუხი: ", None), ("saqarTvelo", "AcadNusx")))
    result = parse("acad.docx", data)
    assert result["legacy"] == {"by_font": True, "detected": True, "applied": True}
    q = result["questions"][0]
    assert (q["text"], q["answer"]) == ("ქალაქი თბილისი დედაქალაქია. რომელი?", "საქართველო")
    assert parse("acad.docx", data, legacy=False)["questions"][0]["answer"] == "saqarTvelo"


def test_acadnusx_txt_is_detected_without_fonts():
    result = parse("old.txt", txt("SekiTxva 1.\nra aris saqarTvelos dedaqalaqi?\npasuxi: Tbilisi"))
    assert result["legacy"]["detected"] and not result["legacy"]["by_font"]
    q = result["questions"][0]
    assert (q["text"], q["answer"]) == ("რა არის საქართველოს დედაქალაქი?", "თბილისი")


@needs_georgian_font
def test_pdf_hyphenation_and_repeated_footer():  # case 8
    pages = [["შეკითხვა 1.\nპირველი კითხვა ეხება საქარ-\nთველოს ისტორიას და გრძელდება.", "პასუხი: საქართველო"],
             ["შეკითხვა 2.\nმეორე კითხვის ტექსტი საკმარისად გრძელია.", "პასუხი: ორი\nწყარო:\n1. https://a.ge\n2. წიგნი"]]
    result = parse("p.pdf", pdf_bytes(pages, footer="ჩემპიონატი 2024 — სარედაქციო", page_numbers=True))
    q1, q2 = result["questions"]
    assert q1["text"] == "პირველი კითხვა ეხება საქართველოს ისტორიას და გრძელდება."
    assert (q1["answer"], q2["answer"]) == ("საქართველო", "ორი")
    assert [s["text"] for s in q2["sources"]] == ["https://a.ge", "წიგნი"]
    assert not any("ჩემპიონატი" in p.text for p in result["paragraphs"])


def test_russian_labels():  # case 9
    text = ("Вопрос 1: Текст первого вопроса достаточно длинный.\nОтвет: Тбилиси\nЗачёт: Тифлис\n"
            "Незачёт: Мцхета\nКомментарий: Столица.\nИсточник: https://ru.wikipedia.org/wiki/Тбилиси\nАвтор: Иван")
    q = parse("ru.txt", txt(text))["questions"][0]
    assert (q["number_label"], q["text"], q["answer"]) == ("1", "Текст первого вопроса достаточно длинный.", "Тбилиси")
    assert (q["accepted"], q["not_accepted"], q["comment"], q["author"]) == ("Тифлис", "Мцхета", "Столица.", "Иван")
    assert q["sources"][0]["url"] == "https://ru.wikipedia.org/wiki/Тбилиси"


def test_title_falls_back_to_file_name():
    assert parse("ჩემი ფაილი.txt", txt("შეკითხვა 1. ტექსტი\nპასუხი: ა"))["title"] == "ჩემი ფაილი"


# ---------- errors ----------

@pytest.mark.parametrize("name, data, code", [
    ("old.doc", b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1 whatever", "doc_format"),
    ("locked.docx", b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1 encrypted package", "docx_encrypted"),
    ("broken.docx", b"not a zip", "unreadable"),
    ("broken.pdf", b"%PDF-1.4 garbage", "unreadable"),
    ("notes.rtf", b"{\\rtf1}", "unsupported_type"),
    ("ansi.txt", "Вопрос 1".encode("cp1251"), "txt_encoding"),
])
def test_unreadable_files(name, data, code):
    with pytest.raises(ImportFailure) as info:
        parse(name, data)
    assert info.value.code == code


def test_scanned_pdf_without_text_layer():
    with pytest.raises(ImportFailure, match="pdf_no_text"):
        parse("scan.pdf", scanned_pdf_bytes())


@needs_georgian_font
def test_password_protected_pdf():
    with pytest.raises(ImportFailure, match="pdf_encrypted"):
        parse("locked.pdf", pdf_bytes([["შეკითხვა 1. ტექსტი", "პასუხი: ა"]], encrypt=True))


def test_utf16_txt():
    data = codecs.BOM_UTF16_LE + "შეკითხვა 1. საკმარისად გრძელი ტექსტი\nპასუხი: ა".encode("utf-16-le")
    assert parse("u16.txt", data)["questions"][0]["answer"] == "ა"


# ---------- warnings ----------

def test_warnings():
    long_text = "ა" * 1501
    rows = [
        {"text": "საკმარისად გრძელი ტექსტი ერთი", "answer": "ა", "number_label": "1"},
        {"text": "მოკლე", "answer": "", "number_label": "2"},
        {"text": long_text, "answer": "ბ" * 301, "number_label": "4"},
        {"text": "საკმარისად გრძელი ტექსტი, ერთი!", "answer": "ა", "number_label": "4"},
        {"text": "საკმარისად გრძელი ტექსტი სამი", "answer": "ა", "number_label": "2"},
        {"text": "ახალი ტურის პირველი კითხვა", "answer": "ა", "number_label": "1", "tour": "2"},
        {"text": "სხვა ფაილის პირველი კითხვა", "answer": "ა", "number_label": "1", "file": 1},
    ]
    codes = [[w["code"] for w in found] for found in checks.compute(rows)]
    assert codes == [[], ["no_answer", "short_text"], ["long_text", "long_answer", "numbering_gap"],
                     ["duplicate_batch", "numbering_repeat"], ["numbering_order"], [], []]
    assert checks.compute(rows)[3][0] == {"code": "duplicate_batch", "row": 1}
