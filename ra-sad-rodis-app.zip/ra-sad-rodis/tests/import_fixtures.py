"""Builds import fixtures in memory (no binary files in the repo): DOCX via python-docx, PDF via pymupdf."""
import io
from pathlib import Path

import pymupdf
import pytest
from docx import Document

FONT_CANDIDATES = [Path("C:/Windows/Fonts/sylfaen.ttf"),
                   Path("/usr/share/fonts/truetype/noto/NotoSansGeorgian-Regular.ttf"),
                   Path("/usr/share/fonts/noto/NotoSansGeorgian-Regular.ttf"),
                   Path("/Library/Fonts/NotoSansGeorgian-Regular.ttf")]
GEORGIAN_FONT = next((p for p in FONT_CANDIDATES if p.exists()), None)
needs_georgian_font = pytest.mark.skipif(GEORGIAN_FONT is None,
                                         reason="no Georgian-capable font (sylfaen.ttf / Noto Sans Georgian) found")


def docx_bytes(*paragraphs, styles: dict[int, str] | None = None, fonts: dict[int, str] | None = None) -> bytes:
    """One paragraph per string. A tuple of (text, font) pairs makes one paragraph of several runs;
    `styles` / `fonts` map paragraph index → style name / font name of all its runs."""
    document = Document()
    for i, item in enumerate(paragraphs):
        paragraph = document.add_paragraph(style=(styles or {}).get(i))
        runs = item if isinstance(item, tuple) else [(item, (fonts or {}).get(i))]
        for text, font in runs:
            run = paragraph.add_run(text)
            if font:
                run.font.name = font
    return save(document)


def save(document) -> bytes:
    buffer = io.BytesIO()
    document.save(buffer)
    return buffer.getvalue()


def pdf_bytes(pages: list[list[str]], footer: str | None = None, page_numbers: bool = False,
              encrypt: bool = False) -> bytes:
    """Each page is a list of text blocks written top-down (each block may contain '\n' lines)."""
    document = pymupdf.open()
    for number, blocks in enumerate(pages, start=1):
        page = document.new_page()
        y = 80
        for block in blocks:
            for line in block.split("\n"):
                page.insert_text((72, y), line, fontname="geo", fontfile=str(GEORGIAN_FONT), fontsize=11)
                y += 14
            y += 24  # gap → new block
        if footer:
            page.insert_text((72, page.rect.height - 30), footer, fontname="geo", fontfile=str(GEORGIAN_FONT),
                             fontsize=9)
        if page_numbers:
            page.insert_text((290, page.rect.height - 15), str(number), fontsize=9)
    if encrypt:
        return document.tobytes(encryption=pymupdf.PDF_ENCRYPT_AES_256, user_pw="u", owner_pw="o")
    return document.tobytes()


def scanned_pdf_bytes() -> bytes:
    """Pages with only a drawn rectangle: no text layer at all."""
    document = pymupdf.open()
    for _ in range(2):
        page = document.new_page()
        page.draw_rect(pymupdf.Rect(50, 50, 500, 700), color=(0, 0, 0), fill=(0.8, 0.8, 0.8))
    return document.tobytes()
