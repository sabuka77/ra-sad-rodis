"""Phase 6: Azure provider, fallback chain, masked key, offline pre-generation, dictionary in previews."""
import asyncio
import logging
import time

import httpx
import pytest

from app import db
from app.speech import cache
from app.speech.providers import PROVIDERS, ProviderConfigError
from app.speech.providers import azure

SECRET = "s3cr3t-azure-key"
MP3 = b"ID3fake"


class Fake:
    """Mocked provider: returns MP3 bytes, or fails while `failing` is set."""

    def __init__(self, name, failing=False, delay=0.0):
        self.name, self.failing, self.delay, self.calls = name, failing, delay, []

    async def synthesize(self, text, voice, rate_pct):
        self.calls.append(text)
        if self.delay:
            await asyncio.sleep(self.delay)
        if self.failing:
            raise ConnectionError("network down")
        return MP3 + f"{self.name}:{text}".encode("utf-8")


@pytest.fixture
def edge(monkeypatch):
    fake = Fake("edge")
    monkeypatch.setitem(PROVIDERS, "edge", fake)
    monkeypatch.setattr(cache, "RETRY_DELAY_S", 0)
    return fake


def make_package(client, questions):
    pkg = client.post("/api/packages", json={"title": "ოფლაინ"}).json()
    for text, answer in questions:
        assert client.post("/api/questions", json={"package_id": pkg["id"], "text": text, "answer": answer}).status_code == 201
    return pkg


def wait_done(client, timeout=10):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        status = client.get("/api/tts/pregenerate").json()
        if not status["running"]:
            return status
        time.sleep(0.02)
    raise AssertionError("pre-generation did not finish")


def all_segment_urls(client, question_ids):
    urls = []
    for qid in question_ids:
        for field in ("text", "answer"):
            res = client.post("/api/tts/prepare", json={"question_id": qid, "field": field})
            urls += [s["url"] for s in res.json()["segments"]]
    return urls


# ---------- Azure provider ----------

def test_ssml_escapes_text_and_sets_voice_and_rate():
    xml = azure.ssml('A & B <C> "1"', "ka-GE-GiorgiNeural", -25)
    assert xml == ('<speak version="1.0" xml:lang="ka-GE"><voice name="ka-GE-GiorgiNeural">'
                   '<prosody rate="-25%">A &amp; B &lt;C&gt; "1"</prosody></voice></speak>')


def use_transport(monkeypatch, handler):
    real = httpx.AsyncClient
    monkeypatch.setattr(httpx, "AsyncClient", lambda **kw: real(transport=httpx.MockTransport(handler), **kw))


def test_azure_request_uses_region_key_and_ssml(client, monkeypatch):
    client.put("/api/settings", json={"azure_key": SECRET, "azure_region": "westeurope"})
    seen = {}

    def handler(request):
        seen.update(url=str(request.url), key=request.headers["Ocp-Apim-Subscription-Key"],
                    fmt=request.headers["X-Microsoft-OutputFormat"], body=request.content.decode("utf-8"))
        return httpx.Response(200, content=MP3)

    use_transport(monkeypatch, handler)
    assert asyncio.run(azure.AzureProvider().synthesize("ერთი", "ka-GE-EkaNeural", -30)) == MP3
    assert seen["url"] == "https://westeurope.tts.speech.microsoft.com/cognitiveservices/v1"
    assert seen["key"] == SECRET and seen["fmt"] == azure.OUTPUT_FORMAT
    assert '<prosody rate="-30%">ერთი</prosody>' in seen["body"]


@pytest.mark.parametrize("status", [401, 403])
def test_rejected_key_fails_once_without_retries_and_never_shows_the_key(client, monkeypatch, caplog, status):
    client.put("/api/settings", json={"azure_key": SECRET, "azure_region": "westeurope"})
    calls = []
    use_transport(monkeypatch, lambda request: calls.append(1) or httpx.Response(status))
    caplog.set_level(logging.DEBUG)
    with pytest.raises(ProviderConfigError) as info:
        asyncio.run(cache.synthesize(cache.Job("azure", "ka-GE-EkaNeural", -25, "ერთი")))
    assert len(calls) == 1
    assert SECRET not in str(info.value) and SECRET not in caplog.text


def test_azure_without_key_is_a_config_error(client):
    with pytest.raises(ProviderConfigError):
        asyncio.run(azure.AzureProvider().synthesize("ერთი", "ka-GE-EkaNeural", -25))


# ---------- provider choice and fallback ----------

def test_azure_is_used_only_with_key_and_region(client, edge):
    client.put("/api/settings", json={"tts_provider": "azure"})
    assert client.post("/api/tts/prepare", json={"text": "ერთი."}).json()["provider"] == "edge"
    client.put("/api/settings", json={"azure_key": SECRET, "azure_region": "westeurope"})
    assert client.post("/api/tts/prepare", json={"text": "ერთი."}).json()["provider"] == "azure"


def test_failing_azure_falls_back_to_edge(client, edge, monkeypatch):
    monkeypatch.setitem(PROVIDERS, "azure", Fake("azure", failing=True))
    client.put("/api/settings", json={"tts_provider": "azure", "azure_key": SECRET, "azure_region": "westeurope"})
    url = client.post("/api/tts/prepare", json={"text": "გამარჯობა."}).json()["segments"][0]["url"]
    res = client.get(url)
    assert res.status_code == 200 and res.content.startswith(MP3 + b"edge:")
    assert edge.calls == ["გამარჯობა."]


def test_when_edge_fails_too_the_page_gets_503_for_the_browser_voice(client, edge):
    edge.failing = True
    url = client.post("/api/tts/prepare", json={"text": "გამარჯობა."}).json()["segments"][0]["url"]
    assert client.get(url).status_code == 503


# ---------- settings: the key stays on the server ----------

def test_azure_key_is_masked_and_kept(client):
    assert client.put("/api/settings", json={"azure_key": SECRET}).json()["azure_key"] == "********"
    assert client.get("/api/settings").json()["azure_key"] == "********"
    client.put("/api/settings", json={"azure_key": "********", "voice": "ka-GE-GiorgiNeural"})  # mask sent back
    assert db.load_settings().azure_key == SECRET
    assert client.put("/api/settings", json={"azure_key": ""}).json()["azure_key"] == ""
    assert db.load_settings().azure_key == ""


def test_region_is_normalized_and_validated(client):
    assert client.put("/api/settings", json={"azure_region": " West Europe "}).json()["azure_region"] == "westeurope"
    res = client.put("/api/settings", json={"azure_region": "evil.example/x", "azure_key": SECRET})
    assert res.status_code == 422 and SECRET not in res.text


# ---------- offline pre-generation ----------

def test_pregenerated_package_plays_without_network(client, edge):
    pkg = make_package(client, [("1921 წელს რა მოხდა?", "საბჭოთა ოკუპაცია"), ("მეორე კითხვა.", "პასუხი 2")])
    ids = [q["id"] for q in client.get("/api/questions", params={"package_id": pkg["id"]}).json()]
    started = client.post("/api/tts/pregenerate", json={"package_id": pkg["id"]})
    assert started.status_code == 200 and started.json()["package_id"] == pkg["id"]
    status = wait_done(client)
    assert status["total"] > 0 and status["done"] == status["total"] and status["failed"] == 0
    assert len(edge.calls) == status["total"]

    edge.failing = True  # "network disconnected": every segment must come from the cache
    urls = all_segment_urls(client, ids)
    assert len(set(urls)) == status["total"]
    for url in urls:
        assert client.get(url).status_code == 200
    assert len(edge.calls) == status["total"]  # no new provider calls


def test_pregeneration_counts_failures_and_skips_cached(client, edge):
    pkg = make_package(client, [("პირველი.", "ა"), ("მეორე.", "ბ")])
    edge.failing = True
    client.post("/api/tts/pregenerate", json={"package_id": pkg["id"]})
    failed = wait_done(client)
    assert failed["failed"] == failed["total"] == 4
    edge.failing = False
    client.post("/api/tts/pregenerate", json={"package_id": pkg["id"]})
    again = wait_done(client)
    assert again["failed"] == 0 and again["done"] == 4
    calls = len(edge.calls)
    client.post("/api/tts/pregenerate", json={"package_id": pkg["id"]})
    assert wait_done(client)["done"] == 4 and len(edge.calls) == calls  # everything was cached


def test_pregeneration_errors_busy_and_cancel(client, edge):
    assert client.post("/api/tts/pregenerate", json={"package_id": 999}).status_code == 404
    pkg = make_package(client, [(f"კითხვა {i}.", f"პასუხი {i}") for i in range(4)])
    client.put("/api/settings", json={"tts_provider": "browser"})
    assert client.post("/api/tts/pregenerate", json={"package_id": pkg["id"]}).status_code == 409
    client.put("/api/settings", json={"tts_provider": "edge"})
    edge.delay = 0.2
    assert client.post("/api/tts/pregenerate", json={"package_id": pkg["id"]}).json()["running"] is True
    assert client.post("/api/tts/pregenerate", json={"package_id": pkg["id"]}).status_code == 409
    cancelled = client.delete("/api/tts/pregenerate").json()
    assert cancelled["cancelled"] is True and cancelled["running"] is False
    assert cancelled["done"] < cancelled["total"]


def test_empty_package_finishes_at_once(client, edge):
    pkg = client.post("/api/packages", json={"title": "ცარიელი"}).json()
    status = client.post("/api/tts/pregenerate", json={"package_id": pkg["id"]}).json()
    assert status["total"] == 0 and status["running"] is False


# ---------- pronunciation dictionary ----------

def test_dictionary_edits_change_the_spoken_preview(client):
    before = client.get("/api/speech/preview", params={"text": "ФИФА-ს მსოფლიო თასი."}).json()["spoken"]
    entry = {"written": "ФИФА", "spoken": "ფიფა"}
    assert client.put("/api/settings", json={"pronunciation_dict": [entry]}).status_code == 200
    after = client.get("/api/speech/preview", params={"text": "ФИФА-ს მსოფლიო თასი."}).json()["spoken"]
    assert "ფიფას მსოფლიო" in after and after != before  # the hyphenated suffix joins the spoken word
    client.put("/api/settings", json={"pronunciation_dict": []})
    assert client.get("/api/speech/preview", params={"text": "ФИФА-ს მსოფლიო თასი."}).json()["spoken"] == before
