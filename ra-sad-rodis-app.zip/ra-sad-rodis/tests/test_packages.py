import sqlite3
from urllib.parse import unquote

PNG = b"\x89PNG\r\n\x1a\n" + b"\x01" * 32


def add_question(client, package_id, text, **extra):
    res = client.post("/api/questions", json={"package_id": package_id, "text": text, "answer": "პასუხი", **extra})
    assert res.status_code == 201, res.text
    return res.json()


def test_package_crud(client):
    assert client.get("/api/packages").json() == []
    created = client.post("/api/packages", json={"title": " თასი 2026 ", "editor": "ნინო"})
    assert created.status_code == 201
    pkg = created.json()
    assert pkg["title"] == "თასი 2026" and pkg["question_count"] == 0 and pkg["created_at"]
    renamed = client.patch(f"/api/packages/{pkg['id']}", json={"title": "ზამთრის თასი"}).json()
    assert renamed["title"] == "ზამთრის თასი" and renamed["editor"] == "ნინო"  # unset fields are kept
    assert [p["title"] for p in client.get("/api/packages").json()] == ["ზამთრის თასი"]


def test_package_validation_and_404(client):
    assert client.post("/api/packages", json={"title": "  "}).status_code == 422
    assert client.patch("/api/packages/5", json={"title": "x"}).status_code == 404
    assert client.delete("/api/packages/5").status_code == 404
    assert client.get("/api/packages/5/export").status_code == 404


def test_counts_and_reset_played(client, data_dir):
    pkg = client.post("/api/packages", json={"title": "პ"}).json()
    for i in range(3):
        add_question(client, pkg["id"], f"კითხვა {i}")
    with sqlite3.connect(data_dir / "quiz.db") as conn:
        conn.execute("UPDATE questions SET played_at = datetime('now') WHERE position <= 2")
    listed = client.get("/api/packages").json()[0]
    assert (listed["question_count"], listed["played_count"]) == (3, 2)
    assert client.post(f"/api/packages/{pkg['id']}/reset-played").json()["played_count"] == 0


def test_delete_package_removes_its_questions_and_images(client, data_dir):
    keep = client.post("/api/packages", json={"title": "დარჩება"}).json()
    gone = client.post("/api/packages", json={"title": "წაიშლება"}).json()
    image = client.post("/api/uploads", files={"file": ("a.png", PNG, "image/png")}).json()["name"]
    kept = add_question(client, keep["id"], "დარჩენილი")
    add_question(client, gone["id"], "პირველი", handout_image=image)
    add_question(client, gone["id"], "მეორე")
    assert client.delete(f"/api/packages/{gone['id']}").status_code == 204
    assert [p["id"] for p in client.get("/api/packages").json()] == [keep["id"]]
    assert [q["id"] for q in client.get("/api/questions").json()] == [kept["id"]]
    assert not (data_dir / "uploads" / image).exists()


def test_export_import_round_trip(client, data_dir):
    pkg = client.post("/api/packages", json={"title": "ზამთრის თასი", "editor": "ნინო", "notes": "შენიშვნა"}).json()
    image = client.post("/api/uploads", files={"file": ("a.png", PNG, "image/png")}).json()["name"]
    first = add_question(client, pkg["id"], "რომელ წელს?", tour="I", number_label="1", accepted="458",
                         not_accepted="459", comment="[1]", author="ავტორი", handout_text="ტექსტი",
                         handout_image=image, spoken_override="ოთხას ორმოცდათვრამეტ",
                         sources=[{"text": "ვიკი", "url": "https://ka.wikipedia.org"}, {"text": "წიგნი"}])
    second = add_question(client, pkg["id"], "მეორე კითხვა", number_label="2")
    client.post(f"/api/questions/{second['id']}/move", json={"direction": "up"})  # export keeps the order
    with sqlite3.connect(data_dir / "quiz.db") as conn:
        conn.execute("UPDATE questions SET played_at = datetime('now')")

    res = client.get(f"/api/packages/{pkg['id']}/export")
    assert res.status_code == 200
    assert "ზამთრის_თასი.json" in unquote(res.headers["content-disposition"])
    doc = res.json()
    assert doc["format"] == "ra-sad-rodis" and doc["version"] == 1
    assert doc["package"] == {"title": "ზამთრის თასი", "editor": "ნინო", "notes": "შენიშვნა"}
    assert [q["text"] for q in doc["questions"]] == ["მეორე კითხვა", "რომელ წელს?"]
    assert doc["questions"][1]["handout_image_data"].startswith("data:image/png;base64,")
    assert "played_at" not in doc["questions"][0] and "id" not in doc["questions"][0]

    (data_dir / "uploads" / image).unlink()  # the import must restore the image from the JSON alone
    imported = client.post("/api/packages/import", json=doc)
    assert imported.status_code == 201
    copy = imported.json()
    assert copy["id"] != pkg["id"] and copy["title"] == "ზამთრის თასი"
    assert (copy["question_count"], copy["played_count"]) == (2, 0)
    copied = client.get("/api/questions", params={"package_id": copy["id"]}).json()
    assert [q["text"] for q in copied] == ["მეორე კითხვა", "რომელ წელს?"]
    fields = ["tour", "number_label", "text", "spoken_override", "answer", "accepted", "not_accepted",
              "comment", "sources", "author", "handout_text", "handout_image", "content_hash"]
    assert {f: copied[1][f] for f in fields} == {f: first[f] for f in fields}
    assert client.get(f"/api/uploads/{image}").content == PNG
    # exporting the copy gives the same document
    assert client.get(f"/api/packages/{copy['id']}/export").json() == doc


def test_import_rejects_invalid_documents(client):
    good_question = {"text": "კ", "answer": "პ"}
    for doc in [
        {"package": {"title": "x"}, "questions": [good_question], "format": "other"},
        {"package": {"title": ""}, "questions": []},
        {"package": {"title": "x"}, "questions": [{"text": "კ"}]},
        {"package": {"title": "x"}, "questions": [good_question | {"handout_image_data": "data:image/png;base64,AAAA"}]},
    ]:
        assert client.post("/api/packages/import", json=doc).status_code == 422
    assert client.get("/api/packages").json() == []  # nothing half-imported
