# რა? სად? როდის? — წამყვანის პანელი

ლოკალური პროგრამა ინტელექტუალური თამაშის „რა? სად? როდის?“ წასაყვანად (ლეპტოპზე, ხშირად ტელევიზორთან ან პროექტორთან მიერთებულზე). პროგრამა კითხვებს **ნელა** კითხულობს ქართულად, ყველა რიცხვს სიტყვებით ამბობს („1921 წელს“ → „ათას ცხრაას ოცდაერთ წელს“), ითვლის დისკუსიის დროს და აჩვენებს პასუხს წყაროებით. კითხვები შეგიძლიათ ხელით შეიყვანოთ ან შემოიტანოთ Word / PDF / ტექსტური ფაილებიდან. ხელოვნური ინტელექტი არსად გამოიყენება: ფაილების დამუშავება და ტექსტის მომზადება ჩვეულებრივი წესებით ხდება.

*English version below.*

## რა გჭირდებათ

- Windows 10/11 (macOS/Linux-ზე — `start.sh`).
- Python 3.11, 3.12, 3.13 ან 3.14 (საუკეთესოა 3.12). უახლესი Python 3.15 ჯერ არ მუშაობს: PDF-ის წამკითხველის ერთ-ერთ ნაწილს მისთვის მზა ვერსია ჯერ არ აქვს.
- ინტერნეტი პირველი გაშვებისთვის (პაკეტების დაყენება) და ხმის მოსამზადებლად. თამაში ინტერნეტის გარეშეც შეიძლება, თუ აუდიო წინასწარ მოამზადეთ (იხ. ქვემოთ).

## დაყენება და გაშვება

1. გადმოწერეთ Python 3.12 საიტიდან [python.org](https://www.python.org/downloads/) (ძველი ვერსიები სიაშია გვერდის ქვემოთ) და დაყენებისას მონიშნეთ **„Add python.exe to PATH“**.
2. ორჯერ დააწკაპეთ **`start.bat`**. პირველ ჯერზე პროგრამა ქმნის `.venv` საქაღალდეს და აყენებს საჭირო პაკეტებს (რამდენიმე წუთი, საჭიროა ინტერნეტი). შემდეგ ბრაუზერში იხსნება `http://127.0.0.1:8000`.
3. გასაჩერებლად დახურეთ შავი ფანჯარა. თუ პროგრამა უკვე გაშვებულია, `start.bat` უბრალოდ ბრაუზერს გახსნის.

## ჩანართები

- **თამაში** — აირჩიეთ პაკეტი (თანმიმდევრობით ან არეულად, შეგიძლიათ გამოტოვოთ ნათამაშევი). ▶ წაკითხვა / 🔁 თავიდან წაკითხვა / პაუზა / შეჩერება, სიჩქარე; წაკითხული წინადადება ინიშნება, წინადადებაზე დაწკაპებით ის თავიდან იკითხება. ტაიმერი (60 / 30 / 20 წმ, +10 და +30 წმ — მუშაობს გაშვებულზე, პაუზაზე და 0-ის შემდეგაც), ხმოვანი სიგნალი 10 წამზე და ბოლოს. „პასუხის ჩვენება“ აჩვენებს პასუხს, ჩაითვლება / არ ჩაითვლება, კომენტარს, წყაროებს (ბმულები ახალ ჩანართში) და ავტორს; კითხვა ავტომატურად ინიშნება ნათამაშევად. ქვემოთ — „ანგარიში“ (მცოდნეები და ტელემაყურებლები 6 ქულამდე, ან გუნდები).
- **კითხვები** — პაკეტების შექმნა, სახელის შეცვლა, წაშლა; კითხვების დამატება და რედაქტირება (ტური, ნომერი, კითხვა, პასუხი, ჩაითვლება, არ ჩაითვლება, კომენტარი, წყაროები, ავტორი, დარიგება და მისი სურათი, „წასაკითხი ტექსტი“), ძებნა, ↑/↓ რიგის შეცვლა, „მოსმენა“. პაკეტის ექსპორტი და იმპორტი JSON ფაილით (სარეზერვო ასლი ან გაზიარება).
- **იმპორტი** — ჩააგდეთ .docx, .pdf ან .txt ფაილები (რამდენიმე ერთად). შენახვამდე ყველაფერს ნახავთ ცხრილში გაფრთხილებებით (პასუხი არ არის, ძალიან მოკლე/გრძელი ტექსტი, დუბლიკატი, ნუმერაციის გამოტოვება) და შეასწორებთ; რიგები შეიძლება წაშალოთ ან შემდეგთან გააერთიანოთ. შეინახეთ ახალ ან არსებულ პაკეტში.
- **პარამეტრები** — ხმის წყარო (Edge / Azure / ბრაუზერი), ხმა (ეკა ან გიორგი), სიჩქარე, რიცხვების დამატებითი შენელება, პაუზები, „ხმის ტესტი“; ტაიმერი და დამატებითი დრო, შრიფტის ზომა, თემა (მუქი / ღია); ოფლაინ თამაში და აუდიოს ქეში; გამოთქმის ლექსიკონი („დაწერილი → წასაკითხი“). ცვლილებები ავტომატურად ინახება.

## დოკუმენტის ფორმატი

ყველაზე საიმედოდ შემოდის ფაილი, სადაც ყოველ ველს თავისი ლეიბლი აქვს:

```
შეკითხვა 1.
კითხვის ტექსტი
პასუხი: პასუხი
ჩაითვლება: სხვა მისაღები ვარიანტები
არ ჩაითვლება: რა არ ჩაითვლება
კომენტარი: განმარტება, წყაროზე მითითება [1]
წყარო:
1. https://ka.wikipedia.org/wiki/...
ავტორი: სახელი გვარი
```

დანომრილი სიები და ცხრილებიც მიიღება. სრული აღწერა: [`docs/FORMAT_GUIDE_ka.md`](docs/FORMAT_GUIDE_ka.md). ნიმუში: `samples/sample_package.docx` (5 სადემონსტრაციო კითხვა; ერთი AcadNusx შრიფტით).

## ოფლაინ თამაშისთვის აუდიოს მომზადება

1. სანამ ინტერნეტი გაქვთ, გახსენით **პარამეტრები → ოფლაინ თამაში**.
2. აირჩიეთ პაკეტი და დააჭირეთ **„აუდიოს წინასწარ მომზადება“**. პროგრესი ზოლზე ჩანს (დაახლოებით 1–2 წამი ფრაგმენტზე).
3. როცა გამოჩნდება „მზადაა…“, ამ პაკეტით თამაში ინტერნეტის გარეშეც იმუშავებს.

თუ შემდეგ შეცვლით ხმას, სიჩქარეს, პაუზებს ან ლექსიკონს, მომზადება გაიმეორეთ (აუდიო ამ პარამეტრებზეა დამოკიდებული). აუდიო ინახება `data/audio` საქაღალდეში; ზომა და გასუფთავება — იმავე ბარათზე.

## კლავიშები (თამაშის ჩანართზე)

| კლავიში | მოქმედება |
|---|---|
| Space | ტაიმერის დაწყება / პაუზა |
| R | კითხვის თავიდან წაკითხვა |
| S | წაკითხვის შეჩერება |
| A | პასუხის ჩვენება / დამალვა |
| → / ← | შემდეგი / წინა კითხვა |
| + | დამატებითი დრო (მცირე ღილაკი) |
| F | სრული ეკრანი |
| ? | მალსახმობების სია |

ასოები ქართულ განლაგებაზეც მუშაობს. ტექსტის ველში წერისას მალსახმობები არ მოქმედებს.

## პრობლემების მოგვარება

- **ხმა არ ისმის.** შეამოწმეთ ინტერნეტი და დააჭირეთ „ხმის ტესტს“ პარამეტრებში. ნაგულისხმევი ხმა (Microsoft Edge-ის ონლაინ სერვისი) ინტერნეტს საჭიროებს; თუ ის არ მუშაობს, პროგრამა ცდილობს ბრაუზერის ქართულ ხმას — ის **Microsoft Edge** ბრაუზერს აქვს, Chrome-ს ჩვეულებრივ არა. ხმის გარეშეც შეიძლება თამაში: ტექსტი ეკრანზე რჩება. ოფიციალური ალტერნატივაა **Azure Speech**: პარამეტრებში აირჩიეთ Azure და შეიყვანეთ გასაღები და რეგიონი (მაგ. `westeurope`). ინტერნეტის გარეშე სათამაშოდ მოამზადეთ აუდიო წინასწარ.
- **PDF-დან არაფერი შემოდის („ტექსტური ფენა არ აქვს“).** ფაილი დასკანერებულია (სურათია). გამოიყენეთ Word-ის ორიგინალი ან PDF, რომელშიც ტექსტის მონიშვნა შეიძლება.
- **ტექსტი უცნაური ლათინური ასოებითაა (AcadNusx).** ძველი ქართული შრიფტი ავტომატურად ამოიცნობა; თუ ვერა, იმპორტის ჩანართზე ფაილთან ჩართეთ „ძველი ქართული შრიფტი (AcadNusx) → Unicode“.
- **.doc ფაილი არ მიიღება.** გახსენით Word-ში და შეინახეთ როგორც .docx („Save as“ → „Word Document“).
- **ფაილი არასწორად დაიყო კითხვებად.** შეასწორეთ ცხრილში (რიგების გაერთიანება / წაშლა) ან ფაილში დაამატეთ ლეიბლები „შეკითხვა“ და „პასუხი“ (იხ. ფორმატის აღწერა).
- **`start.bat` წერს, რომ Python ვერ იპოვა.** დააყენეთ Python 3.12 (ან 3.11–3.14) და მონიშნეთ „Add python.exe to PATH“, შემდეგ თავიდან გაუშვით. Python 3.15 ჯერ არ გამოდგება.
- **პორტი 8000 დაკავებულია.** ბრძანების ფანჯარაში: `set RSR_PORT=8080` და შემდეგ `start.bat`.

## მონაცემები და სარეზერვო ასლი

ყველაფერი ინახება `data` საქაღალდეში: `quiz.db` (პაკეტები, კითხვები, პარამეტრები), `audio` (აუდიოს ქეში), `uploads` (დარიგების სურათები). სარეზერვო ასლისთვის კითხვების ჩანართზე გააკეთეთ პაკეტის **ექსპორტი (JSON)** ან დააკოპირეთ მთელი `data` საქაღალდე.

---

# What? Where? When? — quiz host app (English)

A local app for hosting the Georgian intellectual quiz „რა? სად? როდის?“ from a laptop (often connected to a TV or projector). It reads questions aloud in Georgian **slowly**, speaks every number as Georgian words, runs the discussion timer and reveals answers with sources. Questions are typed in or imported from Word / PDF / text files. No AI is used anywhere: import and speech preparation are plain deterministic code. The interface is in Georgian.

## Requirements

- Windows 10/11 (`start.sh` on macOS/Linux).
- Python 3.11, 3.12, 3.13 or 3.14 (3.12 recommended). The newest Python, 3.15, doesn't work yet: one part the PDF reader needs has no build for it.
- Internet for the first start (installs packages) and for generating speech. Games can run offline once a package's audio has been prepared (see below).

## Install and start

1. Install Python 3.12 from [python.org](https://www.python.org/downloads/) (older versions are listed further down that page) and tick **"Add python.exe to PATH"**.
2. Double-click **`start.bat`**. The first run creates `.venv` and installs the requirements (a few minutes, needs internet), then opens `http://127.0.0.1:8000` in the browser.
3. Close the black console window to stop the app. If it is already running, `start.bat` just opens the browser.

## Tabs

- **თამაში (Play)** — pick a package (in order or shuffled, optionally skipping played questions); read / read again / pause / stop with a speed slider, the sentence being read is highlighted and clicking a sentence re-reads it; timer with 60 / 30 / 20 s presets and +10 / +30 s extra time (works while running, paused and after 0), a beep at 10 s and an end signal; "პასუხის ჩვენება" reveals the answer, accepted / not accepted variants, comment, sources (links open in a new tab) and author, and marks the question as played; a collapsible scoreboard (TV mode first to 6, or teams).
- **კითხვები (Questions)** — create, rename and delete packages; add and edit questions with all fields (tour, number, question, answer, accepted, not accepted, comment, sources, author, handout text and image, spoken-text override); search, reorder with ↑/↓, speech preview; JSON export and import of whole packages.
- **იმპორტი (Import)** — drop .docx, .pdf or .txt files (several at once); an editable preview table with warnings (no answer, very short or long text, duplicates, numbering gaps), delete or merge rows, then save into a new or an existing package.
- **პარამეტრები (Settings)** — speech provider (Edge / Azure / browser), voice (Eka or Giorgi), rate, extra slowdown for numbers, pauses, voice test; timer and extra-time values, font size, dark / light theme; offline audio and the audio cache; pronunciation dictionary ("written → spoken"). Changes save automatically.

## Document format

The most reliable input labels every field („შეკითხვა“, „პასუხი“, „ჩაითვლება“, „არ ჩაითვლება“, „კომენტარი“, „წყარო“, „ავტორი“; Russian labels are accepted too). Numbered lists and tables also work. Full description (in Georgian): [`docs/FORMAT_GUIDE_ka.md`](docs/FORMAT_GUIDE_ka.md). Sample: `samples/sample_package.docx` (5 demo questions, one typed in the legacy AcadNusx font).

## Preparing audio for offline games

1. While online, open **Settings → ოფლაინ თამაში**.
2. Pick the package and click **„აუდიოს წინასწარ მომზადება“**; a progress bar shows the progress (about 1–2 s per segment).
3. When it says „მზადაა…“, that package plays without internet.

Changing the voice, rate, pauses or dictionary afterwards means preparing again (the audio depends on them). Audio is stored in `data/audio`; the same card shows its size and clears it.

## Keyboard shortcuts (Play tab)

Space = timer start/pause, R = read again, S = stop speech, A = show/hide answer, → / ← = next/previous question, + = extra time, F = fullscreen, ? = shortcut list. Letters also work with the Georgian keyboard layout; shortcuts are ignored while typing in a field.

## Troubleshooting

- **No voice.** Check the internet connection and use „ხმის ტესტი“ in Settings. The default voice (Microsoft Edge's online read-aloud service) needs internet; if it fails the app tries the browser's Georgian voice, which **Microsoft Edge** has and Chrome usually doesn't. The game also works without speech (the text stays on screen). The official alternative is **Azure Speech**: choose Azure in Settings and enter your key and region (e.g. `westeurope`). For offline games, prepare the audio in advance.
- **Scanned PDF ("no text layer").** The PDF contains images of text. Use the original Word file or a PDF whose text can be selected.
- **Garbled Latin letters (AcadNusx).** The legacy Georgian font is detected automatically; if not, tick „ძველი ქართული შრიფტი (AcadNusx) → Unicode“ next to the file in the Import tab.
- **.doc files are rejected.** Open the file in Word and save it as .docx ("Save as" → "Word Document").
- **Questions split wrongly.** Fix it in the preview table (merge / delete rows) or add the „შეკითხვა“ and „პასუხი“ labels to the document (see the format guide).
- **`start.bat` can't find Python.** Install Python 3.12 (or 3.11–3.14) with "Add python.exe to PATH" ticked, then run it again. Python 3.15 doesn't work yet.
- **Port 8000 is busy.** In a command prompt: `set RSR_PORT=8080`, then `start.bat`.

## Data and backups

Everything lives in the `data` folder: `quiz.db` (packages, questions, settings), `audio` (speech cache), `uploads` (handout images). Back up with the package **JSON export** in the Questions tab, or copy the whole `data` folder.

## For developers

FastAPI + Uvicorn, SQLite (stdlib `sqlite3`), Pydantic; plain HTML/CSS/vanilla JS modules (no build step); `edge-tts`, optional Azure Speech REST; `python-docx` and `pymupdf` for import. Tests: `.venv\Scripts\python.exe -m pytest -q` (install `requirements-dev.txt` first). Debug a document's import with `python -m app.importer.dump <file>`. `CLAUDE.md` is the spec and `PROGRESS.md` records what was built, decisions and known issues.
