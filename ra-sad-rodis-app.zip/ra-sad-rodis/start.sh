#!/usr/bin/env sh
# Start the app on macOS/Linux: creates .venv on first run, reinstalls only when requirements.txt changes.
set -e
cd "$(dirname "$0")"

# Python 3.11-3.14, 3.12 first (3.15 has no PyMuPDF/onnxruntime build yet)
ok() { "$1" -c 'import sys; sys.exit(not (3, 11) <= sys.version_info[:2] <= (3, 14))' 2>/dev/null; }
PY="${PYTHON:-}"
if [ -z "$PY" ]; then
    for candidate in python3.12 python3.13 python3.14 python3.11 python3; do
        if command -v "$candidate" >/dev/null 2>&1 && ok "$candidate"; then PY="$candidate"; break; fi
    done
fi
if [ -z "$PY" ] || ! ok "$PY"; then
    echo "Python 3.11, 3.12, 3.13 or 3.14 was not found. Install Python 3.12 from https://www.python.org/downloads/"
    echo "(the newest Python, 3.15, does not work with this app yet)"
    exit 1
fi

[ -x .venv/bin/python ] || { echo "First start: creating the Python environment..."; "$PY" -m venv .venv; }

if ! cmp -s requirements.txt .venv/requirements.installed; then
    echo "Installing components, this can take a minute..."
    .venv/bin/python -m pip install --disable-pip-version-check -q -r requirements.txt
    cp requirements.txt .venv/requirements.installed
fi

exec .venv/bin/python run.py
