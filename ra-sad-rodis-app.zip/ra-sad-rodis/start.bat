@echo off
setlocal
cd /d "%~dp0"
title Ra? Sad? Rodis?

rem --- find Python 3.11-3.14 (3.12 first; 3.15 has no PyMuPDF/onnxruntime build yet) ---
set "PY="
for %%v in (3.12 3.13 3.14 3.11) do if not defined PY py -%%v -c "import sys" >nul 2>nul && set "PY=py -%%v"
if not defined PY python -c "import sys; sys.exit(not (3, 11) <= sys.version_info[:2] <= (3, 14))" >nul 2>nul && set "PY=python"
if not defined PY (
    echo.
    echo  Python 3.11, 3.12, 3.13 or 3.14 was not found.
    echo  Install Python 3.12 from https://www.python.org/downloads/
    echo  and tick "Add python.exe to PATH" during installation.
    echo  The newest Python, 3.15, does not work with this app yet.
    echo.
    pause
    exit /b 1
)

rem --- environment and components (installed again only when requirements.txt changes)
if not exist ".venv\Scripts\python.exe" (
    echo First start: creating the Python environment...
    %PY% -m venv .venv || goto :fail
)
fc /b requirements.txt ".venv\requirements.installed" >nul 2>nul || (
    echo Installing components, this can take a minute...
    ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -q -r requirements.txt || goto :fail
    copy /y requirements.txt ".venv\requirements.installed" >nul
)

".venv\Scripts\python.exe" run.py || goto :fail
exit /b 0

:fail
echo.
echo  Something went wrong - see the messages above.
pause
exit /b 1
