# Import spec (deterministic, no AI)

The host must be able to drop their own Word and PDF question packages into the app and get questions, answers and sources out of them **without any AI**. The parser is rule-based, its labels are configurable in `app/importer/labels.json`, and every result goes through an editable preview before it is saved.

## 1. Pipeline

```
file → reader → [Paragraph(text, style, is_heading, is_numbered, fonts, page)]
     → legacy-font conversion → cleanup → segmenter
     → [ParsedQuestion] + warnings → preview UI (edit) → commit to DB
```

`python -m app.importer.dump <file>` prints the paragraphs (with style / numbered / font info) and then the parsed questions. Use it for debugging instead of opening files directly.

## 2. Readers

**DOCX** (`python-docx`)
- Walk the body in document order, including tables (paragraphs inside cells).
- For each run keep its font name: `run.font.name`, else the `w:rFonts` attributes (`w:ascii`, `w:hAnsi`, `w:cs`), else the paragraph style's font.
- Keep heading styles (`Heading*`, `Title`) as `is_heading`.
- Auto-numbered paragraphs: python-docx does not render list numbers. Detect `w:numPr` in the paragraph properties and set `is_numbered=True`; the segmenter can use it as a question boundary.
- Record inline image relationship ids per paragraph (used later for handout images; extraction is optional).

**PDF** (`pymupdf`)
- `page.get_text("dict")`; sort blocks top-to-bottom, then left-to-right. Keep each span's font name.
- Join lines inside a block. Repair end-of-line hyphenation when both sides are Georgian letters (`საქარ-\nთველო` → `საქართველო`).
- Drop repeated headers and footers (same text on at least half of the pages) and lone page numbers.
- If the average extracted text is under 20 characters per page → error "PDF-ს არ აქვს ტექსტური ფენა (დასკანერებულია)". Encrypted PDF → its own error.

**TXT**: decode as utf-8-sig, then utf-16, then fail with a clear message. One line = one paragraph.

**.doc** (old Word): don't parse. Error asking the host to open it in Word and "Save as .docx".

## 3. Legacy Georgian fonts (AcadNusx and friends)

Many older Georgian documents were typed with fonts such as AcadNusx, AcadMtavr, LitNusx, LitMtavr. The file stores **Latin letters** that only look Georgian because of the font. Imported as-is they become nonsense like `saqarTvelo`.

Mapping (standard Georgian keyboard layout):

```
a→ა b→ბ g→გ d→დ e→ე v→ვ z→ზ T→თ i→ი k→კ l→ლ m→მ n→ნ o→ო p→პ J→ჟ r→რ s→ს
t→ტ u→უ f→ფ q→ქ R→ღ y→ყ S→შ C→ჩ c→ც Z→ძ w→წ W→ჭ x→ხ j→ჯ h→ჰ
```

- Convert only runs (DOCX) or spans (PDF) whose font name matches `/acad|lit[\s_-]?(nusx|mtavr)/i`. Digits and punctuation are unchanged.
- Other uppercase Latin letters inside those runs use the lowercase mapping (`A`→ა). Verify this against a real sample if one is available and note the result in PROGRESS.md.
- Fallback detection when font info is missing (for example a .txt file): a paragraph with no Georgian letters, more than 70% Latin letters, and at least two hits from fragments like `Svili`, `Tvel`, `ebi`, `aris`, `Si `, `ze ` → mark the file as "probably AcadNusx" and pre-check the per-file conversion toggle. The host confirms in the preview.
- Test: `saqarTvelo` → `საქართველო`, `Tbilisi` → `თბილისი`.

## 4. Cleanup

Unicode NFC; non-breaking space → space; remove soft hyphens (U+00AD) and zero-width characters; collapse repeated spaces; trim. Keep quotes and dashes as they are.

## 5. Labels (`app/importer/labels.json`, user-editable)

```json
{
  "question":     ["შეკითხვა", "კითხვა", "Вопрос", "Question"],
  "answer":       ["პასუხი", "Ответ", "Answer"],
  "not_accepted": ["არ ჩაითვლება", "Незачёт", "Not accepted"],
  "accepted":     ["ასევე ჩაითვლება", "ჩაითვლება", "ჩათვლა", "Зачёт", "Accepted"],
  "comment":      ["კომენტარი", "განმარტება", "Комментарий", "Comment"],
  "source":       ["წყაროები", "წყარო", "Источники", "Источник", "Sources", "Source"],
  "author":       ["ავტორები", "ავტორი", "Авторы", "Автор", "Authors", "Author"],
  "handout":      ["დარიგება", "ჰენდაუტი", "Раздаточный материал", "Handout"],
  "tour":         ["ტური", "რაუნდი", "Тур", "Round"],
  "editor":       ["რედაქტორი", "რედაქტორები", "Редактор", "Editor"]
}
```

- Match **longest label first** (so "არ ჩაითვლება" is never read as "ჩაითვლება").
- A label counts only at the start of a paragraph, case-insensitive, and only when followed by a number, `№`, `#`, punctuation (`: . ) - – —`) or the end of the paragraph. This prevents false hits on words like "პასუხისმგებლობა".
- Line pattern: `^\s*(LABEL)\s*(?:№|N|#)?\s*(\d+)?\s*[:.)\-–—]?\s*(.*)$`.
- A paragraph can contain several labels on separate lines (soft line breaks); split on `\n` first.

## 6. Segmenter (state machine)

- A **question** label (with or without a number) starts a new question; text after the label is the start of the question text.
- If the document has no question labels at all, start a new question at paragraphs that begin with `^\d{1,3}[.)]\s` or are auto-numbered (`is_numbered`), **only if** an answer label follows before the next such paragraph.
- Field labels switch the current field. Following unlabeled paragraphs are appended to the current field (joined with `\n`) until the next label.
- **tour** sets the tour for the questions that follow. **editor** sets package metadata.
- Text before the first question is the package header: title = first heading, else first non-empty line, else the file name.
- **Sources**: split into items by line, and by `; ` only when every part contains a URL. Remove leading `1.` / `1)` numbering. Detect URLs (`http(s)://…`, `www.…`), strip trailing punctuation from them, and store `{"text", "url"}`.
- **DOCX tables**: if a table's first row contains a question label and an answer label, each following row is one question, columns mapped by header label (unknown columns go to comment). Otherwise treat the cells as normal paragraphs.

Warnings per question (shown in the preview, never blocking):
- no answer; question text under 15 characters; question over 1500 or answer over 300 characters (possible merge of two questions);
- duplicate `content_hash` within the file or in the database;
- gap or repeat in the question numbering.

## 7. Fixtures and tests

Generate fixtures inside the tests (no binary files committed by hand):
- DOCX with `python-docx`; PDF with `pymupdf` `insert_text`/`insert_textbox` using a Georgian-capable font (`C:/Windows/Fonts/sylfaen.ttf` on Windows, or any Noto Sans Georgian file found); skip PDF tests with a clear reason if no such font exists.

Cases to cover:
1. Canonical labeled format (example below), several questions.
2. Numbered format without question labels (`1.` paragraphs and docx auto-numbering).
3. Two-column table format (კითხვა | პასუხი, plus extra columns).
4. AcadNusx runs mixed with Unicode runs in one paragraph.
5. Multi-paragraph comment and multiple sources with URLs.
6. Tour labels; package title and editor in the header.
7. "არ ჩაითვლება" and "ჩაითვლება" in the same question.
8. PDF with a two-line hyphenated word and a repeated footer.
9. Russian-label package (Вопрос / Ответ / Зачёт / Комментарий / Источник / Автор).

## 8. Canonical format (also goes into `docs/FORMAT_GUIDE_ka.md` and the sample package)

```
პაკეტის სახელი
რედაქტორი: ...

ტური 1

შეკითხვა 1.
<question text, may span several paragraphs>
პასუხი: <answer>
ჩაითვლება: <accepted variants>
არ ჩაითვლება: <not accepted>
კომენტარი: <explanation, may reference sources as [1]>
წყარო:
1. https://ka.wikipedia.org/wiki/...
2. <book title, page>
ავტორი: <name>

შეკითხვა 2.
...
```

`docs/FORMAT_GUIDE_ka.md` is a short guide in Georgian for hosts: the canonical layout above, the list of accepted labels, how to add a new label to `labels.json`, and tips (one label per line, don't put two questions in one paragraph, use .docx not .doc, PDFs must contain real text, not scans).
