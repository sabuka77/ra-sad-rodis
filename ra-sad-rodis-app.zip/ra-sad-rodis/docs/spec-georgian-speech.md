# Georgian speech spec

Goal: slow, clear Georgian reading in which **every number is spoken as correct Georgian words**. The TTS engine must never receive raw digits, Roman numerals or symbols like `%`, because it may read them digit by digit, in another language, or not at all.

All rules below are deterministic Python. Every example in the tables is a required pytest case.

## 1. Order of operations (per sentence)

1. Pronunciation dictionary (user-editable, longest match first, whole-word aware).
2. Times (`12:30`), ranges (`1914–1918`), numbers with case suffixes (`1921-ში`), ordinals (`მე-5`, `1-ლი`, `21-ე`), Roman numerals, numbers with units and symbols, plain numbers with the attributive rule.
3. Clean-up: collapse spaces, make sure no ASCII digits remain (log a warning if any do).

Seed dictionary (settings can add more):

| Written | Spoken |
|---|---|
| ე.წ. | ეგრეთ წოდებული |
| ა.შ. | ასე შემდეგ |
| ძვ. წ. | ძველი წელთაღრიცხვით |
| ჩვ. წ. | ჩვენი წელთაღრიცხვით |
| ქ. (before a word) | ქალაქი |
| № | ნომერი |
| § | პარაგრაფი |

## 2. Cardinal numbers

- 1–19: ერთი, ორი, სამი, ოთხი, ხუთი, ექვსი, შვიდი, რვა, ცხრა, ათი, თერთმეტი, თორმეტი, ცამეტი, თოთხმეტი, თხუთმეტი, თექვსმეტი, ჩვიდმეტი, თვრამეტი, ცხრამეტი. Zero: ნული.
- 20–99 are vigesimal: base ოც (20), ორმოც (40), სამოც (60), ოთხმოც (80). Remainder 0 → base + ი (ოცი). Otherwise base + და + word(remainder 1–19): 30 = ოცდაათი, 55 = ორმოცდათხუთმეტი.
- Hundreds: ას, ორას, სამას, ოთხას, ხუთას, ექვსას, შვიდას, რვაას, ცხრაას. Remainder 0 → + ი (ორასი). Otherwise prefix + space + word(remainder): ას ერთი.
- Thousands: count 1 → ათას…; count > 1 → full word of the count + " ათას…" (ორი ათასი). Remainder 0 → ათასი, otherwise ათას + space + word(remainder).
- Millions / billions: მილიონი / მილიარდი, same pattern (non-final element truncated: მილიონ, მილიარდ).
- Only the **last** word of a compound number is ever inflected.
- Decimal separator: `,` or `.` → "მთელი" + fraction word: 1 digit → მეათედი, 2 → მეასედი, 3 → მეათასედი.
- Thousands separators: a space, or a comma when the token matches `^\d{1,3}(,\d{3})+$` (so `1,500` = 1500, but `1,5` = 1.5).
- Leading zero (`007`) → digit by digit: ნული ნული შვიდი.
- `-5` is "მინუს ხუთი" only when the minus sign is at the start or after a space and is not between two numbers.

| Input | Expected |
|---|---|
| 0 | ნული |
| 7 | შვიდი |
| 15 | თხუთმეტი |
| 20 | ოცი |
| 21 | ოცდაერთი |
| 30 | ოცდაათი |
| 37 | ოცდაჩვიდმეტი |
| 40 | ორმოცი |
| 55 | ორმოცდათხუთმეტი |
| 68 | სამოცდარვა |
| 80 | ოთხმოცი |
| 99 | ოთხმოცდაცხრამეტი |
| 100 | ასი |
| 101 | ას ერთი |
| 200 | ორასი |
| 345 | სამას ორმოცდახუთი |
| 800 | რვაასი |
| 1000 | ათასი |
| 1001 | ათას ერთი |
| 1921 | ათას ცხრაას ოცდაერთი |
| 2000 | ორი ათასი |
| 2024 | ორი ათას ოცდაოთხი |
| 15 000 | თხუთმეტი ათასი |
| 1 000 000 | მილიონი |
| 2 500 000 | ორი მილიონ ხუთასი ათასი |
| 3,5 | სამი მთელი ხუთი მეათედი |
| 0.25 | ნული მთელი ოცდახუთი მეასედი |
| 007 | ნული ნული შვიდი |

## 3. Inflection

### 3a. Hyphenated case suffixes (`1921-ში`)

Let `W` be the last word of the number. Join rules:

| Suffix type | Rule | Examples |
|---|---|---|
| -ში, -ზე, -ს, -ჯერ | drop final ი of W (W ending in ა stays) then append | 1921-ში → …ოცდაერთში; 8-ში → რვაში; 3-ჯერ → სამჯერ |
| -თან | drop final ი of W then append; W ending in a vowel (ა, ე) takes the dative ს first | 5-თან → ხუთთან; 8-თან → რვასთან |
| -ის, -ით, -იანი/-იან | drop final ი **or** ა, then append | 1921-ის → …ოცდაერთის; 8-ის → რვის; 10-ით → ათით; 8-იანი → რვიანი |
| -დან | drop final ი or ა, append იდან | 1918-დან → …თვრამეტიდან; 9-დან → ცხრიდან |
| -მდე | W ending in ი: replace ი with ამდე; W ending in ა: append მდე | 1945-მდე → …ორმოცდახუთამდე; 8-მდე → რვამდე |
| -მა | drop final ი and append მა; W ending in ა → append მ | 5-მა → ხუთმა; 8-მა → რვამ |

| Input | Expected |
|---|---|
| 1921-ში | ათას ცხრაას ოცდაერთში |
| 1921-ის | ათას ცხრაას ოცდაერთის |
| 1918-დან 1921-მდე | ათას ცხრაას თვრამეტიდან ათას ცხრაას ოცდაერთამდე |
| 8-ის | რვის |
| 9-დან | ცხრიდან |
| 10-ით | ათით |
| 5-მა | ხუთმა |
| 8-მა | რვამ |
| 8-თან | რვასთან |
| 8-იანი | რვიანი |
| 3-ჯერ | სამჯერ |
| 1990-იან წლებში | ათას ცხრაას ოთხმოცდაათიან წლებში |
| 1990-იანი | ათას ცხრაას ოთხმოცდაათიანი |

The -თან and -იანი rules and the ა-final attributive form in §3b (რვასთან, რვიანი, რვა კაცმა) were confirmed by the host on 2026-10-31.

### 3b. Number before a noun (attributive form)

Look at the next word `N` (Georgian letters only):

- `N` ends in ში, ზე, თან, მდე, ად, or ends in ს but **not** ის → dative/adverbial → **truncated**: drop the final ი of W (ა-final stays).
- `N` ends in მა with a consonant before მ → ergative → W loses ი and gets მა (W ending in ა stays: რვა კაცმა). A vowel-stem noun in the ergative ends in a vowel + მ (ძმამ, ქვეყანამ) and counts as ergative too (added in Phase 7).
- Otherwise (nominative, genitive -ის, instrumental -ით, -დან, -გან, -თვის, -კენ, end of sentence, punctuation) → full form.
- `წ.` right after a number is read as "წელს" (so the number is truncated).

| Input | Expected |
|---|---|
| 1921 წელს | ათას ცხრაას ოცდაერთ წელს |
| 1921 წ. | ათას ცხრაას ოცდაერთ წელს |
| 1921 წლის 25 თებერვალს | ათას ცხრაას ოცდაერთი წლის ოცდახუთ თებერვალს |
| 5 წლის | ხუთი წლის |
| 5 კაცმა | ხუთმა კაცმა |
| 8 კაცმა | რვა კაცმა |
| 5 წუთში | ხუთ წუთში |
| 12 საათზე | თორმეტ საათზე |
| 8 წელს | რვა წელს |
| 3 დღით | სამი დღით |
| 2 ძმა | ორი ძმა |
| 100 კილომეტრამდე | ას კილომეტრამდე |
| 3 ძმამ | სამმა ძმამ |
| 10 ქვეყანამ | ათმა ქვეყანამ |

## 4. Ordinals and Roman numerals

Ordinal of W: 1 → პირველი (special). Otherwise მე + (W without final ი or ა) + ე. In a "…და…" compound the მე goes after და (ოცდამეერთე). Before an ordinal case suffix starting with ი, drop the final ე (მეოცე + ის → მეოცის).

Triggers: `მე-N`, `N-ე`, `1-ლი`, Roman numerals before საუკუნე / ს. / სს., and Roman numerals right after a Georgian word (monarchs: დავით IV). A single-letter Roman numeral counts only for I, V, X (so "ვიტამინი C" and "ვიტამინი D" stay unchanged and are passed through the dictionary).

| Input | Expected |
|---|---|
| 1-ლი | პირველი |
| მე-2 | მეორე |
| მე-5 | მეხუთე |
| მე-8 | მერვე |
| მე-9 | მეცხრე |
| მე-11 | მეთერთმეტე |
| მე-20 | მეოცე |
| 21-ე | ოცდამეერთე |
| 40-ე | მეორმოცე |
| მე-100 | მეასე |
| XIX საუკუნე | მეცხრამეტე საუკუნე |
| XX ს. | მეოცე საუკუნე |
| V–VI სს. | მეხუთე–მეექვსე საუკუნეები |
| დავით IV | დავით მეოთხე |
| ლუი XIV-ის | ლუი მეთოთხმეტის |

## 5. Units, symbols, times, ranges

- `%` → პროცენტი; `°C` → გრადუსი ცელსიუსით; `$` → დოლარი; `€` → ევრო; `₾` → ლარი; `კმ` → კილომეტრი; `მ` (after a number) → მეტრი; `სმ` → სანტიმეტრი; `მმ` → მილიმეტრი; `კგ` → კილოგრამი; `ტ` (after a number) → ტონა; `ლ` (after a number) → ლიტრი. Units are recognised attached or separated by a space (`5კმ`, `5 კმ`). Currency symbols may precede the number (`$100` → ასი დოლარი).
- `HH:MM` → "<H> საათი და <M> წუთი" (":00" → "<H> საათი").
- Range `A–B` or `A-B` between two numbers → "A–B" with a short pause; B follows the attributive rule for the next word.

| Input | Expected |
|---|---|
| 75% | სამოცდათხუთმეტი პროცენტი |
| 5 კმ | ხუთი კილომეტრი |
| 100₾ | ასი ლარი |
| $100 | ასი დოლარი |
| 12:30 | თორმეტი საათი და ოცდაათი წუთი |
| 1914–1918 წლებში | ათას ცხრაას თოთხმეტი – ათას ცხრაას თვრამეტ წლებში |

## 6. Segmentation and highlighting

- Split the **original** text into sentences on `.`, `!`, `?`, `…` followed by whitespace, but not after known abbreviations (dictionary keys, single Georgian letter + dot, `ს.`, `წ.` followed by a lowercase continuation). `;` and `:` give a shorter pause (half the sentence gap). Keep `(start, end)` character offsets of each sentence in the original text.
- Normalize each sentence separately.
- With "number emphasis" on, each expanded number together with its following unit or noun becomes its own sub-segment with `is_number: true` (slower rate, pause before and after). All sub-segments keep the offsets of their parent sentence, so the UI highlights the whole sentence.
- `POST /api/tts/prepare {text | question_id, field: "text" | "answer"}` → `{segments: [{i, spoken, start, end, is_number, pause_after_ms, url}]}`. `url` points to `GET /api/tts/audio/{key}.mp3`, which synthesizes on first request and serves from cache afterwards, so playback can start before every segment exists.

## 7. Providers

Interface: `async synthesize(text, voice, rate_pct) -> bytes (mp3)`.

- **edge** (default): `edge_tts.Communicate(text, voice, rate="-25%")`, collect the audio chunks. No API key. Needs internet. It uses Microsoft's Edge read-aloud service, which is unofficial and can change, which is why the interface and fallbacks exist. Concurrency limit 3, 2 retries, 20 s timeout.
- **azure** (optional, official): `POST https://{region}.tts.speech.microsoft.com/cognitiveservices/v1`, headers `Ocp-Apim-Subscription-Key`, `Content-Type: application/ssml+xml`, `X-Microsoft-OutputFormat: audio-24khz-48kbitrate-mono-mp3`, body `<speak version="1.0" xml:lang="ka-GE"><voice name="ka-GE-EkaNeural"><prosody rate="-25%">…</prosody></voice></speak>` with XML-escaped text. Never log the key.
- **browser** (frontend only): `speechSynthesis.getVoices()`, pick a voice whose `lang` starts with `ka` (Microsoft Edge has Georgian online voices; Chrome usually has none), `rate = 1 + rate_pct/100`, one utterance per segment with the same gaps. If no Georgian voice exists, show a clear Georgian message; the game still works without speech.
- Fallback order when synthesis fails: chosen provider → edge → browser.
- Cache key: sha1 of `provider|voice|rate|spoken_text`. Show cache size in settings; allow clearing it.
