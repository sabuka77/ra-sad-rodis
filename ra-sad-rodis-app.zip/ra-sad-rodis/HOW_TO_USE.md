# How to use this kit (≈ $130 Claude budget)

This kit is the "project prompt" for building the რა? სად? როდის? host app with Claude Code.

| File | Role |
|---|---|
| `CLAUDE.md` | The project spec. Claude Code loads it automatically into the context window of every session in this folder. |
| `docs/spec-georgian-speech.md` | Slow reading, number-to-Georgian-words rules and test tables. Read only in phases 2, 3 and 6. |
| `docs/spec-import.md` | Word/PDF parsing rules (no AI), legacy AcadNusx fonts, labels. Read only in phase 5. |
| `HOW_TO_USE.md` | This file: setup, budget plan, and the prompt to paste for each phase. |

The specs are split so each session loads only what it needs. A smaller context per turn means a lower cost.

## 1. Before you start

1. Install **Python 3.11+** from python.org (tick "Add python.exe to PATH").
2. Create an empty folder, for example `C:\Projects\ra-sad-rodis`, and copy this kit's files into it.
3. Optional, but it makes the importer fit **your** files: put 2–3 typical question documents (.docx / .pdf) in `samples\real\`. Short excerpts are enough.
4. **Check the Georgian test tables** in `docs/spec-georgian-speech.md` (sections 2–5) before phase 2. They define how numbers are spoken. You're the native speaker: fix any row that sounds wrong to you, since Claude will treat them as the truth.
5. Open Claude Code in that folder. Use **Claude Opus 5.5**. If you can set effort, use **high** for phases 2, 3 and 5 and **medium** for the rest.

## 2. Budget plan

Pricing basis (Claude Opus 5.5, per million tokens): $4 input, $20 output, $0.20 for cached input. In an agentic session most tokens are cached re-reads of the context, so output tokens and fix cycles drive the cost.

| Phase | What gets built | Estimate | Running total |
|---|---|---|---|
| 0 | Skeleton, start.bat, tabs, database, settings | $6 | $6 |
| 1 | Questions tab: manual entry & editing, packages, JSON backup | $10 | $16 |
| 2 | Georgian number & text normalizer + tests | $14 | $30 |
| 3 | Text-to-speech, cache, player (read / read again / speed) | $16 | $46 |
| 4 | Play tab: timer + extra time, answer reveal, sources, shortcuts | $16 | $62 |
| 5 | Word/PDF import with preview, AcadNusx, format guide | $22 | $84 |
| 6 | Scoreboard, offline pre-generation, Azure fallback, dictionary | $12 | $96 |
| 7 | QA walkthrough, bug fixes, README | $12 | $108 |
| — | **Reserve** for bugs and changes you ask for | $22 | **$130** |

These are estimates (±50%). Real cost depends mostly on how many fix rounds a phase needs.

Rules that keep you on budget:
- **One phase = one fresh session** (start a new conversation, or `/clear`, before each phase). The context grows within a session, so long sessions get expensive.
- Check your spend after each phase. If a phase passes ~1.5× its estimate, stop it and start a new session with a narrow bug-fix prompt (section 4).
- Don't paste whole documents into the chat. Put files in `samples\real\` and let Claude inspect them with the project's extractor.
- Cheaper option: run phases 0, 1, 6 and 7 on **Claude Sonnet 5.5** ($2 / $10 per million tokens). That saves roughly $15–20 to spend on extras.

## 3. Phase prompts (paste one per session)

### Phase 0 — Skeleton
```
Read CLAUDE.md. Do Phase 0 only.
- Create the folder layout from CLAUDE.md, requirements.txt with pinned versions, .gitignore (data/, .venv/), start.bat and start.sh (create .venv if missing, install requirements quietly, run uvicorn app.main:app on 127.0.0.1:8000, open the browser).
- FastAPI app serving index.html: title "რა? სად? როდის?", four tabs (თამაში, კითხვები, იმპორტი, პარამეტრები) switching client-side, dark projector-friendly theme, Georgian font stack ("Noto Sans Georgian", "BPG Arial", "Segoe UI", Sylfaen, sans-serif).
- db.py creates the schema on startup (idempotent). GET/PUT /api/settings with the defaults from CLAUDE.md.
- Every UI string goes in app/static/i18n/ka.json.
- PROGRESS.md with phases 0–7 as checkboxes plus sections: decisions, known issues.
Done when: start.bat launches the app, tabs switch, GET /api/settings returns the defaults, and a pytest smoke test passes. Then stop and summarize in ≤10 lines.
```

### Phase 1 — Questions tab (manual entry)
```
Read CLAUDE.md and PROGRESS.md. Do Phase 1 only: packages and questions CRUD.
- REST: /api/packages (list, create, rename, delete with its questions) and /api/questions (list with ?package_id and ?q, get, create, update, delete, reorder, reset played). JSON export of a package and JSON import as a new package.
- Questions tab UI as in CLAUDE.md §4. "მოსმენა" (speech preview) belongs to Phase 3: show it disabled for now. Sources are repeatable rows (text + optional URL). Handout images are stored in data/uploads.
- Question and answer are required; compute content_hash on save and warn about duplicates.
Done when: I can create a package, add/edit/delete/reorder questions, export JSON and re-import it as a copy. API tests cover CRUD and the export/import round trip. Then stop and summarize in ≤10 lines.
```

### Phase 2 — Georgian speech normalizer
```
Read CLAUDE.md and docs/spec-georgian-speech.md sections 1–6. Do Phase 2 only (pure Python, no audio yet).
- app/speech/numbers_ka.py: cardinals, decimals, ordinals, hyphenated case suffixes, attributive forms.
- app/speech/normalize_ka.py: dictionary, units and symbols, Roman numerals, times, ranges, leading zeros.
- app/speech/segments.py: sentence split on the ORIGINAL text with character offsets, per-sentence normalization, number sub-segments with is_number.
- Turn EVERY row of the spec tables into a parametrized pytest case. Add a sweep test: every integer 0–1,000,000 converts with no digits left in the output.
- Expose GET /api/speech/preview?text=... returning {spoken, segments}.
- If you think an expected value is linguistically wrong, keep the test, mark it xfail with a reason, and list it in PROGRESS.md for me.
Done when: all tests pass or are explicitly listed as xfail. Then stop and summarize in ≤10 lines.
```

### Phase 3 — Text-to-speech and player
```
Read CLAUDE.md, PROGRESS.md and docs/spec-georgian-speech.md sections 6–7. Do Phase 3 only.
- Provider interface + edge-tts provider (ka-GE-EkaNeural / ka-GE-GiorgiNeural, rate string like "-25%"), disk cache, POST /api/tts/prepare, GET /api/tts/audio/{key}.mp3 (lazy synthesis, concurrency limit 3, 2 retries, 20 s timeout), clear-cache endpoint.
- Frontend player module: plays the segment list with the configured gaps, number segments slower, highlights the current sentence, clicking a sentence replays it. Buttons: წაკითხვა, თავიდან წაკითხვა (restart from the beginning), pause/resume, stop, speed slider. Preload all segments of the current question.
- Browser Web Speech fallback when the server reports a provider failure (voice whose lang starts with "ka"; if none, show a clear Georgian message).
- Settings tab: voice, rate, number slowdown, pauses, number emphasis, "ხმის ტესტი" with a sentence containing a year, a date, a percentage and an ordinal.
- Enable "მოსმენა" in the Questions tab.
Done when: with internet, the test sentence is read slowly in Georgian with every number spoken as words; the second play is instant from cache; unit tests for the cache key and a mocked provider pass. Then stop and summarize in ≤10 lines.
```

### Phase 4 — Play tab
```
Read CLAUDE.md and PROGRESS.md. Do Phase 4 only: the Play tab (CLAUDE.md §1).
- Package picker, in order / shuffled / skip played, N / total, prev / next / jump, auto-mark played when the answer is revealed.
- Timer module: remaining time from performance.now() (never decrement per tick); start/pause/reset; presets 60/30/20; +10 / +30 extra time (configurable) working while running, paused and after 0; 10-second warning beep and end signal via Web Audio (resume the AudioContext on first click); colour states; optional auto-start after reading.
- Answer panel hidden until "პასუხის ჩვენება": answer, ჩაითვლება, არ ჩაითვლება, comment with [n] links to sources, numbered clickable sources, author, 🔊 read answer, hide again.
- Keyboard shortcuts with a "?" cheat sheet, fullscreen, A−/A+ font size (remembered), prefetch the next question's audio.
Done when: a full question cycle works with mouse only and with keyboard only, and the timer stays accurate after switching browser tabs. Give me a numbered manual test checklist (≤12 steps) for this tab. Then stop and summarize in ≤10 lines.
```

### Phase 5 — Word / PDF import
```
Read CLAUDE.md, PROGRESS.md and docs/spec-import.md. Do Phase 5 only.
- Readers (docx, pdf, txt), legacy-font conversion, cleanup, segmenter driven by app/importer/labels.json, warnings, and the `python -m app.importer.dump <file>` debug CLI.
- POST /api/import/parse (multipart, several files) returns a preview with no database writes; POST /api/import/commit saves it.
- Import tab UI: drop zone, per-file status and AcadNusx toggle, editable preview table with warnings, delete / merge-with-next rows, target package (new or existing), save.
- scripts/make_sample.py creates samples/sample_package.docx (5 demo questions in the canonical format, one of them typed in AcadNusx to exercise conversion; mark them clearly as demo content) and write docs/FORMAT_GUIDE_ka.md.
- Fixture-based tests for every case listed in the spec.
- If samples/real/ contains files: dump each one (read ≤150 lines of output per file), make the segmenter handle its layout, and add a short regression fixture per layout. Report any document you couldn't parse cleanly and why.
Done when: sample_package.docx and every file in samples/real/ import with zero errors and only expected warnings, and the tests pass. Then stop and summarize in ≤10 lines.
```

### Phase 6 — Scoreboard, offline mode, fallbacks
```
Read CLAUDE.md, PROGRESS.md and docs/spec-georgian-speech.md section 7. Do Phase 6 only.
- Scoreboard (TV mode first to 6; teams mode with per-question ticks and totals).
- "Pre-generate audio for package" as a background task with a progress endpoint and progress bar; cache size display; clear cache.
- Azure provider (REST + SSML prosody, key and region in settings, never logged), provider selector, automatic fallback chain: chosen → edge → browser.
- Pronunciation dictionary editor in Settings (add / edit / delete rows, applied immediately in previews).
Done when: a package can be pre-generated and then played with the network disconnected, and dictionary edits change the spoken preview. Then stop and summarize in ≤10 lines.
```

### Phase 7 — QA and polish
```
Read CLAUDE.md and PROGRESS.md. Do Phase 7: a quality pass, no new features.
- Run the whole test suite and fix failures.
- Walk through: import the sample → play 3 questions with timer and extra time → reveal answers → edit a question → read again → scoreboard. If you have browser tools, use them; otherwise give me a numbered manual checklist and wait for my results.
- Check projector readability (contrast, font sizes, buttons at least 48px tall), consistent Georgian wording, no browser console errors.
- README.md in Georgian first, then English: install Python, double-click start.bat, document format, preparing audio for offline games, troubleshooting (no voice, scanned PDF, AcadNusx, .doc files).
Done when: tests are green, the README is complete, and PROGRESS.md marks every phase done with known limitations listed. Then stop and summarize in ≤10 lines.
```

## 4. Prompts for fixes and changes (use the reserve)

Bug fix:
```
Bug: [what I did] → [what happened] → [what I expected].
[paste the error text or browser console output, if any]
Fix it with the smallest change, add a regression test if it's backend logic, don't refactor unrelated code, and update PROGRESS.md.
```

Wrong pronunciation:
```
Pronunciation: "[written text]" is spoken as "[what I hear]" but should be "[correct Georgian]".
Add it as a test row in docs/spec-georgian-speech.md and a pytest case, then fix the rule (or add a dictionary entry if it's a one-off).
```

Document that imports badly:
```
Import problem: I put [file name] in samples/real/. [what went wrong in the preview]
Dump it with the extractor (≤150 lines), adjust the segmenter or labels.json, add a regression fixture.
```

## 5. Optional extras if the reserve is left over

| Extra | Rough cost |
|---|---|
| Audience window for the projector (question + timer only) synced with the host window via BroadcastChannel | $8 |
| Handout images extracted automatically from .docx | $6 |
| Windows .exe with PyInstaller (no Python install needed) | $6 |
| Fully offline voice with Piper (first check that a Georgian voice, "natia", is in the rhasspy/piper-voices catalog) | $10 |
| Automatic .doc → .docx conversion when LibreOffice is installed | $4 |

## 6. Without Claude Code (claude.ai Projects)

Paste `CLAUDE.md` into the Project instructions and upload the two `docs/*.md` files as project knowledge, then use the same phase prompts. You'll have to create the files and run the tests yourself, so Claude Code is the better fit for this budget.
