# Progress

## Phases

- [x] 0. Skeleton: layout, requirements, start scripts, FastAPI serving the Georgian tab shell, SQLite schema, settings API
- [x] 1. Questions tab: packages and questions CRUD, JSON export/import
- [x] 2. Georgian speech normalizer with exhaustive tests
- [x] 3. TTS: provider interface, edge-tts, cache, endpoints, frontend player, voice settings, speech preview
- [x] 4. Play tab: question flow, timer with extra time, answer reveal with sources, shortcuts, fullscreen, prefetch
- [x] 5. Import: docx/pdf/txt readers, AcadNusx conversion, segmenter, preview/edit UI, sample package, format guide
- [x] 6. Scoreboard, offline pre-generation, Azure provider and fallbacks, pronunciation dictionary editor
- [x] 7. QA and polish, README

## Known limitations (summary for the host)

- Speech needs internet unless a package's audio was prepared in advance (Settings → ოფლაინ თამაში). The default voice uses Microsoft Edge's unofficial read-aloud service; Azure Speech (needs a key) is the official alternative, and the browser's Georgian voice (Microsoft Edge only) is the last resort.
- The three disputed number rules use the app's forms (host decision, 2026-10-31): „რვა კაცმა“, „რვასთან“, „რვიანი“. The spec and tests say so; no xfail tests remain.
- Dates (`25.02`, `2024-10-31`), scores (`1:2`) and times with a case suffix (`10:30-ზე`) are read without a dedicated rule, so they can sound unnatural.
- Import is tuned to the canonical format in `docs/FORMAT_GUIDE_ka.md` only: `samples/real/` was empty. Two-column PDFs mix their columns, handout images are not taken from documents, and the AcadNusx capital-letter mapping was not checked against a real AcadNusx document.
- Python: 3.11–3.14 work (3.12 recommended). The newest Python, 3.15, can't install the requirements yet: PyMuPDF 2.0 depends on `onnxruntime`, which has no 3.15 build. The start scripts pick a compatible version and explain this if only 3.15 is installed.
- Not checked on real hardware: the timer beeps (the browser pane can't play sound to us), fullscreen, a real Azure key, a real Georgian browser voice, an actual network unplug.

## Phase 0 — what exists

- `run.py` starts Uvicorn on 127.0.0.1:8000 and opens the browser once the port answers; if the port is already taken it just opens the browser. Overrides: `RSR_HOST`, `RSR_PORT`, `RSR_NO_BROWSER=1`.
- `start.bat` / `start.sh`: find Python 3.11+, create `.venv`, reinstall requirements only when `requirements.txt` changed (copy kept in `.venv/requirements.installed`), then run `run.py`.
- `app/db.py`: schema from CLAUDE.md (created on startup, idempotent), `get_conn()` context manager, settings load/save/clear. `RSR_DATA_DIR` overrides the data folder (tests use it).
- `app/models.py`: `Settings` with all defaults from CLAUDE.md (speech, timer, display), `extra="forbid"`.
- API: `GET /api/settings`, `PUT /api/settings` (partial update, 422 on invalid or unknown keys), `POST /api/settings/reset`.
- Frontend: `index.html` with four tabs (hash routing `#play` `#questions` `#import` `#settings`, arrow keys move between tabs), `i18n.js` (`data-i18n` / `data-i18n-aria`), `api.js` fetch wrapper, `settings.js` (applies theme and question font size; read-only summary in the Settings tab).
- Tests: `tests/test_smoke.py` (index, static assets, every `data-i18n` key exists in ka.json, schema, settings defaults / partial update / validation / reset / corrupt stored value).

## Phase 0 — verified

- `pytest`: 19 passed (run with `.venv\Scripts\python.exe -m pytest -q`; install test tools once with `pip install -r requirements-dev.txt`).
- Browser: tabs switch by click, by arrow keys and by URL hash; Settings tab shows the defaults; light theme and question font size from settings apply after reload; no console errors.
- `start.bat`: on a fresh PATH it found Python 3.12, installed requirements, started the server and answered `/api/settings`; a second start skipped the install; launching while the app is already running prints a message and exits 0.

## Phase 1 — what exists

- API `app/routers/packages.py`: `GET/POST /api/packages` (list with `question_count` / `played_count`), `PATCH /api/packages/{id}` (rename; fields left out are kept), `DELETE` (questions cascade, unused images deleted), `POST /{id}/reset-played`, `GET /{id}/export` (JSON attachment), `POST /api/packages/import` (always a new package).
- API `app/routers/questions.py`: `GET /api/questions?package_id=&q=` (search over question and answer text, case-insensitive via Python `casefold` registered in SQLite), `GET/PUT/DELETE /{id}`, `POST` (appends at the end of the package), `POST /{id}/move {"direction": "up"|"down"}` (swap with neighbour, renumber 1..n), `POST /{id}/reset-played`. Save responses carry `duplicates` (same `content_hash`, any package).
- API `app/routers/uploads.py`: `POST /api/uploads` (multipart; PNG/JPG/GIF/WEBP recognised by magic bytes, ≤10 MB) → `{"name": "<sha1>.<ext>"}`; `GET /api/uploads/{name}`.
- `app/db.py` helpers reusable by the Phase 5 importer: `content_hash`, `insert_question`, `update_question`, `get_question`, `find_duplicates`, `question_from_row`. Models in `app/models.py` (`QuestionIn`, `Question`, `QuestionSaved`, `Package`, `PackageExport`, …).
- Frontend: `questions.js` (package toolbar, list, search, ↑/↓, played badge with ↺), `editor.js` (form, sources rows, handout image, save / save and new / duplicate / delete), `dialog.js` (in-page confirm and name prompt). `i18n.js` now fills `{name}` placeholders and supports `data-i18n-placeholder` / `data-i18n-title`.
- Tests: `tests/test_questions.py`, `tests/test_packages.py` (CRUD, validation, search, move, reset played, duplicates, uploads and cleanup, export → import round trip incl. embedded image and order).

## Phase 1 — verified

- `pytest`: 47 passed.
- Browser pane (1366×900, scratch data folder, not `data/quiz.db`): created a package, added two questions with save-and-new (tour carried over, number prefilled), required-field error, duplicate warning with a link to the other question, edit, unsaved-changes prompt, ↑ reorder, played badge + ↺ reset, search across packages, handout image upload and preview, JSON export re-imported as „… (ასლი)“, rename, delete question, delete package (its image file removed). No console errors. Phone width: no horizontal scroll.

## Phase 2 — what exists

- `app/speech/numbers_ka.py`: cardinals up to 999 999 999 999 (0–999 precomputed), digit-by-digit reading, decimals (მთელი + მეათედი/მეასედი/მეათასედი), ordinal words, and last-word inflection: `truncate` (dative attributive), `ergative`, `attach_suffix` (hyphenated case suffixes), `attributive(words, next_word)`.
- `app/speech/normalize_ka.py`: `normalize(text, dictionary)` / `normalize_marked()` (expanded numbers wrapped in private-use markers U+E000…U+E001). Passes: dictionary (seed + settings, longest match first, whole-word, `ე.წ.` also matches `ე. წ.`) → unit symbols → times → Roman centuries / Roman after a Georgian word → ordinals → ranges → case suffixes → plain numbers (attributive rule, `წ.` → წელს, minus) → clean-up (digits left → warning + digit-by-digit fallback).
- `app/speech/segments.py`: `split_sentences(text, dictionary)` → `(start, end)` offsets in the original text; `build_segments(...)` → list of `Segment(spoken, start, end, is_number, pause_after_ms)` with `.to_dict()`; `spoken_text(segments)`.
- API `GET /api/speech/preview?text=` (≤20 000 chars) → `{spoken, segments}`, using the settings dictionary, number emphasis and pause settings (`app/routers/speech.py`).
- Tests: `tests/test_numbers_ka.py`, `tests/test_normalize_ka.py` (every row of every spec table, the §3a rule-column examples, extra rule cases), `tests/test_segments.py`. Sweep: every integer 0–1,000,000 through `cardinal()` (≈2 s) plus every 997th through the full normalizer.

## Phase 2 — verified

- `pytest`: 197 passed, 3 xfailed (three spec rules that looked linguistically wrong — see "Decided by the host").
- No browser check needed (no UI in this phase); the preview endpoint is covered by TestClient tests.

## Phase 3 — what exists

- `app/speech/providers/`: `base.py` (`TTSProvider` protocol `async synthesize(text, voice, rate_pct) -> bytes`, `ProviderError`, `rate_string(-25) → "-25%"`), `edge.py` (`edge_tts.Communicate(text, voice, rate=…)`, audio chunks joined), `__init__.py` (`PROVIDERS` by name, `get_provider`).
- `app/speech/cache.py`: `cache_key` = sha1 of `provider|voice|rate string|spoken`, files `data/audio/<key>.mp3`; `register(Job)` remembers what a key stands for; `get_audio(key)` serves the file or synthesizes it (semaphore 3, `wait_for` 20 s, 2 retries with 0.5 s / 1 s back-off, empty audio = failure, one shared task per key, temp file + `os.replace`); `cache_info()`, `clear_cache()`.
- API `app/routers/tts.py`: `POST /api/tts/prepare {text | question_id, field: "text"|"answer"}` → `{text, provider, voice, segments: [{i, spoken, start, end, is_number, pause_after_ms, rate_pct, url}]}` (offsets refer to the returned `text`, which is the spoken override when filled); `GET /api/tts/audio/{key}.mp3` (lazy synthesis, 503 `{"code": "tts_failed"}` on provider failure, 404 for unknown keys, immutable cache headers); `GET /api/tts/cache` → `{files, bytes}`; `DELETE /api/tts/cache`.
- Frontend `player.js`: reusable `Player(container, {controls})` with `load({text} | {questionId, field})`, `play`, `readAgain`, `pause`, `resume`, `stop`, `playSentence(k)`, `setSpeed`, `destroy`; events `end` (`detail.full` = whole text read) and `statechange`; module exports `prefetch(source)` (for Phase 4's next-question prefetch) and `stopAll()` (called on tab switch). It renders the original text with clickable sentences (highlight on the one being read), buttons ▶ წაკითხვა / 🔁 თავიდან წაკითხვა / ⏸ პაუზა ↔ ▶ გაგრძელება / ⏹ შეჩერება and a 0.5×–1.5× speed slider. All segments of the loaded text are downloaded as blobs right after `load` (shared cache of up to 400 blobs); playback waits only for the segment it needs. Only one player speaks at a time.
- `webspeech.js`: browser fallback (first voice whose `lang` starts with `ka`, `rate = (1 + rate_pct/100) × speed`, one utterance per segment, same gaps). Used when an audio request fails or when `tts_provider` is `browser`; without a Georgian voice the player shows a Georgian message and stops (text stays on screen).
- Questions tab: „მოსმენა“ is enabled (`listen.js`): opens a panel inside the form with the player and the normalized text („ასე წაიკითხება…“) for the spoken override if filled, else the question text (unsaved edits included). Opening another question closes it.
- Settings tab is now an editable form that saves each field on change (`PUT /api/settings`, theme/font applied at once, 422 → Georgian error and the old value comes back): voice, rate, number slowdown, sentence pause, number pause, number emphasis, „ხმის ტესტი“ (sentence with a year, a date, an ordinal and a percentage, from `settings.voice_test_text` in ka.json), timer default, both +time values, timer auto-start, font size, theme, audio cache size with refresh and „აუდიოს ქეშის გასუფთავება“.
- Tests: `tests/test_tts.py` (cache key, rate string, prepare from text/question/answer, rate clamp, validation, browser provider, synthesize-once-then-cache with a mocked provider, 2 retries, failure → 503, timeout, empty audio, concurrency ≤ 3, unknown key, clear cache, edge provider with mocked `edge_tts.Communicate`). Smoke test lists the new JS files.

## Phase 3 — verified

- `pytest`: 224 passed, 3 xfailed.
- Real edge-tts from this machine (no proxy needed), scratch server on port 8001: the voice-test sentence became 7 segments, all digits spoken as words („ორი ათას ოცდაოთხი წლის“, „თხუთმეტ მარტს“, „მესამე ადგილი“, „სამოცდათხუთმეტი პროცენტი“), number segments at −40 %, the rest at −25 %. First fetch of all 7 one after another: 14.9 s (≈2 s per segment); second fetch: 0.03 s from the disk cache.
- Browser UI not checked in this session (left to the orchestrating session).

## Phase 4 — what exists

- API: `POST /api/questions/{id}/mark-played` (sets `played_at` once; repeat calls keep the first time; `updated_at` untouched). Test in `tests/test_questions.py`.
- `play.js`: package picker (package, order and skip flag remembered in `localStorage` `rsr.play`), in order / shuffled, skip played, „N / total“ with tour and №, ← წინა / შემდეგი →, jump to N, handout text or image above the question, question text in the Phase 3 `Player` (highlight, click a sentence to re-read it), „ტექსტის ჩვენება წაკითხვისას“ toggle (setting `show_text_while_reading`), empty states (no packages, empty package, everything played), timer auto-start after a full reading (`timer_autostart`). Opening a question prepares its audio and prefetches the next one. Coming back to the tab re-reads settings and the package (edits, deletions and new questions show up without losing the order).
- `timer.js`: `Timer` (end time from `performance.now()`, 100 ms render tick, re-render on `visibilitychange`), start / pause / resume, reset, presets from `timer_presets`, +small / +large from settings, colour states via `data-state` normal / warn (≤10 s) / over (0, „დრო ამოიწურა!“), Web Audio beep at 10 s and a falling three-tone end signal; `unlockAudio()` creates/resumes the AudioContext on the first pointerdown/keydown.
- `answer.js`: `AnswerPanel` (პასუხის ჩვენება ↔ პასუხის დამალვა; answer, ჩაითვლება, არ ჩაითვლება, კომენტარი with `[n]` buttons that scroll to and flash source n, numbered sources with links `target="_blank" rel="noopener"`, ავტორი; 🔊 reads the answer with a control-less `Player`). Revealing marks the question played.
- `playkeys.js`: shortcuts, „? კლავიშები“ cheat-sheet dialog, ⛶ fullscreen (whole page, header hidden), A−/A+ (4 px steps, 32–96 px, saved with `PUT /api/settings` and mirrored into the Settings form via `settingsChanged()` in `settings.js`).
- `css/play.css` (own file so `app.css` stays under 300 lines). The smoke test lists the new JS/CSS files.

## Phase 4 — verified

- `pytest`: 230 passed, 3 xfailed.
- No JS runtime on this machine and no browser check in this session: the UI is unverified until the checklist below is run.

## Phase 4 — manual test checklist (Play tab)

1. Empty data folder → Play shows „ჯერ არც ერთი პაკეტი არ არის…“ and a button to the Questions tab; create a package there → back in Play: „ამ პაკეტში ჯერ კითხვები არ არის…“.
2. Add 3 questions (one with a handout image, one with 2 sources + comment „იხ. [1] და [2]“, one with a spoken override) → Play shows „1 / 3“, tour/№, handout above the text, text ≥32 px.
3. Mouse cycle: ▶ წაკითხვა (sentence highlight; clicking a sentence re-reads it) → ▶ დაწყება → პასუხის ჩვენება (answer, ჩაითვლება, არ ჩაითვლება, comment, sources, author; the label gains „ნათამაშევი“) → შემდეგი →.
4. Keyboard-only cycle: R reads, S stops, Space starts/pauses the timer, A shows/hides the answer, → / ← move, + adds 10 s, ? opens the cheat sheet (Esc closes). Nothing fires while typing in the jump box or while the sheet is open; ←/→ on a focused tab button only switches tabs.
5. Timer: preset 20 → start → amber at 0:10 with a beep → red „დრო ამოიწურა!“ with the end signal at 0; +10 after 0 restarts at 0:10 and runs; +30 while paused adds without starting; ↺ resets.
6. Start 60 s, switch to another browser tab for ~30 s, come back: the display matches a stopwatch (±1 s).
7. Comment `[2]` scrolls to and flashes source 2; a source link opens in a new tab; 🔊 reads the answer and shows ⏹ while reading.
8. „არეულად“ + „ნათამაშევის გამოტოვება“: already revealed questions are left out and „N / total“ counts only the rest; when all are played a Georgian message explains how to continue.
9. Jump: 3 + Enter → question 3; 0 or 99 marks the field red and stays.
10. A+ three times, reload: size kept (the Settings slider shows it too); A− stops at 32 px.
11. Untick „ტექსტის ჩვენება წაკითხვისას“, open the next question: the text is covered until reading ends or ⏹. Turn on timer auto-start in Settings: the timer starts when a full reading ends.
12. ⛶ / F: fullscreen without the header, Esc leaves; light theme keeps amber/red and links readable; the network tab shows the next question's `/api/tts/prepare` + mp3 requests right after a question opens.

## Phase 5 — what exists

- `app/importer/`: `__init__.py` (`Paragraph` with (text, font) runs, `ImportFailure(code)`), `docx_reader.py` (body + table cells in order, run font → `w:rFonts` → style chain, hyperlink runs, `Heading*`/`Title` → heading, `w:numPr` on the paragraph or its style → numbered, image rIds), `pdf_reader.py` (`get_text("dict", sort=True)`, block = paragraph, hyphen repair, header/footer and page-number removal, no-text-layer and password errors), `txt_reader.py`, `legacy_fonts.py` (AcadNusx map, font regex, fallback guess), `cleanup.py`, `segmenter.py` (labels from `labels.json`, re-read on every import; labelled, numbered and table layouts), `checks.py` (warnings), `pipeline.py` (`parse(name, data, legacy=None)`), `dump.py` (`python -m app.importer.dump <file> [--legacy auto|on|off]`, read-only, UTF-8 output even on the cp1252 console).
- API `app/routers/importer.py`: `POST /api/import/parse` (multipart `files` + optional `legacy` auto/on/off per file) → `{files: [{name, error, title, editor, count, legacy: {by_font, detected, applied}}], rows: [{file, number_label, tour, text, answer, accepted, not_accepted, comment, author, handout_text, sources, warnings}]}`, no writes; `POST /api/import/check {rows}` → `{warnings}` (re-check after edits); `POST /api/import/commit {package | package_id, rows}` → `{package, added}` in one transaction (rows are `QuestionBody`, so a row without text or answer → 422 with `loc = [body, rows, i, field]`).
- Import tab (`importer.js`, `importtable.js`, `css/import.css`): drop zone + „ფაილების არჩევა“ (.docx/.pdf/.txt, several at once; `.json` goes to the Phase 1 JSON import via `importJsonFile` exported from `questions.js`), per-file status (questions found / Georgian error / „კითხვები ვერ მოიძებნა“) with the AcadNusx toggle (pre-checked when detected; changing it re-parses that file) and ✕; preview table grouped by file: №, question (+ „სხვა ველები“: tour, accepted, not accepted, comment, author, handout), answer, sources (one per line), warnings, „⤓ შემდეგთან გაერთიანება“ / „✕ წაშლა“; target „ახალ პაკეტში“ (name prefilled from the document) or „არსებულ პაკეტში“; „შენახვა“ / „გასუფთავება“. After saving, the Questions tab shows the package; Play picks it up when its tab opens.
- `scripts/make_sample.py` → `samples/sample_package.docx` (5 demo questions, title „დემო პაკეტი: სადემონსტრაციო კითხვები“, every comment says „სადემონსტრაციო კითხვა“; question 5 is typed in AcadNusx). `docs/FORMAT_GUIDE_ka.md` (Georgian host guide: layout, labels, adding a label, tips).
- Tests: `tests/test_importer.py` (units + all nine §7 cases, error files, warnings), `tests/test_import_api.py` (parse without writes, legacy toggle, mixed good/bad files, commit new/existing, validation, check, sample package, dump CLI); fixtures are built in memory by `tests/import_fixtures.py` (python-docx; pymupdf with sylfaen.ttf or Noto Sans Georgian, PDF tests skip without such a font).
- `samples/real/` holds only `.gitkeep`: the host added no real documents, so there was nothing to dump or to add regression fixtures for. The dump CLI works on any file added later (HOW_TO_USE „Import problem“ prompt).

## Phase 5 — verified

- `pytest`: 285 passed, 3 xfailed (52 new import tests).
- `samples/sample_package.docx` through the API on a scratch server (port 8001, temp data folder): 5 rows, 0 warnings, 0 errors, AcadNusx detected by font and converted; commit created the package with 5 questions; a `.doc` sent alongside got `doc_format`; the new static files are served.
- No JS runtime or browser in this session: the Import tab UI is unverified until the checklist below is run.

## Phase 5 — manual test checklist (Import tab)

1. Import tab → „ფაილების არჩევა“ → `samples/sample_package.docx`: the file line says „5 კითხვა“, the AcadNusx box is ticked with „(აღმოჩენილია ავტომატურად)“; the preview shows 5 rows, „5 კითხვა, აქედან გაფრთხილებით: 0.“, row 5 is Georgian („რამდენი ასოა…“), the name field says „დემო პაკეტი: სადემონსტრაციო კითხვები“.
2. Untick the AcadNusx box → confirm → 4 rows, and row 4's „სხვა ველები“ → ავტორი holds Latin „SekiTxva 5. …“; tick it again → 5 rows.
3. Clear the answer of row 2 → after ½ s „პასუხი არ არის“ appears; „შენახვა“ → red mark + „1 კითხვას აკლია…“; type the answer back.
4. „⤓ შემდეგთან გაერთიანება“ on row 3 → 4 rows, texts joined; „✕ წაშლა“ on a row → it disappears and the next row warns about the numbering gap.
5. Save to a new package → green „შენახულია … კითხვა …“, the preview closes, the Questions tab shows the package with sources and tour; import the same file again → every row warns „ასეთი კითხვა უკვე არის პაკეტში …“.
6. „არსებულ პაკეტში“ + a package → saving appends at the end of that package.
7. Pick a `.doc`, a renamed non-PDF `.pdf` and a JSON export together: Georgian errors for the first two; the JSON becomes a package („JSON პაკეტი … შემოტანილია“).
8. Dropping a file outside the drop zone on the Import tab does not open it in the browser; light theme readable; at phone width the table scrolls sideways inside its card (no page scroll).

## Phase 6 — what exists

- `app/speech/providers/azure.py`: `AzureProvider` (REST `https://{region}.tts.speech.microsoft.com/cognitiveservices/v1`, SSML with `xml:lang="ka-GE"`, voice and `<prosody rate>`, XML-escaped text, `audio-24khz-48kbitrate-mono-mp3`); key and region are read from settings at call time. `ProviderConfigError` (missing key/region, HTTP 400/401/403/404) is not retried. Error messages carry only the exception type or HTTP status, never request details.
- Fallback chain: `server_provider()` uses Azure only when a key and a region are stored (else edge at once); `cache.get_audio()` serves the chosen provider's file or synthesizes it, and when that fails synthesizes (or reuses) the edge file for the same segment; if edge fails too the page gets 503 and the player switches to the browser voice (Phase 3).
- `app/speech/pregen.py` + `POST /api/tts/pregenerate {package_id}` (question as read aloud + answer, unique segment keys, background job with 3 workers), `GET /api/tts/pregenerate` (`{package_id, total, done, failed, running, cancelled}`), `DELETE /api/tts/pregenerate` (cancel). 404 unknown package, 409 `browser_provider` / `busy`. `plan_segments()` in `routers/tts.py` is shared by prepare and pre-generation, so both give the same cache keys.
- Settings API: `GET`/`PUT /api/settings` return the Azure key as `********` when one is stored; sending the mask back keeps the stored key, `""` removes it; 422 details leave out input values. `azure_region` is normalized („West Europe“ → `westeurope`) and must match `[a-z0-9]*`.
- Settings tab: „ხმის წყარო“ (edge / azure / browser) with the Azure key (password field) and region shown for Azure; „ოფლაინ თამაში“ card (package, „აუდიოს წინასწარ მომზადება“, progress bar, cancel, result message; a running job keeps showing after a reload) with the audio-cache line moved into it; „გამოთქმის ლექსიკონი“ card (`dictionary.js`: rows written → spoken, add / edit / delete, saved on every change, live „ასე წაიკითხება…“ preview of a test text through `/api/speech/preview`).
- Play tab: collapsible „ანგარიში“ (`scoreboard.js`, saved in `localStorage` `rsr.score`): TV mode (მცოდნეები vs ტელემაყურებლები, editable names, +1/−1, banner and +1 locked at 6) and teams mode (add / rename / delete teams, ticks for the question open in Play, totals table with the leader highlighted; „ახალი თამაში“ keeps names and teams).
- Player: with the browser provider chosen on purpose, the no-voice message no longer blames the server voice (`player.no_voice_browser`).
- Tests: `tests/test_offline_azure.py` (SSML, Azure request with mocked httpx, rejected key not retried and never in errors or logs, missing key, provider choice, Azure → edge fallback, edge failure → 503, masked key, region rules, pre-generation then every segment served while the provider fails, failures counted and cached segments skipped, 404/409/cancel, empty package, dictionary edits change the preview). The smoke test lists the new JS files.

## Phase 6 — verified

- `pytest`: 303 passed, 3 xfailed (18 new).
- Built by the orchestrating session itself after the Phase 6 subagent was stopped before it had written anything.
- Browser pane (1366×900, scratch data folder): the provider switch shows/hides the Azure fields; a made-up test key is stored and shown only as `********` (page and API); „West Europe“ → `westeurope`; dictionary row ФИФА → ფიფა changes the preview at once and deleting it restores it; real edge-tts pre-generation of a 2-question package: 4 / 4 segments, 0 failed, progress bar and „მზადაა…“ message, cache count updated; scoreboard TV mode banner at 6 with +1 locked, −1 undoes it; teams mode ticks per question, totals 2 / 1 / 0 with the leader marked, add and rename a team; the browser provider without a Georgian voice shows the new message. No console errors.
- Not checked: a real Azure key (none available; the Azure path is covered by mocked tests) and an actual network unplug (covered by the test that serves every pre-generated segment while the provider fails).

## Phase 7 — what was done

- Fixes: a number before a vowel-stem noun in the ergative is now declined („3 ძმამ“ → „სამმა ძმამ“, „10 ქვეყანამ“ → „ათმა ქვეყანამ“; two rows added to spec §3b and the tests); a dictionary replacement followed by a hyphenated suffix joins it („UNESCO-მ“ → „იუნესკომ“, „ФИФА-ს“ → „ფიფას“); `.btn.small`, icon buttons, selects, the import „სხვა ველები“ toggle and the „დამატებით“ toggle are at least 48 px tall; scoreboard ticks are 32 px; light-theme `--accent` (#9a6400) and `--warn` (#9a5b00) now reach ≥ 4.5:1 (white text on accent 5.0:1, warning text 5.4:1); Georgian wording: „გავაგრძელოთ?“ everywhere, grammatical row labels for merge/delete, clearer „ნათამაშევის სტატუსი განულდა…“.
- `README.md`: Georgian first, then English (requirements, install and start, tabs, document format, offline audio, shortcuts, troubleshooting: no voice, scanned PDF, AcadNusx, .doc, Python not found, busy port; data and backups; developer notes).

## Phase 7 — verified

- `pytest`: 305 passed, 3 xfailed; after the host's decision on the disputed rules: 311 passed, 0 xfailed.
- Walkthrough in the browser pane on a fresh, empty scratch data folder (1366×900): Play shows the no-packages message → Import `samples/sample_package.docx` (5 rows, AcadNusx detected, saved as „დემო პაკეტი…“) → Play: question 1 read (sentence highlight) with the timer and +10 s while running, answer revealed; question 2 on the 30 s preset, paused, +30 s while paused (0:29 → 0:59, still paused), answer revealed; question 3 by keyboard (A reveals, R reads again); 3 questions marked played → Questions tab: answer edited and saved → back in Play the question re-opens with the edited answer → 🔁 read again → scoreboard +1.
- Every visible button, select and toggle on all four tabs measured ≥ 48 px (inline `[n]` source markers in comments are text links and stay inline). Contrast of the colour tokens: dark theme ≥ 5.9:1 for all text pairs (body text 15–17:1, primary buttons 9.9:1); light theme ≥ 4.6:1 after the fix. No browser console errors on any tab.
- Earlier phases were checked in the browser pane by the orchestrating session after each build (Phases 1–6), including the Phase 4 and Phase 5 checklists.

## Decided by the host: disputed spec rules

Phase 2 found three §3 rules whose Georgian looked wrong and kept them as xfail tests. On 2026-10-31 the host chose the app's forms, so the code is unchanged and spec §3a/§3b plus the tests were updated (rule text, new table rows, normal test cases):
- `8 კაცმა` → „რვა კაცმა“ (a vowel-final number before an ergative noun doesn't decline; the spec rule had „რვამ კაცმა“). A number standing alone keeps the ergative: `8-მა` → „რვამ“.
- `8-თან` → „რვასთან“ (vowel stems take the dative ს before -თან, also ე-final ordinals: მეოცესთან; the spec rule had „რვათან“). `5-თან` → „ხუთთან“.
- `8-იანი` → „რვიანი“ (a vowel-initial suffix drops ა, like -ის/-ით; the spec rule had „რვაიანი“).

## Decisions


- Added `run.py` (not in the CLAUDE.md layout) so both start scripts share one launcher that can wait for the server before opening the browser.
- Added `app/static/js/i18n.js` (not in the layout) because every module needs `t()`.
- Dev dependencies live in `requirements-dev.txt` (`pytest`); `start.bat` installs only `requirements.txt`. All later-phase runtime packages are already in `requirements.txt`, so later phases don't trigger a reinstall.
- Start-script messages are English: the Windows console often lacks a Georgian font. Everything in the browser is Georgian.
- One hard-coded bilingual error string in `app.js` is shown only if `ka.json` itself fails to load.
- Settings `PUT` merges the request into the current settings and validates the whole result; a stored value that no longer validates is ignored on read (falls back to its default).
- Requirements are pinned to the versions installed on 2026-10-31 (FastAPI 0.162.0, Pydantic 2.14.2, Uvicorn 0.54.0, PyMuPDF 2.0, edge-tts 7.3.1, …).
- `pytest.ini` hides Starlette's "use httpx2 for TestClient" deprecation warning; httpx still works and the Azure provider will use it.
- `.claude/launch.json` starts Uvicorn directly on port 8001 (no browser pop-up, no clash with a start.bat run on 8000) for previewing the app inside Claude Code.
- The Azure key is stored in plain text in the local SQLite file and returned by `GET /api/settings` (local-only app). Revisit in Phase 6.

- Phase 1: handout images are stored content-addressed (`data/uploads/<sha1>.<ext>`), so duplicated or imported questions share one file; a file is deleted only when no question refers to it. Upload routes live in their own `routers/uploads.py` (not in the layout).
- Phase 1: the JSON export embeds handout images as `data:` URIs (one self-contained file for sharing), leaves out ids, positions (list order instead) and played status. Import always creates a new package; when the title already exists the frontend appends „(ასლი)“ from ka.json, so the server never generates UI text.
- Phase 1: duplicates are reported after saving (warning with links), not blocked; the question is still saved.
- Phase 1: reorder uses `move up/down` (swap with the neighbour) instead of sending a full order, so it also works in a filtered or searched list. Moving does not change `number_label`; "N / total" in Play will use list position.
- Phase 1: „დუბლირება“ turns the form into an unsaved copy of the current question; nothing is written until „შენახვა“.
- Phase 1: source links without a scheme get `https://`; other schemes (e.g. `javascript:`) are rejected. Blank optional text fields are stored as NULL.
- Phase 1: confirmations and the package-name prompt use an in-page `<dialog>` instead of `window.confirm/prompt`.
- Phase 1: Questions-tab files `questions.js` and `dialog.js` are not in the CLAUDE.md layout; `editor.js` holds only the form.

- Phase 2: the seed dictionary is built into `normalize_ka.py`; `settings.pronunciation_dict` adds entries and overrides a seed entry with the same `written`. Matching is case-sensitive.
- Phase 2: unit symbols are rewritten to words (digits kept) before any number pass, so the number before a unit sees the unit word for the attributive rule (`5 კმ-ზე` → ხუთ კილომეტრზე). A hyphenated suffix after a unit, a time or `ს.`/`სს.` is joined to that word.
- Phase 2: ergative detection needs a vowel in the stem before …მა, so `2 ძმა` stays ორი ძმა.
- Phase 2: a comma-thousands token must not start with 0 (`0,125` is a decimal); more than 3 decimal digits are read digit by digit after მთელი; numbers ≥ 10^12 are read digit by digit; `1-ლ` (without ი) → პირველ.
- Phase 2: ordinals of compounds inflect only the last word: 101 → ას პირველი, 121 → ას ოცდამეერთე; `-ე`-final ordinals stay unchanged before dative/ergative nouns.
- Phase 2: Roman numerals use only I V X L (so CD, DC, MC, C, D are never read as numbers); a single letter counts only for I, V, X. Roman ranges are written „მეხუთე–მეექვსე“ (no spaces) and Arabic ranges „… – …“, as in the spec tables.
- Phase 2: sentence split — a dot after a dictionary abbreviation, `სს.`/`ძვ.`/`ჩვ.`, or single Georgian letters with dots (`წ.`, `ს.`, `ი.`, `ე.წ.`) is not a sentence end when the next character is lowercase or a digit; Georgian Mkhedruli letters count as lowercase, so in practice `1921 წ. თებერვალში` never splits. Line breaks alone do not split.
- Phase 2: number emphasis segment = the expanded number plus the next whitespace-separated token (the noun/unit, or a verb when there is none) with attached punctuation; punctuation-only leftovers join the previous segment. Pauses: number segments get `number_pause_ms` before and after, a `;`/`:` clause ends with half the sentence pause, a sentence with `sentence_pause_ms`, the last segment with 0. Sentence-final punctuation is kept in `spoken` (helps TTS intonation).
- Phase 2: the preview's `spoken` is the segments joined with spaces.

- Phase 3: the key → text registry for lazy synthesis lives in memory (filled by `prepare`). After a server restart an old URL whose file is not cached yet returns 404 until the page prepares the text again (the player prepares on every `load`).
- Phase 3: number segments use `rate_pct + number_rate_pct`, clamped at −75 %. The rate in the cache key is the edge-style string (`-25%`).
- Phase 3: the player's speed slider changes the MP3 playback rate in the browser (pitch kept) and divides the gaps by the same factor; it does not re-synthesize. It is remembered in `localStorage`. The settings „კითხვის სიჩქარე“ is the synthesized base rate.
- Phase 3: any failed audio download (503, network) switches that loaded text to the browser voice; the next `load` tries the server again. `tts_provider = "azure"` uses edge until Phase 6 adds Azure; `browser` makes `prepare` return no URLs.
- Phase 3: settings save on every change (no save button). The voice test uses the saved settings. Timer auto-start is in the form already (one checkbox); the provider selector, Azure key/region, pre-generation and the dictionary editor stay for Phase 6.
- Phase 3: when a spoken override exists, the player shows and highlights the override text (the offsets belong to it). Phase 4 can show the question text separately.
- Phase 3: extra files not in the layout: `webspeech.js` (browser fallback) and `listen.js` (Questions-tab preview). `player.js` is ≈340 lines (a bit over the ~300 guideline) to keep the reusable component in one file.

- Phase 4: „დაწყება“ after the timer reached 0 starts the full selected duration again; extra time after 0 restarts from the added amount and starts running at once; extra time while paused only adds. Opening another question resets the timer to the selected preset (the Settings default on page load); a running timer keeps running while switching app tabs.
- Phase 4: the 10 s beep sounds only when the countdown crosses 10 s (not when it starts at ≤10 s); after extra time lifts it above 10 s it can beep again.
- Phase 4: jump goes to position N in the current playing order (the „N / total“ number), not to `number_label`.
- Phase 4: „ნათამაშევის გამოტოვება“ filters when the order is built (package / order / skip change); questions revealed during the game stay in the current order. A shuffle is new each time the order is built (not kept across reloads); only package, order and skip are remembered.
- Phase 4: „ტექსტის ჩვენება წაკითხვისას“ off = the question text is covered from the moment a question opens until its first reading ends or is stopped. With a spoken override the real question text is shown and the player's (override) text is hidden.
- Phase 4: auto-start fires only after a full reading (▶ / 🔁, not a single sentence) and only when the timer is untouched since the last reset.
- Phase 4: shortcut letters use `event.code` (physical keys) so they also work on the Georgian layout; `+` also accepts numpad +; key repeat is ignored; Space on a focused button toggles the timer instead of clicking the button. Shortcuts that need a question do nothing in an empty state.
- Phase 4: fullscreen covers the whole page and hides the header (Esc leaves). A−/A+ use 4 px steps within 32–96 px; the Settings slider still allows down to 20 px, but the question text never renders below 32 px.
- Phase 4: comment markers `[n]` are buttons that scroll to source n (no `#` links, because the hash drives the tabs). Markers without a matching source stay plain text.
- Phase 4: extra files not in the layout: `answer.js`, `playkeys.js`, `css/play.css`.

- Phase 5: the server returns error and warning **codes**; the Georgian texts live in ka.json (`import.errors.*`, `import.warn.*`). The dump CLI prints the code with an English hint.
- Phase 5: extra files not in the layout: `app/importer/pipeline.py` (reader → conversion → cleanup → segmenter), `app/importer/checks.py` (warnings), `static/js/importtable.js`, `static/css/import.css`, `tests/import_fixtures.py`. `Paragraph` and `ImportFailure` live in `app/importer/__init__.py`.
- Phase 5: one save target for the whole batch (all files in the preview go into one package). The name is prefilled from the first file with questions; `source_file` = the file names, `editor` = the first editor found. Other header text is not stored.
- Phase 5: a row without question text or answer cannot be saved (the DB requires both since Phase 1): saving marks such rows red and stops. All other warnings never block.
- Phase 5: warnings are re-computed by `POST /api/import/check` 0.5 s after editing №/text/answer/tour and after merge/delete. Duplicates are checked across the whole preview (`duplicate_batch` points to the first row) and against the database (`duplicate_db`, first matching package). Numbering gaps / repeats / disorder are checked per file and per tour (a new tour restarts the sequence).
- Phase 5: AcadNusx conversion: when a file has legacy-font runs only those runs convert; without font info (TXT, or the host forces the toggle on) every run without Georgian letters converts. URLs are never converted. Uppercase letters without their own key use the lowercase mapping — **not verified against a real AcadNusx document** (none available). Changing the toggle re-parses that file and replaces its rows (a confirmation warns that its edits are lost).
- Phase 5: labels: only question and tour labels take a number (`შეკითხვა 3`, `ტური 2`); after other labels a number is text (`პასუხი 1812`). Added `Зачет`, `Незачет` (without ё), `Редакторы`, `Editors` to labels.json. A heading paragraph after the first question closes the current field, and lines after a tour label up to the next question are skipped (both listed as `skipped:` in the dump).
- Phase 5: numbered layout: a `1.` / `1)` line or a Word-numbered paragraph (numbering on the paragraph or its style, e.g. „List Number“) starts a question only when an answer label follows before the next numbered line, so numbered sources and bullet lists stay in their field. Word-numbered questions get `number_label` = their running count.
- Phase 5: DOCX hyperlinks whose visible text is not the URL get the URL appended, so sources keep their link. Table layout: a „№“/„#“/„N“/„No“ header is the number column, a „ტური“ column sets the tour, unknown columns go to the comment as „Header: value“.
- Phase 5: PDF: a text block is one paragraph whose lines are joined with spaces, except lines starting with a label, `1.`, a bullet or a URL. Line-end hyphens include U+00AD/U+2010/U+2011 (Sylfaen's hyphen comes back as a soft hyphen). Headers/footers = blocks in the top/bottom 12 % of the page whose text (digits ignored) repeats on at least half of the pages (≥ 2 pages); lone page numbers are dropped only in that band.
- Phase 5: TXT tries UTF-16 only with a BOM or NUL bytes, so ANSI files fail with a clear message instead of decoding to garbage. Max upload 50 MB per file.
- Phase 5: a source keeps its whole line as text (URL included) and the detected link as `url`; the preview edits sources as plain lines and the browser splits them again with the same rules. `www.` links get `https://` on save (Phase 1 rule).
- Phase 6: the Azure key never reaches the browser (masked as `********`; the mask sent back keeps the stored key). Azure is used only when both key and region are stored; otherwise edge is used directly instead of failing once per segment.
- Phase 6: when the chosen provider fails for a segment, the server serves the edge audio for the same segment under the edge cache key (so an azure key keeps meaning "azure audio"); the next request tries the chosen provider again.
- Phase 6: pre-generation covers the question as read aloud (spoken override or text) and the answer, with the current voice, rates and dictionary; changing those needs a new run (the card says so). One job at a time, progress kept in memory.
- Phase 6: dictionary rows are saved on every change; a row without the written form stays on screen but is not saved. The cache line moved into the „ოფლაინ თამაში“ card.
- Phase 6: the scoreboard sits under the question in the Play tab (full width, collapsed by default). TV mode stops at 6 (+1 locked, −1 still allowed for corrections); teams-mode ticks are stored per question id, so going back to a question shows its ticks; „ახალი თამაში“ keeps names and teams.
- Phase 6: extra files not in the layout: `app/speech/pregen.py`, `dictionary.js`, `offline.js` (`scoreboard.js` and `providers/azure.py` are in the layout).
- After Phase 7 (sharing with friends): `pip install --dry-run --only-binary=:all: --platform win_amd64` showed every requirement has Windows builds for Python 3.11–3.14 but not 3.15 (`onnxruntime`, pulled in by PyMuPDF 2.0). `start.bat` now tries `py -3.12`, `-3.13`, `-3.14`, `-3.11`, then `python` only if it is 3.11–3.14 (it used to take the newest `py -3`); `start.sh` tries `python3.12`…`python3.11`, then `python3` with the same range. Share zips are made outside the repo without `.venv` (machine-specific), caches and `.claude`; the copy with questions resets played marks and drops any Azure key.
- start.bat now has Windows (CRLF) line endings (it had LF, which cmd can misread around labels such as `:fail`); `.gitattributes` keeps `*.bat` CRLF and `*.sh` LF, also in GitHub's "Download ZIP". Checked: a normal start answers, and a broken install reaches the error message with exit code 1.

## Known issues

- An image that is uploaded but never saved with a question stays in `data/uploads` (no orphan sweep).
- The export button itself was not clicked in the browser pane (it triggers a file download); its endpoint was fetched and the result re-imported through the import button.
- `PATCH /api/packages/{id}` requires `title` even when only other fields change.
- The Claude Code preview tool looks for `.claude/launch.json` in the session folder; when a session starts in the parent folder (`რა სად როდის/`), the `ra-sad-rodis` config is not found. Phase 1 ran the same Uvicorn command by hand on port 8001 instead.
- Phase 2: dates are not in the spec: `25.02` is read as a decimal and `2024-10-31` as a range plus a dash; scores like `1:2` keep the colon. No digits are left, but the reading is unnatural.
- Phase 2: a number before a word with a particle (`5 წელშიც`) is not truncated (the attributive rule looks only at the case endings listed in the spec).
- Phase 3: first play of an uncached question waits for its first segment (≈2–3 s with edge-tts); the rest download 3 at a time while it plays.
- Phase 3: `speechSynthesis.pause()` is unreliable in Chrome, so pause/resume in the browser fallback may not work there (Edge is fine).
- Phase 3: the Web Speech fallback was not tested with a real Georgian browser voice.
- Phase 4: in a background tab the browser slows the 100 ms tick to about once a second, so the 10 s beep / end signal can come up to ~1 s late there (the displayed time is exact on return).
- Phases 4–5: the build sessions had no browser; the orchestrating session ran both checklists in the browser pane afterwards (see Phase 7 — verified). Sound (timer beeps) and fullscreen still need a check on the real laptop.
- Phase 5: handout images in documents are not extracted (DOCX image rIds are only recorded); nested tables inside DOCX cells are ignored and vertically merged cells repeat their text.
- Phase 5: PDF reading order is top-to-bottom, then left-to-right, so two-column PDFs interleave their columns. An AcadNusx PDF could not be generated as a fixture (pymupdf names the font after the embedded file), so legacy fonts in PDFs are covered only by the conversion and hyphen-repair unit tests.
- Phase 5: `index.html` is now about 340 lines (over the ~300 guideline) because the Import panel is static markup; Phase 6's Settings cards bring it to ≈377.
- Phase 6: no real Azure key was available: the Azure request, SSML and error handling are tested against a mocked HTTP layer only.
- Phase 6: with Azure chosen and no network, each segment first fails on Azure (quickly, since the connection fails at once) before the cached edge file is served; pre-generate with the provider you will play with.
- Phase 7: the import preview table is cramped below ~900 px width (answer and source columns get narrow); fine on a laptop screen.
- Phase 7: the inline `[n]` source buttons in comments are text-sized (≈33 px), not 48 px.

## Next

All phases are done. Suggested next steps for the host (use the reserve prompts in HOW_TO_USE.md):
- Put 2–3 real question documents into `samples/real/` and run the "Import problem" prompt, so the importer learns your layouts.
- Report any wrong pronunciation with the "Pronunciation" prompt.
- On the real laptop: check the timer beeps, fullscreen and a full game on the TV/projector; prepare audio for offline games before going somewhere without internet.
