"""Start the app and open the browser once the server answers.

Environment overrides: RSR_HOST (default 127.0.0.1), RSR_PORT (default 8000), RSR_NO_BROWSER=1.
"""
import os
import socket
import sys
import threading
import time
import webbrowser

import uvicorn

HOST = os.environ.get("RSR_HOST", "127.0.0.1")
PORT = int(os.environ.get("RSR_PORT", "8000"))
LOCAL_HOST = "127.0.0.1" if HOST in ("0.0.0.0", "") else HOST
URL = f"http://{LOCAL_HOST}:{PORT}/"


def port_in_use() -> bool:
    try:
        with socket.create_connection((LOCAL_HOST, PORT), timeout=0.5):
            return True
    except OSError:
        return False


def open_when_ready(timeout_s: float = 20) -> None:
    deadline = time.monotonic() + timeout_s
    while time.monotonic() < deadline:
        if port_in_use():
            webbrowser.open(URL)
            return
        time.sleep(0.3)


def main() -> int:
    want_browser = os.environ.get("RSR_NO_BROWSER") != "1"
    if port_in_use():
        print(f"Port {PORT} is already in use - the app is probably running already: {URL}")
        if want_browser:
            webbrowser.open(URL)
        return 0
    if want_browser:
        threading.Thread(target=open_when_ready, daemon=True).start()
    print(f"Ra? Sad? Rodis? is running at {URL}  (close this window to stop it)")
    uvicorn.run("app.main:app", host=HOST, port=PORT)
    return 0


if __name__ == "__main__":
    sys.exit(main())
