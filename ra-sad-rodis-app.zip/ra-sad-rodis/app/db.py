"""SQLite schema and small data helpers. The schema is created on startup."""
import hashlib
import json
import os
import re
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterable, Iterator

from pydantic import ValidationError

from app.models import Settings

ROOT = Path(__file__).resolve().parent.parent

SCHEMA = """
CREATE TABLE IF NOT EXISTS packages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    title       TEXT NOT NULL,
    source_file TEXT,
    editor      TEXT,
    notes       TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS questions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    package_id      INTEGER NOT NULL REFERENCES packages(id) ON DELETE CASCADE,
    position        INTEGER NOT NULL DEFAULT 0,
    tour            TEXT,
    number_label    TEXT,
    text            TEXT NOT NULL,
    spoken_override TEXT,
    answer          TEXT NOT NULL,
    accepted        TEXT,
    not_accepted    TEXT,
    comment         TEXT,
    sources_json    TEXT NOT NULL DEFAULT '[]',
    author          TEXT,
    handout_text    TEXT,
    handout_image   TEXT,
    played_at       TEXT,
    content_hash    TEXT,
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at      TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_questions_package ON questions(package_id, position);
CREATE INDEX IF NOT EXISTS idx_questions_hash ON questions(content_hash);

CREATE TABLE IF NOT EXISTS settings (
    key        TEXT PRIMARY KEY,
    value_json TEXT NOT NULL
);
"""


def data_dir() -> Path:
    """Data folder; RSR_DATA_DIR overrides it (used by tests)."""
    return Path(os.environ.get("RSR_DATA_DIR", ROOT / "data"))


def db_path() -> Path:
    return data_dir() / "quiz.db"


@contextmanager
def get_conn() -> Iterator[sqlite3.Connection]:
    """Connection that commits on success, rolls back on error, and always closes."""
    conn = sqlite3.connect(db_path())
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    # SQLite's lower() only folds ASCII; search uses Python's casefold instead
    conn.create_function("casefold", 1, lambda v: v.casefold() if isinstance(v, str) else v, deterministic=True)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    root = data_dir()
    for folder in (root, root / "audio", root / "uploads"):
        folder.mkdir(parents=True, exist_ok=True)
    with get_conn() as conn:
        conn.executescript(SCHEMA)


def load_settings() -> Settings:
    """Defaults merged with stored values. A stored value that no longer validates is ignored."""
    with get_conn() as conn:
        rows = conn.execute("SELECT key, value_json FROM settings").fetchall()
    merged = Settings().model_dump()
    for row in rows:
        if row["key"] not in Settings.model_fields:
            continue
        candidate = merged | {row["key"]: json.loads(row["value_json"])}
        try:
            Settings.model_validate(candidate)
        except ValidationError:
            continue
        merged = candidate
    return Settings.model_validate(merged)


def save_settings(settings: Settings, keys: Iterable[str]) -> None:
    values = settings.model_dump()
    with get_conn() as conn:
        conn.executemany(
            "INSERT INTO settings (key, value_json) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value_json = excluded.value_json",
            [(k, json.dumps(values[k], ensure_ascii=False)) for k in keys],
        )


def clear_settings() -> None:
    with get_conn() as conn:
        conn.execute("DELETE FROM settings")


# ---------- Questions ----------

# Content columns written from a QuestionIn (sources are stored separately as JSON).
QUESTION_FIELDS = ("package_id", "tour", "number_label", "text", "spoken_override", "answer", "accepted",
                   "not_accepted", "comment", "author", "handout_text", "handout_image")


def content_hash(text: str) -> str:
    """sha1 of the text lowercased with whitespace and punctuation removed."""
    return hashlib.sha1(re.sub(r"[\W_]+", "", text.lower()).encode("utf-8")).hexdigest()


def question_from_row(row: sqlite3.Row) -> dict:
    data = dict(row)
    data["sources"] = json.loads(data.pop("sources_json") or "[]")
    return data


def _question_values(data: dict) -> list:
    return [data.get(f) for f in QUESTION_FIELDS] + [
        json.dumps(data.get("sources", []), ensure_ascii=False), content_hash(data["text"])]


def insert_question(conn: sqlite3.Connection, data: dict) -> int:
    """Insert at the end of its package; `data` is a QuestionIn dump."""
    position = conn.execute("SELECT COALESCE(MAX(position), 0) + 1 FROM questions WHERE package_id = ?",
                            (data["package_id"],)).fetchone()[0]
    cols = ", ".join(QUESTION_FIELDS)
    cur = conn.execute(
        f"INSERT INTO questions ({cols}, sources_json, content_hash, position) "
        f"VALUES ({', '.join('?' * (len(QUESTION_FIELDS) + 3))})",
        _question_values(data) + [position],
    )
    return cur.lastrowid


def update_question(conn: sqlite3.Connection, question_id: int, data: dict) -> None:
    sets = ", ".join(f"{f} = ?" for f in QUESTION_FIELDS)
    conn.execute(
        f"UPDATE questions SET {sets}, sources_json = ?, content_hash = ?, updated_at = datetime('now') "
        "WHERE id = ?",
        _question_values(data) + [question_id],
    )


def get_question(conn: sqlite3.Connection, question_id: int) -> dict | None:
    row = conn.execute("SELECT * FROM questions WHERE id = ?", (question_id,)).fetchone()
    return question_from_row(row) if row else None


def find_duplicates(conn: sqlite3.Connection, hash_: str, exclude_id: int | None = None) -> list[dict]:
    rows = conn.execute(
        "SELECT q.id, q.package_id, p.title AS package_title, q.number_label FROM questions q "
        "JOIN packages p ON p.id = q.package_id WHERE q.content_hash = ? AND q.id != ? "
        "ORDER BY q.package_id, q.position",
        (hash_, exclude_id or 0),
    ).fetchall()
    return [dict(r) for r in rows]
