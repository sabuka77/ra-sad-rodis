"""FastAPI entry point: serves the static UI and the JSON API."""
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app import db
from app.routers import importer, packages, questions, settings, speech, tts, uploads

STATIC_DIR = Path(__file__).resolve().parent / "static"


@asynccontextmanager
async def lifespan(_app: FastAPI):
    db.init_db()
    yield


app = FastAPI(title="რა? სად? როდის?", version="0.1.0", lifespan=lifespan)
app.include_router(settings.router)
app.include_router(packages.router)
app.include_router(questions.router)
app.include_router(uploads.router)
app.include_router(speech.router)
app.include_router(tts.router)
app.include_router(importer.router)
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/", include_in_schema=False)
def index() -> FileResponse:
    # no-cache so a restarted app never shows a stale UI
    return FileResponse(STATIC_DIR / "index.html", headers={"Cache-Control": "no-cache"})
