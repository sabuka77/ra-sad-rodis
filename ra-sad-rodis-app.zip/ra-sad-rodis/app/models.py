"""Pydantic schemas shared by the API and the data layer."""
import re
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class PronunciationEntry(BaseModel):
    written: str = Field(min_length=1, max_length=200)
    spoken: str = Field(max_length=500)


class Settings(BaseModel):
    """All app settings with their defaults. Stored per key in the settings table."""

    model_config = ConfigDict(extra="forbid")

    # Speech
    tts_provider: Literal["edge", "azure", "browser"] = "edge"
    voice: Literal["ka-GE-EkaNeural", "ka-GE-GiorgiNeural"] = "ka-GE-EkaNeural"
    rate_pct: int = Field(-25, ge=-50, le=0)
    number_rate_pct: int = Field(-15, ge=-50, le=0)
    sentence_pause_ms: int = Field(600, ge=0, le=3000)
    number_pause_ms: int = Field(250, ge=0, le=2000)
    number_emphasis: bool = True
    show_text_while_reading: bool = True
    azure_key: str = Field("", max_length=200)
    azure_region: str = Field("", max_length=40, pattern=r"^[a-z0-9]*$")  # goes into the Azure host name
    pronunciation_dict: list[PronunciationEntry] = []

    # Timer
    timer_default_s: int = Field(60, ge=5, le=600)
    timer_presets: list[int] = [60, 30, 20]
    extra_time_small_s: int = Field(10, ge=1, le=300)
    extra_time_large_s: int = Field(30, ge=1, le=600)
    timer_autostart: bool = False

    # Display
    font_size_px: int = Field(36, ge=20, le=96)
    theme: Literal["dark", "light"] = "dark"

    @field_validator("azure_region", mode="before")
    @classmethod
    def _region_form(cls, v):
        # "West Europe" → "westeurope", the form Azure uses in its host names
        return "".join(v.split()).lower() if isinstance(v, str) else v

    @field_validator("timer_presets")
    @classmethod
    def _presets_in_range(cls, v: list[int]) -> list[int]:
        if not 1 <= len(v) <= 6 or any(not 5 <= s <= 600 for s in v):
            raise ValueError("1–6 presets, each between 5 and 600 seconds")
        return v


# ---------- Packages and questions ----------

HANDOUT_IMAGE_PATTERN = r"^[0-9a-f]{40}\.(png|jpg|gif|webp)$"

_OPTIONAL_TEXT = ("tour", "number_label", "spoken_override", "accepted", "not_accepted",
                  "comment", "author", "handout_text")


class Source(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    text: str = Field("", max_length=2000)
    url: str | None = Field(None, max_length=2000)

    @field_validator("url")
    @classmethod
    def _http_url(cls, v: str | None) -> str | None:
        if not v:
            return None
        if not re.match(r"[a-z][a-z0-9+.-]*:(?!\d)", v, re.I):
            return f"https://{v}"  # "www.example.ge" → clickable link
        if not v.lower().startswith(("http://", "https://")):
            raise ValueError("only http(s) links")
        return v

    @model_validator(mode="after")
    def _not_empty(self) -> "Source":
        if not self.text and not self.url:
            raise ValueError("a source needs text or a link")
        return self


class QuestionBody(BaseModel):
    """Question content shared by the API and the JSON export format."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    tour: str | None = Field(None, max_length=200)
    number_label: str | None = Field(None, max_length=50)
    text: str = Field(min_length=1, max_length=20000)
    spoken_override: str | None = Field(None, max_length=20000)
    answer: str = Field(min_length=1, max_length=5000)
    accepted: str | None = Field(None, max_length=5000)
    not_accepted: str | None = Field(None, max_length=5000)
    comment: str | None = Field(None, max_length=20000)
    sources: list[Source] = []
    author: str | None = Field(None, max_length=500)
    handout_text: str | None = Field(None, max_length=20000)

    @field_validator(*_OPTIONAL_TEXT)
    @classmethod
    def _blank_is_none(cls, v: str | None) -> str | None:
        return v or None


class QuestionIn(QuestionBody):
    package_id: int
    handout_image: str | None = Field(None, pattern=HANDOUT_IMAGE_PATTERN)


class Question(QuestionIn):
    model_config = ConfigDict(extra="ignore")

    id: int
    position: int
    played_at: str | None
    content_hash: str | None
    created_at: str
    updated_at: str


class DuplicateRef(BaseModel):
    id: int
    package_id: int
    package_title: str
    number_label: str | None


class QuestionSaved(Question):
    duplicates: list[DuplicateRef] = []


class MoveIn(BaseModel):
    direction: Literal["up", "down"]


class PackageIn(BaseModel):
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    title: str = Field(min_length=1, max_length=300)
    source_file: str | None = Field(None, max_length=500)
    editor: str | None = Field(None, max_length=300)
    notes: str | None = Field(None, max_length=5000)


class Package(PackageIn):
    id: int
    created_at: str
    question_count: int = 0
    played_count: int = 0


class ExportQuestion(QuestionBody):
    handout_image_data: str | None = None  # data:image/...;base64,... so the file is self-contained


class PackageExport(BaseModel):
    format: Literal["ra-sad-rodis"] = "ra-sad-rodis"
    version: Literal[1] = 1
    package: PackageIn
    questions: list[ExportQuestion]
