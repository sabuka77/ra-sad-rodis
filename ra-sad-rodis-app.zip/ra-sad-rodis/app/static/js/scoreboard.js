// Play tab: collapsible scoreboard. TV mode (მცოდნეები vs ტელემაყურებლები, first to 6 wins) or
// teams mode (named teams, tick who answered the open question correctly, totals). Kept in localStorage.
import { confirmDialog } from "./dialog.js";
import { t } from "./i18n.js";

const KEY = "rsr.score";
const WIN_AT = 6;
let game;
let question = null; // {id, label} of the question open in Play

const $ = (id) => document.getElementById(id);

function el(tag, props = {}, ...children) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

function freshGame(previous) {
  return {
    mode: previous?.mode ?? "tv",
    tv: { names: previous?.tv.names ?? [t("score.experts"), t("score.viewers")], scores: [0, 0] },
    teams: {
      list: previous?.teams.list ?? [1, 2].map((n) => ({ id: n, name: t("score.team_default", { n }) })),
      ticks: {},
      nextId: previous?.teams.nextId ?? 3,
    },
  };
}

function load() {
  try {
    const saved = JSON.parse(localStorage.getItem(KEY));
    if (saved?.tv && saved?.teams) return saved;
  } catch { /* storage unavailable or broken: start fresh */ }
  return freshGame();
}

function store() {
  try { localStorage.setItem(KEY, JSON.stringify(game)); } catch { /* storage unavailable */ }
}

function change(update) {
  update();
  store();
  render();
}

function nameInput(value, label, onChange) {
  const input = el("input", { value, className: "score-name", autocomplete: "off" });
  input.setAttribute("aria-label", label);
  input.addEventListener("change", () => { onChange(input.value.trim() || value); store(); render(); });
  return input;
}

function button(text, label, onClick, className = "btn") {
  const node = el("button", { type: "button", className, textContent: text, title: label });
  node.setAttribute("aria-label", label);
  node.addEventListener("click", onClick);
  return node;
}

function renderTv() {
  const { names, scores } = game.tv;
  const winner = scores.findIndex((s) => s >= WIN_AT);
  const sides = names.map((name, i) => el("div", { className: `score-side${winner === i ? " won" : ""}` },
    nameInput(name, t("score.side_name"), (v) => { game.tv.names[i] = v; }),
    el("span", { className: "score-value", textContent: String(scores[i]) }),
    button(t("score.minus"), t("score.minus_for", { name }), () => change(() => { scores[i] = Math.max(0, scores[i] - 1); })),
    Object.assign(button(t("score.plus"), t("score.plus_for", { name }), () => change(() => { scores[i] += 1; }), "btn primary"),
      { disabled: winner !== -1 }),
  ));
  const banner = winner === -1 ? [] : [el("p", { className: "score-winner", role: "status", textContent: t("score.winner", { name: names[winner] }) })];
  return [...banner, ...sides];
}

function renderTeams() {
  const { list, ticks } = game.teams;
  const totals = new Map(list.map((team) => [team.id, 0]));
  for (const ids of Object.values(ticks)) for (const id of ids) if (totals.has(id)) totals.set(id, totals.get(id) + 1);
  const best = Math.max(0, ...totals.values());

  const rows = list.map((team) => {
    const tick = el("input", { type: "checkbox", disabled: !question,
      checked: Boolean(question && ticks[question.id]?.includes(team.id)) });
    tick.setAttribute("aria-label", team.name);
    tick.addEventListener("change", () => change(() => {
      const set = new Set(ticks[question.id] ?? []);
      if (tick.checked) set.add(team.id); else set.delete(team.id);
      ticks[question.id] = [...set];
    }));
    const remove = button("×", t("score.remove_team"), async () => {
      if (await confirmDialog(t("score.remove_team_confirm", { name: team.name }), t("dialog.delete"))) {
        change(() => { game.teams.list = list.filter((x) => x.id !== team.id); });
      }
    }, "btn small icon");
    const total = totals.get(team.id);
    return el("tr", { className: total === best && best > 0 ? "leader" : "" },
      el("td", {}, tick),
      el("td", {}, nameInput(team.name, t("score.team_name"), (v) => { team.name = v; })),
      el("td", { className: "score-total", textContent: String(total) }),
      el("td", {}, remove));
  });
  const head = el("tr", {}, el("th", { textContent: "✓" }), el("th", { textContent: t("score.team") }),
    el("th", { textContent: t("score.points") }), el("th"));
  const caption = question ? t("score.ticks_title", { number: question.label }) : t("score.no_question");
  const add = button(t("score.add_team"), t("score.add_team"), () => change(() => {
    const id = game.teams.nextId++;
    list.push({ id, name: t("score.team_default", { n: list.length + 1 }) });
  }), "btn small");
  return [
    el("p", { className: "muted small", textContent: caption }),
    list.length ? el("table", { className: "score-table" }, el("thead", {}, head), el("tbody", {}, ...rows))
      : el("p", { className: "muted", textContent: t("score.no_teams") }),
    add,
  ];
}

function render() {
  const modes = ["tv", "teams"].map((mode) => {
    const radio = el("input", { type: "radio", name: "score-mode", value: mode, checked: game.mode === mode });
    radio.addEventListener("change", () => change(() => { game.mode = mode; }));
    return el("label", { className: "check" }, radio, ` ${t(`score.mode_${mode}`)}`);
  });
  const reset = button(t("score.new_game"), t("score.new_game"), async () => {
    if (await confirmDialog(t("score.new_game_confirm"), t("dialog.continue"))) change(() => { game = freshGame(game); });
  }, "btn small");
  const group = el("div", { className: "score-modes", role: "radiogroup" }, ...modes);
  group.setAttribute("aria-label", t("score.mode"));
  $("score-body").replaceChildren(group,
    el("div", { className: `score-${game.mode}` }, ...(game.mode === "tv" ? renderTv() : renderTeams())),
    reset);
}

// Called by play.js whenever a question opens (null when nothing is open).
export function setScoreQuestion(q) {
  question = q ? { id: q.id, label: q.number_label ?? q.position } : null;
  if (game?.mode === "teams") render();
}

export function initScoreboard() {
  game = load();
  render();
}
