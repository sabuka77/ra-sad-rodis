// Import preview table: one editable row per parsed question, with warnings, merge-with-next and delete.
import { t } from "./i18n.js";

const MORE_FIELDS = [["tour", "input"], ["accepted", "input"], ["not_accepted", "input"], ["comment", "textarea"],
  ["author", "input"], ["handout_text", "textarea"]];
const MERGE_FIELDS = ["text", "answer", "accepted", "not_accepted", "comment", "author", "handout_text", "sources_text"];
export const CHECKED_FIELDS = new Set(["number_label", "text", "answer", "tour"]);

const URL_RE = /(?:https?:\/\/|www\.)[^\s<>"«»“”]+/i;

function el(tag, props = {}, ...children) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

export function sourcesToText(sources) {
  return (sources || []).map((s) => s.text || s.url || "").join("\n");
}

function cleanUrl(url) {
  url = url.replace(/[.,;:!?'’]+$/, "");
  while (/[)\]]$/.test(url)) {
    const close = url.at(-1);
    const open = close === ")" ? "(" : "[";
    if (url.split(close).length <= url.split(open).length) break;
    url = url.slice(0, -1).replace(/[.,;:!?'’]+$/, "");
  }
  return url;
}

// Same rules as the server's parse_sources for one source per line.
export function textToSources(text) {
  return (text || "").split("\n")
    .map((line) => line.replace(/^\s*(?:\d{1,3}[.)]|[-•–])\s*/, "").trim())
    .filter(Boolean)
    .map((line) => {
      const match = line.match(URL_RE);
      return { text: line, url: match ? cleanUrl(match[0]) : null };
    });
}

export function warningText(w) {
  const number = w.code === "duplicate_db" ? (w.number ? `№ ${w.number}` : "") : w.number;
  return t(`import.warn.${w.code}`, { ...w, number });
}

function field(row, name, kind, label, rows = 2) {
  const control = el(kind, { value: row[name] ?? "" });
  control.dataset.field = name;
  if (kind === "textarea") control.rows = rows;
  if (label) return el("label", { className: "field" }, el("span", { textContent: label }), control);
  return control;
}

function renderRow(row, i, total) {
  const n = i + 1;
  const tr = el("tr", { className: "imp-row" });
  tr.dataset.index = String(i);
  const number = field(row, "number_label", "input");
  number.setAttribute("aria-label", t("questions.field_number"));
  const text = field(row, "text", "textarea", null, 4);
  text.setAttribute("aria-label", t("questions.field_text"));
  const more = el("details", { className: "imp-more" }, el("summary", { textContent: t("import.more") }),
    ...MORE_FIELDS.map(([name, kind]) => field(row, name, kind, t(`questions.field_${name}`))));
  const answer = field(row, "answer", "textarea", null, 3);
  answer.setAttribute("aria-label", t("questions.field_answer"));
  const sources = field(row, "sources_text", "textarea", null, 3);
  sources.setAttribute("aria-label", t("questions.field_sources"));
  const merge = el("button", { type: "button", className: "btn small", textContent: t("import.merge"), disabled: n === total });
  merge.dataset.action = "merge";
  merge.setAttribute("aria-label", t("import.merge_aria", { n }));
  const remove = el("button", { type: "button", className: "btn small danger", textContent: t("import.delete_row") });
  remove.dataset.action = "delete";
  remove.setAttribute("aria-label", t("import.delete_aria", { n }));
  tr.append(
    el("td", { className: "imp-num" }, el("span", { className: "imp-n muted", textContent: `${n}.` }), number),
    el("td", { className: "imp-q" }, text, more),
    el("td", {}, answer),
    el("td", {}, sources),
    el("td", {}, el("ul", { className: "imp-warn" })),
    el("td", { className: "imp-actions" }, merge, remove),
  );
  return tr;
}

export function renderRows(tbody, rows, fileName) {
  const out = [];
  let lastFile = null;
  rows.forEach((row, i) => {
    if (row.fileId !== lastFile) {
      lastFile = row.fileId;
      out.push(el("tr", { className: "imp-file-row" },
        el("th", { colSpan: 6, textContent: t("import.row_file", { name: fileName(row.fileId) }) })));
    }
    out.push(renderRow(row, i, rows.length));
  });
  tbody.replaceChildren(...out);
  renderWarnings(tbody, rows);
}

export function renderWarnings(tbody, rows) {
  for (const tr of tbody.querySelectorAll("tr.imp-row")) {
    const list = rows[Number(tr.dataset.index)]?.warnings ?? [];
    tr.querySelector(".imp-warn").replaceChildren(...list.map((w) => el("li", { textContent: warningText(w) })));
    tr.classList.toggle("has-warn", list.length > 0);
  }
}

// Rows without question text or answer get a red mark; returns their indexes.
export function markMissing(tbody, rows, indexes = null) {
  const bad = indexes ?? rows.flatMap((r, i) => (r.text.trim() && r.answer.trim() ? [] : [i]));
  for (const tr of tbody.querySelectorAll("tr.imp-row")) {
    const invalid = bad.includes(Number(tr.dataset.index));
    tr.classList.toggle("invalid", invalid);
    for (const name of ["text", "answer"]) {
      const control = tr.querySelector(`[data-field="${name}"]`);
      if (invalid && !rows[Number(tr.dataset.index)][name].trim()) control.setAttribute("aria-invalid", "true");
      else control.removeAttribute("aria-invalid");
    }
  }
  return bad;
}

export function mergeWithNext(rows, i) {
  const [a, b] = [rows[i], rows[i + 1]];
  for (const name of MERGE_FIELDS) {
    a[name] = [a[name], b[name]].map((v) => (v ?? "").trim()).filter(Boolean).join("\n");
  }
  rows.splice(i + 1, 1);
}
