// UI strings from i18n/ka.json. Elements opt in with data-i18n="section.key"
// (also data-i18n-aria, data-i18n-placeholder, data-i18n-title for those attributes).
let strings = {};

export async function loadStrings() {
  const res = await fetch("/static/i18n/ka.json", { cache: "no-cache" });
  if (!res.ok) throw new Error(`ka.json: ${res.status}`);
  strings = await res.json();
}

// t("questions.import_done", { title: "…" }) fills {title} placeholders.
export function t(key, vars = {}) {
  const value = key.split(".").reduce((node, part) => node?.[part], strings);
  if (typeof value !== "string") return key;
  return value.replace(/\{(\w+)\}/g, (match, name) => (name in vars ? String(vars[name]) : match));
}

const ATTRIBUTES = { i18nAria: "aria-label", i18nPlaceholder: "placeholder", i18nTitle: "title" };

export function applyStrings(root = document) {
  for (const el of root.querySelectorAll("[data-i18n]")) el.textContent = t(el.dataset.i18n);
  for (const [prop, attr] of Object.entries(ATTRIBUTES)) {
    const selector = `[data-${prop.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`)}]`;
    for (const el of root.querySelectorAll(selector)) el.setAttribute(attr, t(el.dataset[prop]));
  }
}
