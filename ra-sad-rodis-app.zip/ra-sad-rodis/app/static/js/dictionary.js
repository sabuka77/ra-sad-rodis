// Settings: pronunciation dictionary editor ("written → spoken"). Every change is saved at once
// (PUT /api/settings) and the preview line shows how a sample text will be read with it.
import { getJSON, putJSON } from "./api.js";
import { t } from "./i18n.js";

let entries = [];
let hooks = {};
let previewTimer;

const $ = (id) => document.getElementById(id);

function input(value, placeholder, onChange) {
  const field = Object.assign(document.createElement("input"), { value, placeholder, autocomplete: "off" });
  field.setAttribute("aria-label", placeholder);
  field.addEventListener("change", () => onChange(field.value));
  return field;
}

function render() {
  const rows = entries.map((entry, i) => {
    const remove = Object.assign(document.createElement("button"), { type: "button", className: "btn small icon", textContent: "×" });
    remove.setAttribute("aria-label", t("settings.dict_remove"));
    remove.title = t("settings.dict_remove");
    remove.addEventListener("click", () => { entries.splice(i, 1); render(); save(); });
    const row = document.createElement("div");
    row.className = "dict-row";
    row.append(
      input(entry.written, t("settings.dict_written"), (v) => { entry.written = v; save(); }),
      Object.assign(document.createElement("span"), { className: "dict-arrow", textContent: "→", ariaHidden: "true" }),
      input(entry.spoken, t("settings.dict_spoken"), (v) => { entry.spoken = v; save(); }),
      remove,
    );
    return row;
  });
  if (!rows.length) rows.push(Object.assign(document.createElement("p"), { className: "muted small", textContent: t("settings.dict_empty") }));
  $("dict-rows").replaceChildren(...rows);
}

async function save() {
  // a row without the written form is kept on screen but not saved yet
  const clean = entries.map((e) => ({ written: e.written.trim(), spoken: e.spoken.trim() })).filter((e) => e.written);
  try {
    hooks.onSaved(await putJSON("/api/settings", { pronunciation_dict: clean }));
    hooks.status("ok", t("settings.saved"));
    preview();
  } catch (error) {
    hooks.status("error", error.status === 422 ? t("settings.invalid") : t("errors.request_failed"));
  }
}

async function preview() {
  const text = $("dict-try").value.trim();
  if (!text) {
    $("dict-preview").textContent = "";
    return;
  }
  try {
    const { spoken } = await getJSON(`/api/speech/preview?${new URLSearchParams({ text })}`);
    if ($("dict-try").value.trim() === text) $("dict-preview").textContent = t("settings.dict_preview", { spoken });
  } catch (error) {
    $("dict-preview").textContent = t("errors.request_failed");
  }
}

export function initDictionary(settings, options) {
  hooks = options;
  entries = settings.pronunciation_dict.map((e) => ({ ...e }));
  render();
  $("dict-add").addEventListener("click", () => {
    entries.push({ written: "", spoken: "" });
    render();
    $("dict-rows").lastElementChild.querySelector("input").focus();
  });
  $("dict-try").addEventListener("input", () => {
    clearTimeout(previewTimer);
    previewTimer = setTimeout(preview, 300);
  });
}
