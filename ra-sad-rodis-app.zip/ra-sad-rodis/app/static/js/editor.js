// Questions tab: the question form (create, edit, duplicate, delete, sources, handout image).
import { deleteJSON, getJSON, postJSON, putJSON, uploadFile } from "./api.js";
import { confirmDialog } from "./dialog.js";
import { t } from "./i18n.js";
import { closeListen, initListen } from "./listen.js";

const TEXT_FIELDS = ["tour", "number_label", "text", "spoken_override", "answer", "accepted",
  "not_accepted", "comment", "author", "handout_text"];
const NEW_PACKAGE = "__new";

const state = { id: null, image: null, dirty: false, packages: [] };
let hooks = {};
let form;

const $ = (id) => document.getElementById(id);

function el(tag, props = {}, ...children) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

export function setStatus(target, kind, message, ...extra) {
  target.className = `status ${kind}`;
  target.replaceChildren(message, ...extra);
  target.hidden = !message;
}

const status = (kind, message, ...extra) => setStatus($("q-status"), kind, message, ...extra);

export function errorText(error) {
  return `${t("errors.request_failed")}${error.status ? ` (${error.status})` : ""}`;
}

// ---------- packages select ----------

export function setPackages(packages) {
  state.packages = packages;
  const select = $("q-package");
  const current = select.value;
  select.replaceChildren(
    ...(packages.length ? [] : [el("option", { value: "", textContent: "—", disabled: true })]),
    ...packages.map((p) => el("option", { value: String(p.id), textContent: p.title })),
    el("option", { value: NEW_PACKAGE, textContent: t("questions.package_new_option") }),
  );
  select.value = packages.some((p) => String(p.id) === current) ? current : String(packages[0]?.id ?? "");
  select.dataset.previous = select.value;
}

async function onPackageChange() {
  const select = $("q-package");
  if (select.value !== NEW_PACKAGE) {
    select.dataset.previous = select.value;
    return;
  }
  const id = await hooks.createPackage();
  select.value = id ? String(id) : select.dataset.previous;
  select.dataset.previous = select.value;
}

function nextNumber(packageId) {
  const pkg = state.packages.find((p) => p.id === Number(packageId));
  return pkg ? String(pkg.question_count + 1) : "";
}

// ---------- sources ----------

function addSourceRow(source = { text: "", url: "" }) {
  const remove = el("button", { type: "button", className: "btn small icon", textContent: "×" });
  remove.setAttribute("aria-label", t("questions.source_remove"));
  const row = el("div", { className: "source-row" },
    el("input", { className: "source-text", value: source.text ?? "", placeholder: t("questions.source_text") }),
    el("input", { className: "source-url", value: source.url ?? "", placeholder: t("questions.source_url"), inputMode: "url" }),
    remove);
  remove.addEventListener("click", () => { row.remove(); state.dirty = true; });
  $("q-sources").append(row);
  return row;
}

function collectSources() {
  return [...document.querySelectorAll("#q-sources .source-row")]
    .map((row) => ({ text: row.querySelector(".source-text").value.trim(),
      url: row.querySelector(".source-url").value.trim() || null }))
    .filter((s) => s.text || s.url);
}

// ---------- handout image ----------

function showImage(name) {
  state.image = name;
  const img = $("q-image-preview");
  img.hidden = !name;
  img.src = name ? `/api/uploads/${name}` : "";
  $("q-image-remove").hidden = !name;
}

async function onImageChosen(event) {
  const file = event.target.files[0];
  event.target.value = "";
  if (!file) return;
  try {
    showImage((await uploadFile("/api/uploads", file)).name);
    state.dirty = true;
  } catch (error) {
    status("error", error.status === 415 ? t("questions.image_failed") : errorText(error));
  }
}

// ---------- fill / collect ----------

function fill(question, title) {
  for (const name of TEXT_FIELDS) form.elements[name].value = question[name] ?? "";
  if (question.package_id) $("q-package").value = String(question.package_id);
  $("q-package").dataset.previous = $("q-package").value;
  $("q-sources").replaceChildren();
  (question.sources ?? []).forEach((s) => addSourceRow(s));
  if (!question.sources?.length) addSourceRow();
  showImage(question.handout_image ?? null);
  for (const field of form.querySelectorAll("[aria-invalid]")) field.removeAttribute("aria-invalid");
  $("q-form-title").textContent = title;
  $("q-delete").disabled = state.id === null;
  state.dirty = false;
  closeListen();
  hooks.onSelect?.(state.id);
}

export function openQuestion(question) {
  state.id = question.id;
  status("", "");
  const number = question.number_label ?? question.position;
  fill(question, `${t("questions.form_edit")} · ${t("questions.number_short")}${number}`);
}

export function newQuestion({ package_id, tour } = {}, { focus = false } = {}) {
  state.id = null;
  const packageId = package_id ?? $("q-package").value;
  fill({ package_id: packageId, tour, number_label: nextNumber(packageId) }, t("questions.form_new"));
  if (focus) form.elements.text.focus();
}

export const currentId = () => state.id;
export const isDirty = () => state.dirty;
export const currentPackageId = () => Number($("q-package").value) || null;

export async function confirmDiscard() {
  return !state.dirty || confirmDialog(t("questions.discard_confirm"), t("dialog.continue"));
}

function collect() {
  const data = { package_id: Number($("q-package").value), sources: collectSources(), handout_image: state.image };
  for (const name of TEXT_FIELDS) data[name] = form.elements[name].value;
  const missing = ["text", "answer"].filter((name) => !data[name].trim());
  for (const name of ["text", "answer"]) form.elements[name].toggleAttribute("aria-invalid", missing.includes(name));
  if (missing.length) {
    status("error", t("questions.required"));
    form.elements[missing[0]].focus();
    return null;
  }
  if (!data.package_id) {
    status("error", t("questions.choose_package"));
    return null;
  }
  return data;
}

// ---------- actions ----------

function duplicatesNote(duplicates) {
  const links = duplicates.map((d) => {
    const link = el("button", { type: "button", className: "link",
      textContent: t("questions.duplicate_ref", { package: d.package_title, number: d.number_label ?? "?" }) });
    link.addEventListener("click", async () => openQuestion(await getJSON(`/api/questions/${d.id}`)));
    return link;
  });
  return el("span", { className: "dup-links" }, ...links);
}

async function save(andNew) {
  const data = collect();
  if (!data) return;
  try {
    const saved = state.id === null
      ? await postJSON("/api/questions", data)
      : await putJSON(`/api/questions/${state.id}`, data);
    state.dirty = false;
    await hooks.onChanged();
    if (andNew) newQuestion({ package_id: saved.package_id, tour: saved.tour }, { focus: true });
    else openQuestion(saved);
    if (saved.duplicates.length) status("warn", `${t("questions.duplicate_warning")} `, duplicatesNote(saved.duplicates));
    else status("ok", t("questions.saved"));
  } catch (error) {
    status("error", error.status === 422 ? t("questions.invalid") : errorText(error));
  }
}

function duplicate() {
  if (collect() === null) return;
  state.id = null;
  $("q-form-title").textContent = t("questions.form_copy");
  $("q-delete").disabled = true;
  state.dirty = true;
  hooks.onSelect?.(null);
  status("info", t("questions.copy_ready"));
}

async function remove() {
  if (state.id === null || !(await confirmDialog(t("questions.delete_confirm"), t("dialog.delete")))) return;
  try {
    await deleteJSON(`/api/questions/${state.id}`);
    await hooks.onChanged();
    newQuestion();
    status("ok", t("questions.deleted"));
  } catch (error) {
    status("error", errorText(error));
  }
}

export function initEditor(options) {
  hooks = options;
  form = $("q-form");
  form.addEventListener("submit", (event) => { event.preventDefault(); save(false); });
  form.addEventListener("input", (event) => { if (!event.target.closest("#q-listen-panel")) state.dirty = true; });
  $("q-save-new").addEventListener("click", () => save(true));
  $("q-duplicate").addEventListener("click", duplicate);
  $("q-delete").addEventListener("click", remove);
  $("q-package").addEventListener("change", onPackageChange);
  $("q-source-add").addEventListener("click", () => addSourceRow().querySelector("input").focus());
  $("q-image-file").addEventListener("change", onImageChosen);
  $("q-image-remove").addEventListener("click", () => { showImage(null); state.dirty = true; });
  initListen(form, status);
}
