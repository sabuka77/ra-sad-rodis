// Thin fetch wrapper: JSON in, JSON out, errors carry the server's detail.
async function request(method, url, body) {
  const options = { method, headers: {} };
  if (body instanceof FormData) {
    options.body = body; // the browser sets the multipart boundary
  } else if (body !== undefined) {
    options.headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(body);
  }
  const res = await fetch(url, options);
  const data = res.headers.get("content-type")?.includes("application/json") ? await res.json() : null;
  if (!res.ok) {
    const error = new Error(`${method} ${url}: ${res.status}`);
    error.status = res.status;
    error.detail = data?.detail;
    throw error;
  }
  return data;
}

export const getJSON = (url) => request("GET", url);
export const putJSON = (url, body) => request("PUT", url, body);
export const patchJSON = (url, body) => request("PATCH", url, body);
export const postJSON = (url, body) => request("POST", url, body);
export const deleteJSON = (url) => request("DELETE", url);

export function uploadFile(url, file) {
  const form = new FormData();
  form.append("file", file);
  return request("POST", url, form);
}
