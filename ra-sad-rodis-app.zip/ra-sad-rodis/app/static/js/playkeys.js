// Play-tab keyboard shortcuts with the „?“ cheat sheet, fullscreen and the A−/A+ question font size.
// Shortcuts act only while the Play tab is shown, never while typing in a field or while a dialog is open.
// Letters are matched by physical key (event.code), so they also work with the Georgian keyboard layout.
import { unlockAudio } from "./timer.js";

const FONT_MIN = 32;
const FONT_MAX = 96;
const FONT_STEP = 4;

const BY_CODE = {
  Space: "toggleTimer", KeyR: "readAgain", KeyS: "stopSpeech", KeyA: "toggleAnswer",
  ArrowRight: "next", ArrowLeft: "prev", KeyF: "fullscreen",
};

const $ = (id) => document.getElementById(id);

function typing(target) {
  return target instanceof HTMLElement && (target.isContentEditable || Boolean(target.closest("input, textarea, select")));
}

function toggleFullscreen() {
  if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
  else document.documentElement.requestFullscreen?.().catch(() => {});
}

function actionFor(event) {
  if (event.key === "?" || (event.shiftKey && event.code === "Slash")) return "help";
  if (event.key === "+" || event.code === "NumpadAdd") return "addTime";
  return event.shiftKey ? null : BY_CODE[event.code] ?? null;
}

// actions: {toggleTimer, readAgain, stopSpeech, toggleAnswer, next, prev, addTime, fontSize(), setFontSize(px)}
export function initPlayKeys(actions) {
  const help = $("play-help");
  const all = { ...actions, fullscreen: toggleFullscreen, help: () => help.showModal() };
  let swallowSpaceUp = false;

  const changeFont = (delta) => {
    const current = actions.fontSize();
    const next = Math.min(FONT_MAX, Math.max(FONT_MIN, current + delta));
    if (delta < 0 ? next < current : next > current) actions.setFontSize(next);
  };
  $("play-font-down").addEventListener("click", () => changeFont(-FONT_STEP));
  $("play-font-up").addEventListener("click", () => changeFont(FONT_STEP));
  $("play-fullscreen").addEventListener("click", toggleFullscreen);
  $("play-help-open").addEventListener("click", all.help);
  document.addEventListener("fullscreenchange", () => {
    $("play-fullscreen").setAttribute("aria-pressed", String(Boolean(document.fullscreenElement)));
  });

  // The timer's AudioContext may only start after a user gesture.
  document.addEventListener("pointerdown", unlockAudio, true);

  document.addEventListener("keydown", (event) => {
    unlockAudio();
    if ($("tab-play").hidden || event.ctrlKey || event.altKey || event.metaKey || event.isComposing) return;
    if (typing(event.target) || document.querySelector("dialog[open]")) return;
    const action = actionFor(event);
    if (!action) return;
    // app.js already moves between the tab buttons with ←/→ when one of them has focus.
    if ((action === "next" || action === "prev") && event.target.closest?.("[data-tab]")) return;
    event.preventDefault();
    if (action === "toggleTimer") swallowSpaceUp = true; // a focused button would click on keyup
    if (event.repeat) return;
    all[action]();
  });
  document.addEventListener("keyup", (event) => {
    if (event.code === "Space" && swallowSpaceUp) {
      swallowSpaceUp = false;
      event.preventDefault();
    }
  });
}
