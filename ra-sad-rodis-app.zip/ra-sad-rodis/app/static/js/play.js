// Play tab: package picker (in order / shuffled / skip played), "N / total", prev / next / jump,
// question text with the speech player, timer, answer reveal (marks the question played).
// When a question opens its audio is prepared and the next question's audio is prefetched.
import { getJSON, postJSON, putJSON } from "./api.js";
import { t } from "./i18n.js";
import { AnswerPanel } from "./answer.js";
import { initPlayKeys } from "./playkeys.js";
import { initScoreboard, setScoreQuestion } from "./scoreboard.js";
import { Player, prefetch } from "./player.js";
import { applyDisplaySettings, settingsChanged } from "./settings.js";
import { Timer } from "./timer.js";

const PREFS_KEY = "rsr.play"; // {packageId, order, skip}
const $ = (id) => document.getElementById(id);

const state = { settings: null, packages: [], all: [], seq: [], index: 0, textShown: true, readerState: "idle" };
let player;
let timer;
let answer;

const current = () => state.seq[state.index];
const packageId = () => $("play-package").value;
const staged = () => !$("play-stage").hidden; // a question is on screen

function loadPrefs() {
  try { return JSON.parse(localStorage.getItem(PREFS_KEY)) || {}; } catch { return {}; }
}

function savePrefs() {
  const prefs = { packageId: packageId(), order: $("play-order").value, skip: $("play-skip").checked };
  try { localStorage.setItem(PREFS_KEY, JSON.stringify(prefs)); } catch { /* private mode */ }
}

function shuffle(list) {
  const out = [...list];
  for (let i = out.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

function packageLabel(p) {
  return t("play.package_option", { title: p.title, count: p.question_count, played: p.played_count });
}

async function loadPackages() {
  state.packages = await getJSON("/api/packages");
  const select = $("play-package");
  const wanted = select.value || String(loadPrefs().packageId ?? "");
  select.replaceChildren(...state.packages.map((p) => new Option(packageLabel(p), p.id)));
  const known = state.packages.some((p) => String(p.id) === wanted);
  select.value = known ? wanted : String(state.packages[0]?.id ?? "");
}

// Fetch the package's questions and build the playing order from scratch.
async function buildSequence() {
  savePrefs();
  state.all = packageId() ? await getJSON(`/api/questions?package_id=${packageId()}`) : [];
  const list = $("play-skip").checked ? state.all.filter((q) => !q.played_at) : state.all;
  state.seq = $("play-order").value === "shuffle" ? shuffle(list) : list;
  open(0);
}

// Back on the tab: keep the order, drop deleted questions, take edits, append new unplayed ones.
async function refreshSequence() {
  const openId = current()?.id;
  const before = current()?.updated_at;
  state.all = await getJSON(`/api/questions?package_id=${packageId()}`);
  const byId = new Map(state.all.map((q) => [q.id, q]));
  const kept = state.seq.filter((q) => byId.has(q.id)).map((q) => byId.get(q.id));
  const known = new Set(kept.map((q) => q.id));
  const added = state.all.filter((q) => !known.has(q.id) && !q.played_at);
  state.seq = [...kept, ...added];
  const index = state.seq.findIndex((q) => q.id === openId);
  if (index >= 0 && state.seq[index].updated_at === before) {
    state.index = index;
    renderNav();
  } else open(Math.max(0, index));
}

function emptyKey() {
  if (!state.packages.length) return "play.empty_no_packages";
  if (!state.all.length) return "play.empty_package";
  if (!state.seq.length) return "play.empty_all_played";
  return null;
}

function open(index) {
  const empty = emptyKey();
  $("play-empty").hidden = !empty;
  $("play-stage").hidden = Boolean(empty);
  if (empty) {
    player.stop();
    answer.stopSpeech();
    setScoreQuestion(null);
    $("play-empty-text").textContent = t(empty);
    $("play-empty-link").hidden = empty === "play.empty_all_played";
    return;
  }
  player.stop(); // before the new text is covered, so stopping the old reading does not uncover it
  state.index = Math.max(0, Math.min(index, state.seq.length - 1));
  const q = current();
  renderQuestion(q);
  answer.set(q);
  setScoreQuestion(q);
  timer.reset();
  player.load({ questionId: q.id }).catch(() => {}); // the player shows its own error
  const next = state.seq[state.index + 1];
  if (next) prefetch({ questionId: next.id }).catch(() => {});
}

function renderNav() {
  const q = current();
  const total = state.seq.length;
  $("play-counter").textContent = t("play.counter", { n: state.index + 1, total });
  const parts = [q.tour, q.number_label && t("play.number", { n: q.number_label })].filter(Boolean);
  if (q.played_at) parts.push(t("questions.played"));
  $("play-label").textContent = parts.join(" · ");
  $("play-prev").disabled = state.index === 0;
  $("play-next").disabled = state.index >= total - 1;
  $("play-jump-n").max = String(total);
}

function renderQuestion(q) {
  renderNav();
  $("play-jump-n").value = "";
  $("play-jump-n").removeAttribute("aria-invalid");
  $("play-handout").hidden = !q.handout_text && !q.handout_image;
  $("play-handout-text").textContent = q.handout_text ?? "";
  $("play-handout-text").hidden = !q.handout_text;
  const img = $("play-handout-img");
  img.hidden = !q.handout_image;
  if (q.handout_image) img.src = `/api/uploads/${encodeURIComponent(q.handout_image)}`;
  else img.removeAttribute("src");
  // With a spoken override the player shows (and highlights) the override; the host sees the real text.
  $("play-qtext").hidden = !q.spoken_override;
  $("play-qtext").textContent = q.text;
  $("play-player").classList.toggle("override", Boolean(q.spoken_override));
  setTextShown(state.settings.show_text_while_reading);
}

// "Show text while reading" off: the text stays covered until the first reading ends or is stopped.
function setTextShown(shown) {
  state.textShown = shown;
  $("play-text-wrap").classList.toggle("text-covered", !shown);
  $("play-text-hidden").hidden = shown;
}

function go(step) {
  const index = state.index + step;
  if (index >= 0 && index < state.seq.length) open(index);
}

function jump(event) {
  event.preventDefault();
  const input = $("play-jump-n");
  const n = Number(input.value);
  if (!Number.isInteger(n) || n < 1 || n > state.seq.length) {
    input.setAttribute("aria-invalid", "true");
    input.focus();
    return;
  }
  input.blur(); // shortcuts work again right away
  open(n - 1);
}

async function markPlayed(q) {
  if (q.played_at) return;
  try {
    q.played_at = (await postJSON(`/api/questions/${q.id}/mark-played`)).played_at;
    const pkg = state.packages.find((p) => p.id === q.package_id);
    if (pkg) {
      pkg.played_count += 1;
      const option = [...$("play-package").options].find((o) => o.value === String(pkg.id));
      if (option) option.textContent = packageLabel(pkg);
    }
    if (q === current()) renderNav();
  } catch (error) {
    console.error(error);
  }
}

async function saveSettings(patch) {
  try {
    state.settings = await putJSON("/api/settings", patch);
    applyDisplaySettings(state.settings);
    settingsChanged(state.settings);
  } catch (error) {
    console.error(error);
  }
}

function stopSpeech() {
  player.stop();
  answer.stopSpeech();
}

// Called on start and every time the Play tab is shown (settings or questions may have changed).
async function refresh() {
  try {
    const first = !state.settings;
    state.settings = await getJSON("/api/settings");
    timer.configure(state.settings, { resetDuration: first });
    $("play-show-text").checked = state.settings.show_text_while_reading;
    const before = packageId();
    await loadPackages();
    if (first || packageId() !== before || !state.seq.length) await buildSequence();
    else await refreshSequence();
  } catch (error) {
    console.error(error);
    $("play-empty").hidden = false;
    $("play-stage").hidden = true;
    $("play-empty-text").textContent = t("errors.load_failed");
  }
}

export async function initPlay() {
  player = new Player($("play-player"));
  player.addEventListener("statechange", (e) => {
    const was = state.readerState;
    state.readerState = e.detail;
    if (e.detail === "idle" && (was === "playing" || was === "paused") && !state.textShown) setTextShown(true);
  });
  player.addEventListener("end", (e) => {
    if (e.detail.full && state.settings.timer_autostart && timer.pristine) timer.start();
  });
  timer = new Timer({
    root: $("timer"), display: $("timer-display"), message: $("timer-message"), toggle: $("timer-toggle"),
    reset: $("timer-reset"), presets: $("timer-presets"), addSmall: $("timer-add-small"), addLarge: $("timer-add-large"),
  });
  answer = new AnswerPanel({ onReveal: markPlayed });
  initScoreboard();

  const prefs = loadPrefs();
  $("play-order").value = prefs.order === "shuffle" ? "shuffle" : "order";
  $("play-skip").checked = Boolean(prefs.skip);
  for (const id of ["play-package", "play-order", "play-skip"]) $(id).addEventListener("change", buildSequence);
  $("play-show-text").addEventListener("change", (e) => {
    saveSettings({ show_text_while_reading: e.target.checked });
    if (e.target.checked) setTextShown(true);
  });
  $("play-prev").addEventListener("click", () => go(-1));
  $("play-next").addEventListener("click", () => go(1));
  $("play-jump").addEventListener("submit", jump);

  initPlayKeys({
    toggleTimer: () => staged() && timer.toggle(),
    readAgain: () => staged() && player.readAgain(),
    stopSpeech,
    toggleAnswer: () => staged() && answer.toggle(),
    next: () => go(1),
    prev: () => go(-1),
    addTime: () => staged() && timer.add(state.settings.extra_time_small_s),
    fontSize: () => state.settings.font_size_px,
    setFontSize: (px) => saveSettings({ font_size_px: px }),
  });
  window.addEventListener("hashchange", () => { if (!$("tab-play").hidden) refresh(); });
  await refresh();
}
