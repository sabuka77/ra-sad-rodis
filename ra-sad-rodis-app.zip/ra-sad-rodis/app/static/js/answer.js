// Play-tab answer panel: hidden until „პასუხის ჩვენება“; shows the answer, accepted / not accepted,
// the comment with [n] links to the numbered sources (links open in a new tab), the author,
// and 🔊 reads the answer aloud. onReveal(question) is called every time the panel is opened.
import { t } from "./i18n.js";
import { Player } from "./player.js";

const $ = (id) => document.getElementById(id);

function el(tag, props = {}, ...children) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

export class AnswerPanel {
  #question = null;
  #voice;
  #onReveal;

  constructor({ onReveal }) {
    this.#onReveal = onReveal;
    this.#voice = new Player($("answer-voice"), { controls: false });
    this.#voice.addEventListener("statechange", (e) => {
      $("answer-speak").textContent = t(e.detail === "playing" || e.detail === "paused" ? "play.answer_speak_stop" : "play.answer_speak");
    });
    $("answer-speak").textContent = t("play.answer_speak");
    $("answer-toggle").addEventListener("click", () => this.toggle());
    $("answer-speak").addEventListener("click", () => this.speak());
  }

  get shown() { return !$("answer-panel").hidden; }

  set(question) {
    this.#question = question;
    this.#setShown(false);
  }

  toggle() { this.#setShown(!this.shown); }

  stopSpeech() { this.#voice.stop(); }

  async speak() {
    const voice = this.#voice;
    if (voice.state === "playing" || voice.state === "paused") {
      voice.stop();
      return;
    }
    try {
      await voice.load({ questionId: this.#question.id, field: "answer" });
      voice.play();
    } catch (error) {
      console.error(error); // the player shows the message
    }
  }

  #setShown(shown) {
    $("answer-panel").hidden = !shown;
    const toggle = $("answer-toggle");
    toggle.textContent = t(shown ? "play.answer_hide" : "play.answer_show");
    toggle.setAttribute("aria-expanded", String(shown));
    toggle.classList.toggle("primary", !shown);
    if (!shown) {
      this.#voice.stop();
      return;
    }
    this.#render();
    this.#onReveal(this.#question);
  }

  #render() {
    const q = this.#question;
    $("answer-text").textContent = q.answer;
    const row = (key, ...content) => el("div", { className: "answer-row" },
      el("dt", { textContent: t(key) }), el("dd", {}, ...content));
    const rows = [];
    if (q.accepted) rows.push(row("questions.field_accepted", q.accepted));
    if (q.not_accepted) rows.push(row("questions.field_not_accepted", q.not_accepted));
    if (q.comment) rows.push(row("questions.field_comment", ...this.#comment(q.comment, q.sources.length)));
    if (q.sources.length) rows.push(row("questions.field_sources", this.#sources(q.sources)));
    if (q.author) rows.push(row("questions.field_author", q.author));
    $("answer-meta").replaceChildren(...rows);
  }

  // "… იხ. [2]" → text with a button that jumps to source 2 (only for numbers that exist).
  #comment(text, count) {
    return text.split(/(\[\d+\])/).map((part) => {
      const n = /^\[\d+\]$/.test(part) ? Number(part.slice(1, -1)) : 0;
      if (n < 1 || n > count) return part;
      const link = el("button", { type: "button", className: "link src-ref", textContent: part,
        title: t("play.source_ref", { n }) });
      link.addEventListener("click", () => this.#focusSource(n));
      return link;
    });
  }

  #sources(list) {
    return el("ol", { className: "answer-sources", id: "answer-sources" }, ...list.map((s, i) => {
      const item = el("li", { tabIndex: -1 });
      item.dataset.n = String(i + 1);
      if (s.url) item.append(el("a", { href: s.url, target: "_blank", rel: "noopener", title: s.url, textContent: s.text || s.url }));
      else item.append(s.text);
      return item;
    }));
  }

  #focusSource(n) {
    const item = document.querySelector(`#answer-sources li[data-n="${n}"]`);
    if (!item) return;
    item.scrollIntoView({ block: "nearest", behavior: "smooth" });
    item.focus({ preventScroll: true });
    item.classList.remove("flash");
    void item.offsetWidth; // restart the animation
    item.classList.add("flash");
  }
}
