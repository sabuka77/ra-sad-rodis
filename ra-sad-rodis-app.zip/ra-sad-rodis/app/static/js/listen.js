// Questions tab „მოსმენა“: shows the normalized text that will be spoken and plays it
// (the spoken override if filled, else the question text; unsaved edits included).
import { t } from "./i18n.js";
import { Player } from "./player.js";

let player = null;
let form;
let showStatus;

const $ = (id) => document.getElementById(id);

async function listen() {
  const text = form.elements.spoken_override.value.trim() || form.elements.text.value.trim();
  if (!text) {
    showStatus("error", t("questions.listen_empty"));
    form.elements.text.focus();
    return;
  }
  player ??= new Player($("q-listen-player"));
  $("q-listen-panel").hidden = false;
  $("q-listen-spoken").textContent = "";
  try {
    const data = await player.load({ text });
    $("q-listen-spoken").textContent = data.segments.map((s) => s.spoken).join(" ");
    player.play();
  } catch (error) {
    console.error(error); // the player shows the message
  }
}

export function closeListen() {
  player?.stop();
  if ($("q-listen-panel")) $("q-listen-panel").hidden = true;
}

export function initListen(questionForm, status) {
  form = questionForm;
  showStatus = status;
  $("q-listen").addEventListener("click", listen);
  $("q-listen-close").addEventListener("click", closeListen);
}
