// App shell: loads strings and settings, switches tabs via the URL hash (#play, #questions, ...).
import { getJSON } from "./api.js";
import { applyStrings, loadStrings, t } from "./i18n.js";
import { initImport } from "./importer.js";
import { initPlay } from "./play.js";
import { initQuestions } from "./questions.js";
import { stopAll } from "./player.js";
import { applyDisplaySettings, initSettings } from "./settings.js";

const TABS = ["play", "questions", "import", "settings"];

function currentTab() {
  const name = location.hash.slice(1);
  return TABS.includes(name) ? name : "play";
}

function showTab(name) {
  for (const button of document.querySelectorAll("[data-tab]")) {
    const selected = button.dataset.tab === name;
    button.setAttribute("aria-selected", String(selected));
    button.tabIndex = selected ? 0 : -1;
  }
  for (const panel of document.querySelectorAll(".tab-panel")) {
    panel.hidden = panel.id !== `tab-${name}`;
  }
}

function setupTabs() {
  const buttons = [...document.querySelectorAll("[data-tab]")];
  for (const button of buttons) {
    button.addEventListener("click", () => { location.hash = button.dataset.tab; });
    button.addEventListener("keydown", (event) => {
      if (event.key !== "ArrowRight" && event.key !== "ArrowLeft") return;
      const step = event.key === "ArrowRight" ? 1 : -1;
      const next = buttons[(buttons.indexOf(button) + step + buttons.length) % buttons.length];
      next.focus();
      location.hash = next.dataset.tab;
    });
  }
  window.addEventListener("hashchange", () => { stopAll(); showTab(currentTab()); });
  showTab(currentTab());
}

export function showBanner(message) {
  const banner = document.getElementById("banner");
  banner.textContent = message;
  banner.hidden = false;
}

async function main() {
  await loadStrings();
  applyStrings();
  document.title = t("app.title");
  setupTabs();
  try {
    const settings = await getJSON("/api/settings");
    applyDisplaySettings(settings);
    initSettings(settings);
    await Promise.all([initQuestions(), initPlay(), initImport()]);
  } catch (error) {
    console.error(error);
    showBanner(t("errors.load_failed"));
  }
}

main().catch((error) => {
  console.error(error);
  showBanner("შეცდომა: გვერდი ვერ ჩაიტვირთა. / Error: the page could not load.");
});
