// Settings: pre-generate a package's audio for offline games, with a progress bar.
// The job runs on the server; this page only starts, cancels and polls it (so a reload keeps showing it).
import { deleteJSON, getJSON, postJSON } from "./api.js";
import { t } from "./i18n.js";

const POLL_MS = 700;
let hooks = {};
let pollTimer;

const $ = (id) => document.getElementById(id);

function show(status) {
  const bar = $("pregen-progress");
  const total = status.total || 0;
  bar.hidden = !status.running && !status.done;
  bar.max = Math.max(total, 1);
  bar.value = status.done;
  const noPackages = !$("pregen-package").options.length;
  $("pregen-start").disabled = status.running || noPackages;
  $("pregen-cancel").hidden = !status.running;
  let message = "";
  if (status.running) message = t("settings.pregen_progress", { done: status.done, total });
  else if (status.cancelled) message = t("settings.pregen_cancelled", { done: status.done, total });
  else if (status.package_id !== null && status.failed) {
    message = t("settings.pregen_done_failed", { ok: status.done - status.failed, total, failed: status.failed });
  } else if (status.package_id !== null) message = t("settings.pregen_done", { total });
  else if (noPackages) message = t("settings.pregen_no_packages");
  $("pregen-status").textContent = message;
}

async function poll() {
  clearTimeout(pollTimer);
  try {
    const status = await getJSON("/api/tts/pregenerate");
    show(status);
    if (status.running) pollTimer = setTimeout(poll, POLL_MS);
    else hooks.onFinished();
  } catch (error) {
    $("pregen-status").textContent = t("errors.request_failed");
  }
}

async function start() {
  const packageId = Number($("pregen-package").value);
  if (!packageId) return;
  try {
    show(await postJSON("/api/tts/pregenerate", { package_id: packageId }));
    poll();
  } catch (error) {
    const key = error.detail === "browser_provider" ? "settings.pregen_browser"
      : error.detail === "busy" ? "settings.pregen_busy" : "errors.request_failed";
    $("pregen-status").textContent = t(key);
  }
}

async function cancel() {
  try {
    show(await deleteJSON("/api/tts/pregenerate"));
    hooks.onFinished();
  } catch (error) {
    $("pregen-status").textContent = t("errors.request_failed");
  }
}

async function loadPackages() {
  const select = $("pregen-package");
  const previous = select.value;
  try {
    const packages = await getJSON("/api/packages");
    select.replaceChildren(...packages.map((p) => new Option(`${p.title} · ${p.question_count}`, String(p.id))));
    if (packages.some((p) => String(p.id) === previous)) select.value = previous;
    select.disabled = !packages.length;
    if (!packages.length) {
      $("pregen-status").textContent = t("settings.pregen_no_packages");
      $("pregen-start").disabled = true;
    }
  } catch (error) {
    $("pregen-status").textContent = t("errors.request_failed");
  }
}

export function initOffline(options) {
  hooks = options;
  $("pregen-start").addEventListener("click", start);
  $("pregen-cancel").addEventListener("click", cancel);
  window.addEventListener("hashchange", () => { if (location.hash === "#settings") loadPackages(); });
  loadPackages().then(poll); // a job started before a reload keeps showing its progress
}
