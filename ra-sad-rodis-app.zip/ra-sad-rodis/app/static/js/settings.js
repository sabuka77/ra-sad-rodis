// Settings tab: every field saves itself on change (PUT /api/settings, partial update),
// voice test, audio cache size and clearing. Theme and font size apply immediately.
// The Azure key comes back masked ("********"); the dictionary and offline cards have their own modules.
import { deleteJSON, getJSON, putJSON } from "./api.js";
import { initDictionary } from "./dictionary.js";
import { t } from "./i18n.js";
import { initOffline } from "./offline.js";
import { Player } from "./player.js";

let current = null;
let testPlayer = null;
let form;

const $ = (id) => document.getElementById(id);

export function applyDisplaySettings(settings) {
  document.documentElement.dataset.theme = settings.theme;
  document.documentElement.style.setProperty("--fs-question", `${settings.font_size_px}px`);
}

function status(kind, message) {
  const box = $("settings-status");
  box.className = `status ${kind}`;
  box.textContent = message;
  box.hidden = !message;
}

function showOutput(input) {
  const output = form.querySelector(`output[data-for="${input.name}"]`);
  if (!output) return;
  const unit = output.dataset.unit === "ms" ? ` ${t("settings.ms_short")}` : output.dataset.unit;
  output.value = `${input.value}${unit}`;
}

function fillForm(settings) {
  for (const input of form.elements) {
    if (!input.name || !(input.name in settings) || Array.isArray(settings[input.name])) continue;
    if (input.type === "checkbox") input.checked = settings[input.name];
    else input.value = String(settings[input.name]);
    showOutput(input);
  }
  showProviderFields();
}

function showProviderFields() {
  $("azure-fields").hidden = form.elements.tts_provider.value !== "azure";
}

function valueOf(input) {
  if (input.type === "checkbox") return input.checked;
  if (input.type === "range" || input.type === "number") return input.value === "" ? NaN : Number(input.value);
  return input.value;
}

async function save(input) {
  const value = valueOf(input);
  if (Number.isNaN(value)) {
    status("error", t("settings.invalid"));
    fillForm(current);
    return;
  }
  try {
    current = await putJSON("/api/settings", { [input.name]: value });
    applyDisplaySettings(current);
    if (input.name === "azure_key") input.value = current.azure_key; // don't keep the key in the page
    status("ok", t("settings.saved"));
  } catch (error) {
    status("error", error.status === 422 ? t("settings.invalid") : t("errors.request_failed"));
    fillForm(current);
  }
}

async function voiceTest() {
  testPlayer ??= new Player($("voice-test-player"));
  try {
    await testPlayer.load({ text: t("settings.voice_test_text") });
    testPlayer.play();
  } catch (error) {
    console.error(error); // the player shows the message
  }
}

function formatBytes(bytes) {
  return bytes < 1024 * 1024 ? `${Math.ceil(bytes / 1024)} KB` : `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

async function showCache(info) {
  try {
    info ??= await getJSON("/api/tts/cache");
    $("cache-info").textContent = t("settings.cache_info", { files: info.files, size: formatBytes(info.bytes) });
  } catch (error) {
    $("cache-info").textContent = t("errors.request_failed");
  }
}

async function clearCache() {
  try {
    testPlayer?.stop();
    await showCache(await deleteJSON("/api/tts/cache"));
  } catch (error) {
    $("cache-info").textContent = t("errors.request_failed");
  }
}

// Another tab saved settings (Play: A−/A+, show text while reading): keep this form in step.
export function settingsChanged(settings) {
  current = settings;
  if (form) fillForm(settings);
}

export function initSettings(settings) {
  current = settings;
  form = $("settings-form");
  fillForm(settings);
  form.addEventListener("submit", (event) => event.preventDefault());
  form.addEventListener("input", (event) => showOutput(event.target));
  form.addEventListener("change", (event) => {
    if (event.target.name) save(event.target);
    showProviderFields();
  });
  form.elements.azure_key.addEventListener("focus", (event) => event.target.select());
  $("voice-test").addEventListener("click", voiceTest);
  $("cache-clear").addEventListener("click", clearCache);
  $("cache-refresh").addEventListener("click", () => showCache());
  window.addEventListener("hashchange", () => { if (location.hash === "#settings") showCache(); });
  showCache();
  initDictionary(settings, { onSaved: (saved) => { current = saved; }, status });
  initOffline({ onFinished: () => showCache() });
}
