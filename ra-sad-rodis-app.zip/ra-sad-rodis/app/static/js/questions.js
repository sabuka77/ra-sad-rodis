// Questions tab: package toolbar (create, rename, delete, export/import JSON), searchable list, reorder.
import { deleteJSON, getJSON, patchJSON, postJSON } from "./api.js";
import { askText, confirmDialog } from "./dialog.js";
import * as editor from "./editor.js";
import { t } from "./i18n.js";

const FILTER_KEY = "rsr.questions.package";
const state = { packages: [], filter: "", search: "", list: [] };

const $ = (id) => document.getElementById(id);
const toolbarStatus = (kind, message) => editor.setStatus($("pkg-status"), kind, message);
const selectedPackage = () => state.packages.find((p) => String(p.id) === state.filter);

function remember(value) {
  try { localStorage.setItem(FILTER_KEY, value); } catch { /* storage unavailable */ }
}

function recall() {
  try { return localStorage.getItem(FILTER_KEY) ?? ""; } catch { return ""; }
}

// ---------- data ----------

async function loadPackages() {
  state.packages = await getJSON("/api/packages");
  if (!selectedPackage()) state.filter = "";
  const select = $("pkg-filter");
  const options = [new Option(t("questions.all_packages"), ""),
    ...state.packages.map((p) => new Option(p.title, String(p.id)))];
  select.replaceChildren(...options);
  select.value = state.filter;
  for (const id of ["pkg-rename", "pkg-export", "pkg-reset", "pkg-delete"]) $(id).disabled = !state.filter;
  editor.setPackages(state.packages);
}

async function loadList() {
  const params = new URLSearchParams();
  if (state.filter) params.set("package_id", state.filter);
  if (state.search) params.set("q", state.search);
  state.list = await getJSON(`/api/questions?${params}`);
  renderList();
}

async function refresh() {
  await loadPackages();
  await loadList();
}

// ---------- list ----------

function iconButton(text, label, onClick) {
  const button = Object.assign(document.createElement("button"), { type: "button", className: "btn small icon", textContent: text });
  button.setAttribute("aria-label", label);
  button.title = label;
  button.addEventListener("click", onClick);
  return button;
}

function span(className, text) {
  return Object.assign(document.createElement("span"), { className, textContent: text });
}

function renderItem(q, i) {
  const li = document.createElement("li");
  li.className = "q-item";
  li.dataset.id = q.id;
  li.classList.toggle("selected", q.id === editor.currentId());
  const open = Object.assign(document.createElement("button"), { type: "button", className: "q-open" });
  open.append(span("q-num", `${t("questions.number_short")}${q.number_label ?? q.position}`),
    span("q-text", q.text), span("q-answer", q.answer));
  if (!state.filter) open.append(span("q-pkg", state.packages.find((p) => p.id === q.package_id)?.title ?? ""));
  open.addEventListener("click", async () => {
    if (await editor.confirmDiscard()) editor.openQuestion(q);
  });

  const actions = document.createElement("div");
  actions.className = "q-actions";
  if (q.played_at) {
    actions.append(span("badge played", t("questions.played")),
      iconButton("↺", t("questions.reset_played"), () => run(async () => {
        await postJSON(`/api/questions/${q.id}/reset-played`);
        await refresh();
      })));
  }
  // without a search the list shows whole packages in order, so the ends of a package can't move further
  const first = !state.search && state.list[i - 1]?.package_id !== q.package_id;
  const last = !state.search && state.list[i + 1]?.package_id !== q.package_id;
  const up = iconButton("↑", t("questions.move_up"), () => move(q.id, "up"));
  const down = iconButton("↓", t("questions.move_down"), () => move(q.id, "down"));
  up.disabled = first;
  down.disabled = last;
  up.dataset.move = "up";
  down.dataset.move = "down";
  actions.append(up, down);
  li.append(open, actions);
  return li;
}

function renderList() {
  const list = $("q-list");
  list.replaceChildren(...state.list.map(renderItem));
  if (!state.packages.length) list.append(Object.assign(document.createElement("li"), { className: "empty", textContent: t("questions.no_packages") }));
  else if (!state.list.length) list.append(Object.assign(document.createElement("li"), { className: "empty",
    textContent: t(state.search ? "questions.no_results" : "questions.empty_list") }));
  const pkg = selectedPackage();
  $("q-count").textContent = pkg && !state.search
    ? t("questions.package_count", { count: pkg.question_count, played: pkg.played_count })
    : t("questions.count", { shown: state.list.length });
}

function markSelected(id) {
  for (const li of document.querySelectorAll("#q-list .q-item")) li.classList.toggle("selected", Number(li.dataset.id) === id);
}

async function move(id, direction) {
  await run(async () => {
    await postJSON(`/api/questions/${id}/move`, { direction });
    await loadList();
    const button = document.querySelector(`#q-list [data-id="${id}"] [data-move="${direction}"]`);
    (button && !button.disabled ? button : document.querySelector(`#q-list [data-id="${id}"] .q-open`))?.focus();
  });
}

// ---------- packages toolbar ----------

async function run(action) {
  try {
    await action();
  } catch (error) {
    console.error(error);
    toolbarStatus("error", editor.errorText(error));
  }
}

async function setFilter(value) {
  state.filter = value;
  remember(value);
  await refresh();
}

// An untouched new-question form follows the chosen package (and its next number).
function followFilter() {
  if (state.filter && editor.currentId() === null && !editor.isDirty()) editor.newQuestion({ package_id: state.filter });
}

async function createPackage() {
  const title = await askText(t("questions.package_name"));
  if (!title) return null;
  const pkg = await postJSON("/api/packages", { title });
  await setFilter(String(pkg.id));
  return pkg.id;
}

async function renamePackage() {
  const pkg = selectedPackage();
  const title = pkg && (await askText(t("questions.package_name"), pkg.title));
  if (!title) return;
  await patchJSON(`/api/packages/${pkg.id}`, { title });
  await refresh();
}

async function deletePackage() {
  const pkg = selectedPackage();
  if (!pkg) return;
  const message = t("questions.package_delete_confirm", { title: pkg.title, count: pkg.question_count });
  if (!(await confirmDialog(message, t("dialog.delete")))) return;
  await deleteJSON(`/api/packages/${pkg.id}`);
  const editingDeleted = editor.currentPackageId() === pkg.id;
  await setFilter("");
  if (editingDeleted) editor.newQuestion({ package_id: state.packages[0]?.id });
}

function exportPackage() {
  const link = Object.assign(document.createElement("a"), { href: `/api/packages/${state.filter}/export`, download: "" });
  link.click();
}

// Shows a package in this tab (used after any import, also from the Import tab).
export async function showPackage(id) {
  await setFilter(String(id));
  followFilter();
}

// Imports one JSON export as a new package; also used by the Import tab for .json files.
// Throws with status 422 when the file is not a valid export.
export async function importJsonFile(file) {
  let doc;
  try {
    doc = JSON.parse(await file.text());
  } catch {
    throw Object.assign(new Error("invalid JSON"), { status: 422 });
  }
  if (doc?.package?.title && state.packages.some((p) => p.title === doc.package.title)) {
    doc.package.title = `${doc.package.title} ${t("questions.copy_suffix")}`;
  }
  const pkg = await postJSON("/api/packages/import", doc);
  await showPackage(pkg.id);
  return pkg;
}

async function importPackage(event) {
  const file = event.target.files[0];
  event.target.value = "";
  if (!file) return;
  try {
    const pkg = await importJsonFile(file);
    toolbarStatus("ok", t("questions.import_done", { title: pkg.title, count: pkg.question_count }));
  } catch (error) {
    toolbarStatus("error", error.status === 422 ? t("questions.import_failed") : editor.errorText(error));
  }
}

async function resetPackagePlayed() {
  await postJSON(`/api/packages/${state.filter}/reset-played`);
  await refresh();
  toolbarStatus("ok", t("questions.reset_played_all_done"));
}

export async function initQuestions() {
  editor.initEditor({ onChanged: refresh, onSelect: markSelected, createPackage });
  const toolbar = [["pkg-new", async () => { if (await createPackage()) followFilter(); }], ["pkg-rename", renamePackage], ["pkg-delete", deletePackage],
    ["pkg-export", exportPackage], ["pkg-reset", resetPackagePlayed], ["pkg-import", () => $("pkg-import-file").click()]];
  for (const [id, action] of toolbar) {
    $(id).addEventListener("click", () => { toolbarStatus("", ""); run(action); });
  }
  $("pkg-import-file").addEventListener("change", importPackage);
  $("pkg-filter").addEventListener("change", (event) => run(async () => {
    await setFilter(event.target.value);
    followFilter();
  }));
  let timer;
  $("q-search").addEventListener("input", (event) => {
    clearTimeout(timer);
    timer = setTimeout(() => { state.search = event.target.value.trim(); run(loadList); }, 250);
  });
  $("q-new").addEventListener("click", async () => {
    if (await editor.confirmDiscard()) editor.newQuestion({ package_id: state.filter || undefined }, { focus: true });
  });
  state.filter = recall();
  await refresh();
  remember(state.filter);
  editor.newQuestion({ package_id: state.filter || state.packages[0]?.id });
}
