// Discussion timer for the Play tab. The remaining time is always computed from performance.now()
// (an end time while running), never decremented per tick, so it stays exact in a background tab.
// Signals come from the Web Audio API: a short beep at 10 s left and a falling three-tone end signal.
import { t } from "./i18n.js";

const WARN_MS = 10_000;
let audio = null;

// Browsers start an AudioContext suspended until a user gesture: call this from click/keydown.
export function unlockAudio() {
  const Context = window.AudioContext || window.webkitAudioContext;
  if (!audio && Context) audio = new Context();
  if (audio?.state === "suspended") audio.resume().catch(() => {});
}

function tone(freq, startS, lengthS, gain) {
  if (!audio) return;
  const osc = audio.createOscillator();
  const volume = audio.createGain();
  const at = audio.currentTime + startS;
  osc.type = "sine";
  osc.frequency.value = freq;
  volume.gain.setValueAtTime(0.0001, at);
  volume.gain.exponentialRampToValueAtTime(gain, at + 0.02);
  volume.gain.exponentialRampToValueAtTime(0.0001, at + lengthS);
  osc.connect(volume).connect(audio.destination);
  osc.start(at);
  osc.stop(at + lengthS + 0.05);
}

const warnBeep = () => tone(880, 0, 0.2, 0.3);
const endSignal = () => { tone(784, 0, 0.3, 0.4); tone(587, 0.35, 0.3, 0.4); tone(392, 0.7, 0.9, 0.45); };

function format(ms) {
  const s = Math.ceil(ms / 1000);
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

export class Timer {
  #durationMs = 60_000;
  #remainingMs = 60_000; // used while not running
  #endAt = 0; // performance.now() value at which a running countdown reaches 0
  #running = false;
  #warned = false;
  #interval = null;
  #ui;
  #small = 10;
  #large = 30;

  // ui: {root, display, message, toggle, reset, presets, addSmall, addLarge}
  constructor(ui) {
    this.#ui = ui;
    ui.toggle.addEventListener("click", () => this.toggle());
    ui.reset.addEventListener("click", () => this.reset());
    ui.addSmall.addEventListener("click", () => this.add(this.#small));
    ui.addLarge.addEventListener("click", () => this.add(this.#large));
    document.addEventListener("visibilitychange", () => this.#tick());
    this.#render();
  }

  get running() { return this.#running; }
  // Untouched since the last reset (used for auto-start after reading).
  get pristine() { return !this.#running && this.#remainingMs === this.#durationMs; }

  // settings: timer_default_s, timer_presets, extra_time_small_s, extra_time_large_s
  configure(settings, { resetDuration = false } = {}) {
    this.#small = settings.extra_time_small_s;
    this.#large = settings.extra_time_large_s;
    this.#ui.addSmall.textContent = t("play.timer_add", { n: this.#small });
    this.#ui.addLarge.textContent = t("play.timer_add", { n: this.#large });
    const presets = [...new Set(settings.timer_presets)];
    this.#ui.presets.replaceChildren(...presets.map((s) => {
      const button = Object.assign(document.createElement("button"), {
        type: "button", className: "btn", textContent: t("play.timer_preset", { n: s }) });
      button.dataset.seconds = String(s);
      button.addEventListener("click", () => this.setDuration(s));
      return button;
    }));
    if (resetDuration) this.setDuration(settings.timer_default_s);
    else this.#render();
  }

  remaining() {
    return this.#running ? Math.max(0, this.#endAt - performance.now()) : this.#remainingMs;
  }

  start() {
    if (this.#running) return;
    if (this.#remainingMs <= 0) this.#remainingMs = this.#durationMs; // start after 0 = full round again
    this.#warned = this.#remainingMs <= WARN_MS;
    this.#endAt = performance.now() + this.#remainingMs;
    this.#running = true;
    this.#interval = setInterval(() => this.#tick(), 100);
    this.#render();
  }

  pause() {
    if (!this.#running) return;
    this.#remainingMs = this.remaining();
    this.#halt();
  }

  toggle() { if (this.#running) this.pause(); else this.start(); }

  reset() {
    this.#remainingMs = this.#durationMs;
    this.#warned = false;
    this.#halt();
  }

  setDuration(seconds) {
    this.#durationMs = seconds * 1000;
    this.reset();
  }

  // Extra time: while running or paused it is added; after 0 the countdown restarts from it.
  add(seconds) {
    const ms = seconds * 1000;
    if (this.#running) this.#endAt += ms;
    else if (this.#remainingMs <= 0) {
      this.#remainingMs = ms;
      this.start();
    } else this.#remainingMs += ms;
    if (this.remaining() > WARN_MS) this.#warned = false;
    this.#render();
  }

  #halt() {
    this.#running = false;
    clearInterval(this.#interval);
    this.#interval = null;
    this.#render();
  }

  #tick() {
    if (this.#running) {
      const left = this.remaining();
      if (left <= 0) {
        this.#remainingMs = 0;
        this.#halt();
        endSignal();
        return;
      }
      if (!this.#warned && left <= WARN_MS) {
        this.#warned = true;
        warnBeep();
      }
    }
    this.#render();
  }

  #render() {
    const ui = this.#ui;
    const left = this.remaining();
    const over = left <= 0;
    ui.display.textContent = format(left);
    ui.root.dataset.state = over ? "over" : left <= WARN_MS ? "warn" : "normal";
    ui.message.hidden = !over;
    ui.toggle.textContent = t(this.#running ? "play.timer_pause"
      : this.pristine || over ? "play.timer_start" : "play.timer_resume");
    for (const button of ui.presets.children) {
      button.setAttribute("aria-pressed", String(Number(button.dataset.seconds) * 1000 === this.#durationMs));
    }
  }
}
