// Browser Web Speech fallback: a Georgian voice (lang "ka…") if the browser has one.
// Microsoft Edge has Georgian online voices; Chrome usually has none.

const pick = () => speechSynthesis.getVoices().find((v) => v.lang?.toLowerCase().startsWith("ka")) ?? null;

export function findGeorgianVoice() {
  if (!("speechSynthesis" in window)) return Promise.resolve(null);
  const voice = pick();
  if (voice) return Promise.resolve(voice);
  return new Promise((resolve) => { // voices load asynchronously on first use
    const done = () => {
      clearTimeout(timer);
      speechSynthesis.removeEventListener("voiceschanged", onChange);
      resolve(pick());
    };
    const onChange = () => { if (pick()) done(); };
    const timer = setTimeout(done, 1500);
    speechSynthesis.addEventListener("voiceschanged", onChange);
  });
}

// Speaks one segment; resolves when it ends (or fails). rate_pct is the segment's server rate.
export function speakSegment(segment, voice, speed) {
  return new Promise((resolve) => {
    const utterance = new SpeechSynthesisUtterance(segment.spoken);
    utterance.voice = voice;
    utterance.lang = voice.lang;
    utterance.rate = Math.min(Math.max((1 + segment.rate_pct / 100) * speed, 0.1), 10);
    utterance.onend = () => resolve(true);
    utterance.onerror = () => resolve(true);
    speechSynthesis.speak(utterance);
  });
}

export const pauseSpeech = () => window.speechSynthesis?.pause();
export const resumeSpeech = () => window.speechSynthesis?.resume();
export const cancelSpeech = () => window.speechSynthesis?.cancel();
