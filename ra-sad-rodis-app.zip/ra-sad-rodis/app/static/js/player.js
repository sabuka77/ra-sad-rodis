// Reusable speech player. Renders the text (sentences highlighted and clickable) and the controls
// into a container, plays the server's segment list with the configured gaps, and falls back to the
// browser's Web Speech voice when the server reports a provider failure.
//
//   const player = new Player(container);
//   await player.load({ text }) | player.load({ questionId, field: "text" | "answer" });
//   player.play() · readAgain() · pause() · resume() · stop() · playSentence(k) · setSpeed(x)
//   player.addEventListener("end", (e) => e.detail.full)   // reading finished on its own
//   player.addEventListener("statechange", (e) => e.detail) // idle | loading | playing | paused
import { postJSON } from "./api.js";
import { t } from "./i18n.js";
import { cancelSpeech, findGeorgianVoice, pauseSpeech, resumeSpeech, speakSegment } from "./webspeech.js";

const MAX_BLOBS = 400;
const blobs = new Map(); // audio url → Promise<object URL>, shared by all players
const players = new Set();
const SPEED_KEY = "rsr.speechSpeed";

function fetchAudio(url) {
  if (!blobs.has(url)) {
    const promise = fetch(url).then(async (res) => {
      if (!res.ok) throw Object.assign(new Error(`audio ${res.status}`), { status: res.status });
      return URL.createObjectURL(await res.blob());
    });
    promise.catch(() => blobs.delete(url)); // a later attempt may succeed (e.g. back online)
    blobs.set(url, promise);
    if (blobs.size > MAX_BLOBS) {
      const [oldUrl, oldPromise] = blobs.entries().next().value;
      blobs.delete(oldUrl);
      oldPromise.then(URL.revokeObjectURL, () => {});
    }
  }
  return blobs.get(url);
}

function prepareBody(source) {
  return source.questionId != null ? { question_id: source.questionId, field: source.field ?? "text" }
    : { text: source.text };
}

// Prepare and download all audio of a text or question in the background (next-question prefetch).
export async function prefetch(source) {
  const data = await postJSON("/api/tts/prepare", prepareBody(source));
  for (const s of data.segments) if (s.url) fetchAudio(s.url).catch(() => {});
  return data;
}

export function stopAll() {
  for (const player of players) player.stop();
}

function loadSpeed() {
  try { return Number(localStorage.getItem(SPEED_KEY)) || 1; } catch { return 1; }
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

function el(tag, props = {}, ...children) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

export class Player extends EventTarget {
  #data = null;
  #sentences = []; // [{start, end, node}]
  #pending = new Map(); // url → audio promise of the loaded text
  #mode = "server";
  #state = "idle";
  #gen = 0; // bumped by stop(): a running loop with an older value quits
  #loads = 0;
  #loading = Promise.resolve();
  #paused = false;
  #abort = null;
  #speed = loadSpeed();
  #audio = new Audio();
  #ui = {};

  constructor(container, { controls = true } = {}) {
    super();
    this.container = container;
    this.#build(controls);
    players.add(this);
  }

  get state() { return this.#state; }
  get data() { return this.#data; }

  // ---------- public API ----------

  load(source) {
    this.stop();
    const token = ++this.#loads;
    this.#setState("loading");
    this.#message("", "");
    this.#loading = postJSON("/api/tts/prepare", prepareBody(source)).then((data) => {
      if (token !== this.#loads) return data;
      this.#data = data;
      this.#mode = data.provider === "browser" ? "browser" : "server";
      this.#pending = new Map(data.segments.filter((s) => s.url).map((s) => [s.url, fetchAudio(s.url)]));
      for (const promise of this.#pending.values()) promise.catch(() => {});
      this.#renderText();
      this.#setState("idle");
      return data;
    }, (error) => {
      if (token === this.#loads) {
        this.#data = null;
        this.#renderText();
        this.#setState("idle");
        this.#message("error", t("player.prepare_failed"));
      }
      throw error;
    });
    return this.#loading;
  }

  async play() {
    await this.#loading.catch(() => {});
    if (this.#state === "paused") this.resume();
    else if (this.#state === "idle") this.readAgain();
  }

  readAgain() {
    if (!this.#data?.segments.length) return;
    this.#run(this.#data.segments.map((s) => s.i), true);
  }

  playSentence(k) {
    const { start, end } = this.#sentences[k];
    this.#run(this.#data.segments.filter((s) => s.start === start && s.end === end).map((s) => s.i), false);
  }

  pause() {
    if (this.#state !== "playing") return;
    this.#paused = true;
    if (this.#mode === "server") this.#audio.pause();
    else pauseSpeech();
    this.#setState("paused");
  }

  resume() {
    if (this.#state !== "paused") return;
    this.#paused = false;
    if (this.#mode === "server") { if (this.#abort) this.#audio.play().catch(() => {}); } else resumeSpeech();
    this.#setState("playing");
  }

  stop() {
    this.#gen += 1;
    this.#paused = false;
    const abort = this.#abort;
    this.#abort = null;
    abort?.();
    this.#audio.pause();
    if (this.#mode === "browser") cancelSpeech();
    this.#highlight(-1);
    if (this.#state !== "loading") this.#setState("idle");
  }

  setSpeed(speed) {
    this.#speed = speed;
    this.#audio.defaultPlaybackRate = this.#audio.playbackRate = speed;
    try { localStorage.setItem(SPEED_KEY, String(speed)); } catch { /* private mode */ }
    if (this.#ui.speed) {
      this.#ui.speed.value = String(speed);
      this.#ui.speedOut.value = t("player.speed_value", { x: speed.toFixed(2) });
    }
  }

  destroy() {
    this.stop();
    players.delete(this);
    this.container.replaceChildren();
  }

  // ---------- playback ----------

  async #run(indices, full) {
    for (const other of players) if (other !== this) other.stop();
    this.stop();
    const gen = this.#gen;
    this.#setState("playing");
    for (const [n, i] of indices.entries()) {
      const segment = this.#data.segments[i];
      this.#highlight(this.#sentenceOf(segment));
      const spoken = await this.#speak(segment, gen);
      if (!spoken || gen !== this.#gen) return;
      if (n < indices.length - 1) await this.#gap(segment.pause_after_ms / this.#speed, gen);
      if (gen !== this.#gen) return;
    }
    this.#highlight(-1);
    this.#setState("idle");
    this.dispatchEvent(new CustomEvent("end", { detail: { full } }));
  }

  // Resolves to false when stop() interrupts the promise, otherwise to the promise's value.
  #interruptible(promise) {
    return new Promise((resolve) => {
      const abort = () => resolve(false);
      this.#abort = abort;
      promise.then((value) => {
        if (this.#abort === abort) this.#abort = null;
        resolve(value);
      });
    });
  }

  async #speak(segment, gen) {
    if (this.#mode === "server") {
      try {
        const src = await (this.#pending.get(segment.url) ?? fetchAudio(segment.url));
        if (gen !== this.#gen) return false;
        return await this.#interruptible(this.#playAudio(src));
      } catch (error) {
        console.warn("server speech failed, using the browser voice", error);
        this.#mode = "browser";
        this.#message("warn", t("player.fallback"));
      }
    }
    const voice = await findGeorgianVoice();
    if (gen !== this.#gen) return false;
    if (!voice) {
      // the host chose the browser voice: don't blame the server
      this.#message("error", t(this.#data?.provider === "browser" ? "player.no_voice_browser" : "player.no_voice"));
      this.stop();
      return false;
    }
    return this.#interruptible(speakSegment(segment, voice, this.#speed));
  }

  #playAudio(src) {
    const audio = this.#audio;
    return new Promise((resolve) => {
      audio.onended = audio.onerror = () => resolve(true); // a broken file is skipped
      audio.src = src;
      audio.defaultPlaybackRate = audio.playbackRate = this.#speed;
      if (!this.#paused) audio.play().catch((error) => { if (error.name !== "AbortError") resolve(true); });
    });
  }

  async #gap(ms, gen) {
    let left = ms;
    while (left > 0 && gen === this.#gen) {
      const step = Math.min(left, 50);
      await sleep(step);
      if (!this.#paused) left -= step;
    }
  }

  // ---------- rendering ----------

  #build(controls) {
    const text = el("div", { className: "player-text" });
    text.lang = "ka";
    const status = el("p", { className: "status", hidden: true });
    status.setAttribute("role", "status");
    this.#ui = { text, status };
    const parts = [text];
    if (controls) {
      const button = (key, onClick, extra = "") => {
        const b = el("button", { type: "button", className: `btn ${extra}`, textContent: t(key) });
        b.addEventListener("click", onClick);
        return b;
      };
      const speed = el("input", { type: "range", min: "0.5", max: "1.5", step: "0.05" });
      speed.setAttribute("aria-label", t("player.speed"));
      speed.addEventListener("input", () => this.setSpeed(Number(speed.value)));
      const speedOut = el("output");
      Object.assign(this.#ui, {
        read: button("player.read", () => this.play(), "primary"),
        again: button("player.again", () => this.readAgain()),
        pause: button("player.pause", () => (this.#state === "paused" ? this.resume() : this.pause())),
        stop: button("player.stop", () => this.stop()),
        speed, speedOut,
      });
      const { read, again, pause, stop } = this.#ui;
      parts.push(el("div", { className: "player-controls btn-row" }, read, again, pause, stop,
        el("label", { className: "player-speed" }, el("span", { textContent: t("player.speed") }), speed, speedOut)));
    }
    parts.push(status);
    this.container.replaceChildren(el("div", { className: "player" }, ...parts));
    this.setSpeed(this.#speed);
    this.#setState("idle");
  }

  #renderText() {
    const text = this.#data?.text ?? "";
    const spans = [];
    for (const s of this.#data?.segments ?? []) {
      if (!spans.some((x) => x.start === s.start && x.end === s.end)) spans.push({ start: s.start, end: s.end });
    }
    const nodes = [];
    let pos = 0;
    spans.forEach((span, k) => {
      nodes.push(text.slice(pos, span.start));
      span.node = el("span", { className: "sentence", tabIndex: 0, title: t("player.sentence_hint"),
        textContent: text.slice(span.start, span.end) });
      span.node.setAttribute("role", "button");
      span.node.addEventListener("click", () => this.playSentence(k));
      span.node.addEventListener("keydown", (e) => {
        if (e.key === "Enter") { e.preventDefault(); this.playSentence(k); }
      });
      nodes.push(span.node);
      pos = span.end;
    });
    nodes.push(text.slice(pos));
    this.#sentences = spans;
    this.#ui.text.replaceChildren(...nodes);
  }

  #sentenceOf(segment) {
    return this.#sentences.findIndex((s) => s.start === segment.start && s.end === segment.end);
  }

  #highlight(k) {
    this.#sentences.forEach((s, i) => s.node.classList.toggle("current", i === k));
  }

  #message(kind, message) {
    const { status } = this.#ui;
    status.className = `status ${kind}`;
    status.textContent = message;
    status.hidden = !message;
  }

  #setState(state) {
    this.#state = state;
    const ui = this.#ui;
    if (ui.read) {
      const loaded = Boolean(this.#data?.segments.length);
      ui.read.disabled = !loaded || state === "playing";
      ui.again.disabled = !loaded;
      ui.pause.disabled = state !== "playing" && state !== "paused";
      ui.pause.textContent = t(state === "paused" ? "player.resume" : "player.pause");
      ui.stop.disabled = ui.pause.disabled;
    }
    this.container.dataset.state = state;
    this.dispatchEvent(new CustomEvent("statechange", { detail: state }));
  }
}
