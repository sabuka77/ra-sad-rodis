// One in-page <dialog> for confirmations and short text input (instead of window.confirm/prompt).
import { t } from "./i18n.js";

function open(message, { input = null, okLabel = t("dialog.ok") } = {}) {
  const dialog = document.getElementById("dialog");
  const field = document.getElementById("dialog-input");
  document.getElementById("dialog-message").textContent = message;
  document.getElementById("dialog-ok").textContent = okLabel;
  field.hidden = input === null;
  field.value = input ?? "";
  // Enter would otherwise trigger the first button, which is "cancel"
  field.onkeydown = (event) => {
    if (event.key === "Enter") { event.preventDefault(); dialog.close("ok"); }
  };
  dialog.returnValue = "";
  dialog.showModal();
  if (input !== null) field.select();
  return new Promise((resolve) => {
    dialog.addEventListener("close", () => resolve(dialog.returnValue === "ok"), { once: true });
  });
}

// Resolves to true when the host confirms.
export function confirmDialog(message, okLabel) {
  return open(message, { okLabel });
}

// Resolves to the trimmed text, or null when cancelled or empty.
export async function askText(message, initial = "") {
  const ok = await open(message, { input: initial });
  const value = document.getElementById("dialog-input").value.trim();
  return ok && value ? value : null;
}
