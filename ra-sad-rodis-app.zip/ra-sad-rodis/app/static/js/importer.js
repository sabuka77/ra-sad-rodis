// Import tab: drop/pick files → server parses them (no saving) → editable preview → save into a package.
// .json files are package exports and go straight to the Questions tab's JSON import.
import { getJSON, postJSON } from "./api.js";
import { confirmDialog } from "./dialog.js";
import { errorText } from "./editor.js";
import { t } from "./i18n.js";
import * as table from "./importtable.js";
import { importJsonFile, showPackage } from "./questions.js";

// files: {id, file, name, status: "parsing"|"ok"|"error"|"json", error, count, title, editor, legacy}
const state = { files: [], rows: [], packages: [], nextId: 1, titleTouched: false, checkTimer: null };
const $ = (id) => document.getElementById(id);

function status(id, kind, message) {
  const node = $(id);
  node.className = `status ${kind}`;
  node.textContent = message;
  node.hidden = !message;
}

// ---------- files ----------

function fileStatusText(entry) {
  if (entry.status === "parsing") return t("import.parsing");
  if (entry.status === "error") return entry.error;
  if (entry.status === "json") return entry.message;
  return entry.count ? t("import.file_ok", { count: entry.count }) : t("import.file_none");
}

function renderFiles() {
  $("imp-files").replaceChildren(...state.files.map((entry) => {
    const item = document.createElement("li");
    item.className = `imp-file ${entry.status}${entry.status === "ok" && !entry.count ? " empty" : ""}`;
    const name = Object.assign(document.createElement("strong"), { textContent: entry.name });
    const info = Object.assign(document.createElement("span"), { className: "imp-file-status", textContent: fileStatusText(entry) });
    item.append(name, info);
    if (entry.status === "ok") {
      const box = Object.assign(document.createElement("input"), { type: "checkbox", checked: entry.legacy.applied });
      box.addEventListener("change", () => reparse(entry, box));
      const label = Object.assign(document.createElement("label"), { className: "check imp-legacy" });
      label.append(box, t("import.legacy"));
      if (entry.legacy.detected) label.append(" ", Object.assign(document.createElement("span"), { className: "muted", textContent: t("import.legacy_detected") }));
      item.append(label);
    }
    if (entry.status !== "parsing") {
      const remove = Object.assign(document.createElement("button"), { type: "button", className: "btn small", textContent: "✕" });
      remove.setAttribute("aria-label", `${t("import.remove_file")}: ${entry.name}`);
      remove.addEventListener("click", () => removeFile(entry));
      item.append(remove);
    }
    return item;
  }));
}

function errorMessage(code) {
  return t(`import.errors.${code}`) === `import.errors.${code}` ? t("import.errors.unreadable") : t(`import.errors.${code}`);
}

async function parseEntries(entries, legacy = "auto") {
  const form = new FormData();
  for (const entry of entries) {
    form.append("files", entry.file, entry.name);
    form.append("legacy", legacy);
  }
  try {
    const result = await postJSON("/api/import/parse", form);
    result.files.forEach((info, k) => {
      const entry = entries[k];
      Object.assign(entry, info.error ? { status: "error", error: errorMessage(info.error) }
        : { status: "ok", count: info.count, title: info.title, editor: info.editor, legacy: info.legacy });
    });
    return result.rows.map((row) => ({ ...row, fileId: entries[row.file].id, sources_text: table.sourcesToText(row.sources) }));
  } catch (error) {
    for (const entry of entries) Object.assign(entry, { status: "error", error: errorText(error) });
    return [];
  }
}

async function addFiles(fileList) {
  status("imp-result", "", "");
  const fresh = [];
  for (const file of fileList) {
    if (file.name.toLowerCase().endsWith(".json")) {
      const entry = { id: state.nextId++, file, name: file.name, status: "parsing" };
      state.files.push(entry);
      renderFiles();
      try {
        const pkg = await importJsonFile(file);
        Object.assign(entry, { status: "json", message: t("import.json_done", { title: pkg.title, count: pkg.question_count }) });
      } catch (error) {
        Object.assign(entry, { status: "error", error: error.status === 422 ? t("import.errors.json") : errorText(error) });
      }
      continue;
    }
    fresh.push({ id: state.nextId++, file, name: file.name, status: "parsing" });
  }
  state.files.push(...fresh);
  renderFiles();
  if (fresh.length) {
    state.rows.push(...await parseEntries(fresh));
    await refreshPreview();
  }
  renderFiles();
}

async function reparse(entry, box) {
  const hasRows = state.rows.some((r) => r.fileId === entry.id);
  if (hasRows && !(await confirmDialog(t("import.confirm_reparse"), t("dialog.continue")))) {
    box.checked = !box.checked;
    return;
  }
  const at = state.rows.findIndex((r) => r.fileId === entry.id);
  state.rows = state.rows.filter((r) => r.fileId !== entry.id);
  entry.status = "parsing";
  renderFiles();
  const rows = await parseEntries([entry], box.checked ? "on" : "off");
  state.rows.splice(at < 0 ? state.rows.length : at, 0, ...rows);
  renderFiles();
  await refreshPreview();
}

async function removeFile(entry) {
  state.files = state.files.filter((f) => f !== entry);
  state.rows = state.rows.filter((r) => r.fileId !== entry.id);
  renderFiles();
  await refreshPreview();
}

// ---------- preview ----------

const fileName = (id) => state.files.find((f) => f.id === id)?.name ?? "";

async function refreshPreview() {
  const visible = state.rows.length > 0;
  $("imp-preview").hidden = !visible;
  if (!visible) return;
  if (!state.titleTouched) {
    $("imp-title").value = state.files.find((f) => f.status === "ok" && f.count)?.title ?? "";
  }
  table.renderRows($("imp-rows"), state.rows, fileName);
  await recheck();
}

function summary() {
  const warned = state.rows.filter((r) => r.warnings?.length).length;
  $("imp-summary").textContent = t("import.summary", { count: state.rows.length, warned });
}

async function recheck() {
  clearTimeout(state.checkTimer);
  const rows = state.rows.map((r) => ({ text: r.text, answer: r.answer, number_label: r.number_label, tour: r.tour, file: r.fileId }));
  try {
    const { warnings } = await postJSON("/api/import/check", { rows });
    if (warnings.length === state.rows.length) warnings.forEach((w, i) => { state.rows[i].warnings = w; });
  } catch (error) {
    console.error(error);
  }
  table.renderWarnings($("imp-rows"), state.rows);
  summary();
}

function onRowInput(event) {
  const control = event.target.closest("[data-field]");
  const tr = event.target.closest("tr.imp-row");
  if (!control || !tr) return;
  const row = state.rows[Number(tr.dataset.index)];
  row[control.dataset.field] = control.value;
  if (tr.classList.contains("invalid")) table.markMissing($("imp-rows"), state.rows);
  if (table.CHECKED_FIELDS.has(control.dataset.field)) {
    clearTimeout(state.checkTimer);
    state.checkTimer = setTimeout(recheck, 500);
  }
}

async function onRowClick(event) {
  const button = event.target.closest("button[data-action]");
  if (!button) return;
  const i = Number(button.closest("tr.imp-row").dataset.index);
  if (button.dataset.action === "merge") table.mergeWithNext(state.rows, i);
  else state.rows.splice(i, 1);
  await refreshPreview();
  $("imp-rows").querySelector(`tr.imp-row[data-index="${Math.min(i, state.rows.length - 1)}"] button[data-action]`)?.focus();
}

// ---------- target and save ----------

async function loadPackages() {
  state.packages = await getJSON("/api/packages");
  const select = $("imp-package");
  const keep = select.value;
  select.replaceChildren(...(state.packages.length
    ? state.packages.map((p) => new Option(p.title, String(p.id)))
    : [new Option(t("import.no_packages"), "")]));
  if (state.packages.some((p) => String(p.id) === keep)) select.value = keep;
}

function target() {
  return document.querySelector('input[name="imp-target"]:checked').value;
}

function commitRows() {
  return state.rows.map((r) => ({
    tour: r.tour || null, number_label: r.number_label || null, text: r.text, answer: r.answer,
    accepted: r.accepted, not_accepted: r.not_accepted, comment: r.comment, author: r.author,
    handout_text: r.handout_text, sources: table.textToSources(r.sources_text),
  }));
}

async function save() {
  if (!state.rows.length) return status("imp-status", "error", t("import.no_rows"));
  const missing = table.markMissing($("imp-rows"), state.rows);
  if (missing.length) return status("imp-status", "error", t("import.missing", { count: missing.length }));
  const body = { rows: commitRows() };
  if (target() === "new") {
    const title = $("imp-title").value.trim();
    if (!title) return status("imp-status", "error", t("import.need_title"));
    const names = [...new Set(state.rows.map((r) => fileName(r.fileId)))].join(", ").slice(0, 500);
    const editor = state.files.find((f) => f.status === "ok" && f.editor)?.editor ?? null;
    body.package = { title, source_file: names || null, editor: editor?.slice(0, 300) ?? null };
  } else {
    if (!$("imp-package").value) return status("imp-status", "error", t("import.need_package"));
    body.package_id = Number($("imp-package").value);
  }
  $("imp-save").disabled = true;
  status("imp-status", "", t("import.saving"));
  try {
    const { package: pkg, added } = await postJSON("/api/import/commit", body);
    resetPreview();
    status("imp-result", "ok", t("import.saved", { count: added, title: pkg.title }));
    await showPackage(pkg.id);
    await loadPackages();
  } catch (error) {
    const rows = Array.isArray(error.detail) ? error.detail.filter((d) => d.loc?.[1] === "rows").map((d) => d.loc[2]) : [];
    if (rows.length) {
      table.markMissing($("imp-rows"), state.rows, [...new Set(rows)]);
      status("imp-status", "error", t("import.missing", { count: new Set(rows).size }));
    } else {
      status("imp-status", "error", errorText(error));
    }
  } finally {
    $("imp-save").disabled = false;
  }
}

function resetPreview() {
  Object.assign(state, { files: [], rows: [], titleTouched: false });
  $("imp-title").value = "";
  status("imp-status", "", "");
  renderFiles();
  refreshPreview();
}

async function clearAll() {
  if (state.rows.length && !(await confirmDialog(t("import.confirm_clear"), t("dialog.continue")))) return;
  resetPreview();
  status("imp-result", "", "");
}

// ---------- setup ----------

function setupDrop() {
  const zone = $("imp-drop");
  const importVisible = () => !$("tab-import").hidden;
  // dropping a file anywhere else on the Import tab must not open it in the browser
  for (const type of ["dragover", "drop"]) {
    window.addEventListener(type, (event) => { if (importVisible()) event.preventDefault(); });
  }
  zone.addEventListener("dragover", (event) => { event.preventDefault(); zone.classList.add("over"); });
  zone.addEventListener("dragleave", () => zone.classList.remove("over"));
  zone.addEventListener("drop", (event) => {
    event.preventDefault();
    zone.classList.remove("over");
    if (event.dataTransfer?.files?.length) addFiles([...event.dataTransfer.files]);
  });
}

export function initImport() {
  setupDrop();
  $("imp-pick").addEventListener("click", () => $("imp-file").click());
  $("imp-file").addEventListener("change", (event) => {
    const files = [...event.target.files];
    event.target.value = "";
    if (files.length) addFiles(files);
  });
  $("imp-rows").addEventListener("input", onRowInput);
  $("imp-rows").addEventListener("click", onRowClick);
  $("imp-title").addEventListener("input", () => { state.titleTouched = true; });
  $("imp-package").addEventListener("change", () => { document.querySelector('input[name="imp-target"][value="existing"]').checked = true; });
  $("imp-title").addEventListener("focus", () => { document.querySelector('input[name="imp-target"][value="new"]').checked = true; });
  $("imp-save").addEventListener("click", save);
  $("imp-clear").addEventListener("click", clearAll);
  window.addEventListener("hashchange", () => { if (!$("tab-import").hidden) loadPackages().catch(console.error); });
  return loadPackages();
}
