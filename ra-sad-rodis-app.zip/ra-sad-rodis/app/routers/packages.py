"""Packages API: CRUD, reset played status, JSON export and import (as a new package)."""
import re
import sqlite3
from urllib.parse import quote

from fastapi import APIRouter, HTTPException, Response
from fastapi.responses import JSONResponse

from app import db
from app.models import ExportQuestion, Package, PackageExport, PackageIn
from app.routers.uploads import image_data_uri, remove_unused, save_data_uri

router = APIRouter(prefix="/api/packages", tags=["packages"])

PACKAGE_SQL = (
    "SELECT p.*, COUNT(q.id) AS question_count, COUNT(q.played_at) AS played_count "
    "FROM packages p LEFT JOIN questions q ON q.package_id = p.id"
)


def _get_or_404(conn: sqlite3.Connection, package_id: int) -> dict:
    row = conn.execute(f"{PACKAGE_SQL} WHERE p.id = ? GROUP BY p.id", (package_id,)).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="package_not_found")
    return dict(row)


def _insert_package(conn: sqlite3.Connection, body: PackageIn) -> int:
    return conn.execute(
        "INSERT INTO packages (title, source_file, editor, notes) VALUES (?, ?, ?, ?)",
        (body.title, body.source_file, body.editor, body.notes),
    ).lastrowid


def _pick(model, row: dict):
    return model.model_validate({k: row[k] for k in model.model_fields if k in row})


@router.get("", response_model=list[Package])
def list_packages() -> list[dict]:
    with db.get_conn() as conn:
        rows = conn.execute(f"{PACKAGE_SQL} GROUP BY p.id ORDER BY p.id").fetchall()
    return [dict(r) for r in rows]


@router.post("", response_model=Package, status_code=201)
def create_package(body: PackageIn) -> dict:
    with db.get_conn() as conn:
        return _get_or_404(conn, _insert_package(conn, body))


@router.patch("/{package_id}", response_model=Package)
def update_package(package_id: int, body: PackageIn) -> dict:
    """Rename (and edit the other given fields); fields left out keep their value."""
    changes = body.model_dump(exclude_unset=True)
    with db.get_conn() as conn:
        _get_or_404(conn, package_id)
        conn.execute(f"UPDATE packages SET {', '.join(f'{k} = ?' for k in changes)} WHERE id = ?",
                     [*changes.values(), package_id])
        return _get_or_404(conn, package_id)


@router.delete("/{package_id}", status_code=204)
def delete_package(package_id: int) -> Response:
    with db.get_conn() as conn:
        _get_or_404(conn, package_id)
        images = [r[0] for r in conn.execute("SELECT handout_image FROM questions WHERE package_id = ?", (package_id,))]
        conn.execute("DELETE FROM packages WHERE id = ?", (package_id,))  # questions go with it (ON DELETE CASCADE)
        remove_unused(conn, images)
    return Response(status_code=204)


@router.post("/{package_id}/reset-played", response_model=Package)
def reset_played(package_id: int) -> dict:
    with db.get_conn() as conn:
        _get_or_404(conn, package_id)
        conn.execute("UPDATE questions SET played_at = NULL WHERE package_id = ?", (package_id,))
        return _get_or_404(conn, package_id)


@router.get("/{package_id}/export")
def export_package(package_id: int) -> JSONResponse:
    """The whole package as one self-contained JSON file (handout images embedded as data URIs)."""
    with db.get_conn() as conn:
        package = _get_or_404(conn, package_id)
        rows = conn.execute("SELECT * FROM questions WHERE package_id = ? ORDER BY position, id", (package_id,))
        questions = [db.question_from_row(r) for r in rows]
    doc = PackageExport(
        package=_pick(PackageIn, package),
        questions=[_pick(ExportQuestion, {**q, "handout_image_data": image_data_uri(q["handout_image"])})
                   for q in questions],
    )
    filename = re.sub(r'[\\/:*?"<>|\s]+', "_", package["title"]).strip("_") or "package"
    return JSONResponse(
        doc.model_dump(exclude_none=True),
        headers={"Content-Disposition": f"attachment; filename=\"package.json\"; "
                                        f"filename*=UTF-8''{quote(filename)}.json"},
    )


@router.post("/import", response_model=Package, status_code=201)
def import_package(doc: PackageExport) -> dict:
    """Always creates a new package, so importing an export again makes a copy. Played status is not kept."""
    with db.get_conn() as conn:
        package_id = _insert_package(conn, doc.package)
        for item in doc.questions:
            data = item.model_dump(exclude={"handout_image_data"}) | {"package_id": package_id}
            if item.handout_image_data:
                try:
                    data["handout_image"] = save_data_uri(item.handout_image_data)
                except ValueError:
                    raise HTTPException(status_code=422, detail="invalid_image")
            db.insert_question(conn, data)
        return _get_or_404(conn, package_id)
