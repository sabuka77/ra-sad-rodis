"""Speech preview: the normalized text and segments the TTS will receive (no audio)."""
from fastapi import APIRouter, Query

from app import db
from app.speech.segments import build_segments, spoken_text

router = APIRouter(prefix="/api/speech", tags=["speech"])


@router.get("/preview")
def preview(text: str = Query(..., max_length=20000)) -> dict:
    settings = db.load_settings()
    segments = build_segments(
        text,
        dictionary=settings.pronunciation_dict,
        number_emphasis=settings.number_emphasis,
        sentence_pause_ms=settings.sentence_pause_ms,
        number_pause_ms=settings.number_pause_ms,
    )
    return {"spoken": spoken_text(segments), "segments": [s.to_dict() for s in segments]}
