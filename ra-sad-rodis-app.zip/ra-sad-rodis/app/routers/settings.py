"""Settings API: GET returns defaults merged with stored values, PUT accepts partial updates."""
from typing import Any

from fastapi import APIRouter, Body, HTTPException
from pydantic import ValidationError

from app import db
from app.models import Settings

router = APIRouter(prefix="/api/settings", tags=["settings"])

KEY_MASK = "********"  # what the browser sees instead of a stored Azure key


def _masked(settings: Settings) -> Settings:
    """The Azure key never leaves the server: the page only learns whether one is stored."""
    return settings.model_copy(update={"azure_key": KEY_MASK if settings.azure_key else ""})


@router.get("", response_model=Settings)
def get_settings() -> Settings:
    return _masked(db.load_settings())


@router.put("", response_model=Settings)
def update_settings(changes: dict[str, Any] = Body(...)) -> Settings:
    if changes.get("azure_key") == KEY_MASK:  # the mask sent back unchanged keeps the stored key
        changes = {k: v for k, v in changes.items() if k != "azure_key"}
    try:
        updated = Settings.model_validate(db.load_settings().model_dump() | changes)
    except ValidationError as exc:
        # input values are left out, so a key can't end up in the error or a log line
        raise HTTPException(status_code=422, detail=exc.errors(include_url=False, include_context=False,
                                                               include_input=False))
    db.save_settings(updated, changes.keys())
    return _masked(updated)


@router.post("/reset", response_model=Settings)
def reset_settings() -> Settings:
    db.clear_settings()
    return Settings()
