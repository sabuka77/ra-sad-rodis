"""TTS API: prepare segments with audio URLs, serve (and lazily synthesize) cached MP3s, cache admin."""
import re
from typing import Literal

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, ConfigDict, Field, model_validator

from app import db
from app.models import Settings
from app.speech import cache, pregen
from app.speech.providers import ProviderError
from app.speech.segments import build_segments

router = APIRouter(prefix="/api/tts", tags=["tts"])

_KEY = re.compile(r"[0-9a-f]{40}")
MIN_RATE_PCT = -75  # base rate + number slowdown never goes below this


class PrepareIn(BaseModel):
    model_config = ConfigDict(extra="forbid")

    text: str | None = Field(None, min_length=1, max_length=20000)
    question_id: int | None = None
    field: Literal["text", "answer"] = "text"

    @model_validator(mode="after")
    def _one_source(self) -> "PrepareIn":
        if (self.text is None) == (self.question_id is None):
            raise ValueError("give either text or question_id")
        return self


def segment_rate(settings: Settings, is_number: bool) -> int:
    rate = settings.rate_pct + (settings.number_rate_pct if is_number else 0)
    return max(rate, MIN_RATE_PCT)


def server_provider(settings: Settings) -> str | None:
    """Provider that synthesizes on the server; None means the browser speaks.

    Azure without a key or region uses edge right away (no failing request per segment).
    """
    if settings.tts_provider == "browser":
        return None
    if settings.tts_provider == "azure" and settings.azure_key and settings.azure_region:
        return "azure"
    return "edge"


def plan_segments(text: str, settings: Settings, provider: str | None) -> list[dict]:
    """Segments of `text` with their rate and, for a server provider, a registered audio URL."""
    segments = []
    for i, seg in enumerate(build_segments(
        text,
        dictionary=settings.pronunciation_dict,
        number_emphasis=settings.number_emphasis,
        sentence_pause_ms=settings.sentence_pause_ms,
        number_pause_ms=settings.number_pause_ms,
    )):
        rate = segment_rate(settings, seg.is_number)
        url = None
        if provider:
            key = cache.register(cache.Job(provider, settings.voice, rate, seg.spoken))
            url = f"/api/tts/audio/{key}.mp3"
        segments.append({"i": i, **seg.to_dict(), "rate_pct": rate, "url": url})
    return segments


def _source_text(body: PrepareIn) -> str:
    if body.text is not None:
        return body.text
    with db.get_conn() as conn:
        question = db.get_question(conn, body.question_id)
    if question is None:
        raise HTTPException(status_code=404, detail="question not found")
    if body.field == "answer":
        return question["answer"]
    return question["spoken_override"] or question["text"]


@router.post("/prepare")
def prepare(body: PrepareIn) -> dict:
    """Segments of the text with one audio URL each. `start`/`end` are offsets into the returned `text`."""
    settings = db.load_settings()
    text = _source_text(body)
    provider = server_provider(settings)
    segments = plan_segments(text, settings, provider)
    return {"text": text, "provider": provider or "browser", "voice": settings.voice, "segments": segments}


@router.get("/audio/{key}.mp3")
async def audio(key: str) -> FileResponse:
    if not _KEY.fullmatch(key):
        raise HTTPException(status_code=404, detail="unknown audio")
    try:
        path = await cache.get_audio(key)
    except ProviderError as exc:
        raise HTTPException(status_code=503, detail={"code": "tts_failed", "message": str(exc)[:500]})
    if path is None:
        raise HTTPException(status_code=404, detail="unknown audio")
    return FileResponse(path, media_type="audio/mpeg",
                        headers={"Cache-Control": "public, max-age=31536000, immutable"})


@router.get("/cache")
def cache_size() -> dict:
    return cache.cache_info()


@router.delete("/cache")
def clear_cache() -> dict:
    return cache.clear_cache()


class PregenerateIn(BaseModel):
    package_id: int


@router.post("/pregenerate")
async def pregenerate(body: PregenerateIn) -> dict:
    """Start synthesizing every segment of the package (question as read aloud + answer) in the background."""
    settings = db.load_settings()
    provider = server_provider(settings)
    if provider is None:
        raise HTTPException(status_code=409, detail="browser_provider")
    with db.get_conn() as conn:
        if not conn.execute("SELECT 1 FROM packages WHERE id = ?", (body.package_id,)).fetchone():
            raise HTTPException(status_code=404, detail="package_not_found")
        rows = conn.execute("SELECT text, spoken_override, answer FROM questions WHERE package_id = ? "
                            "ORDER BY position, id", (body.package_id,)).fetchall()
    keys: dict[str, None] = {}  # ordered and unique
    for row in rows:
        for text in (row["spoken_override"] or row["text"], row["answer"]):
            for seg in plan_segments(text, settings, provider):
                keys[seg["url"].rsplit("/", 1)[1].removesuffix(".mp3")] = None
    try:
        return pregen.start(body.package_id, list(keys))
    except RuntimeError:
        raise HTTPException(status_code=409, detail="busy")


@router.get("/pregenerate")
def pregenerate_status() -> dict:
    return pregen.status()


@router.delete("/pregenerate")
async def pregenerate_cancel() -> dict:
    return pregen.cancel()
