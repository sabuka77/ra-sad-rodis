"""Questions API: list/search, CRUD, move up/down inside a package, mark played / reset played status."""
import sqlite3

from fastapi import APIRouter, HTTPException, Response

from app import db
from app.models import MoveIn, Question, QuestionIn, QuestionSaved
from app.routers.uploads import remove_unused

router = APIRouter(prefix="/api/questions", tags=["questions"])


def _get_or_404(conn: sqlite3.Connection, question_id: int) -> dict:
    question = db.get_question(conn, question_id)
    if question is None:
        raise HTTPException(status_code=404, detail="question_not_found")
    return question


def _require_package(conn: sqlite3.Connection, package_id: int) -> None:
    if not conn.execute("SELECT 1 FROM packages WHERE id = ?", (package_id,)).fetchone():
        raise HTTPException(status_code=404, detail="package_not_found")


def _saved(conn: sqlite3.Connection, question_id: int) -> QuestionSaved:
    question = db.get_question(conn, question_id)
    return QuestionSaved(**question, duplicates=db.find_duplicates(conn, question["content_hash"], question_id))


@router.get("", response_model=list[Question])
def list_questions(package_id: int | None = None, q: str = "") -> list[dict]:
    where, params = [], []
    if package_id is not None:
        where.append("package_id = ?")
        params.append(package_id)
    if q.strip():
        where.append("(instr(casefold(text), ?) > 0 OR instr(casefold(answer), ?) > 0)")
        params += [q.strip().casefold()] * 2
    sql = "SELECT * FROM questions" + (f" WHERE {' AND '.join(where)}" if where else "")
    with db.get_conn() as conn:
        rows = conn.execute(sql + " ORDER BY package_id, position, id", params).fetchall()
    return [db.question_from_row(r) for r in rows]


@router.get("/{question_id}", response_model=Question)
def get_question(question_id: int) -> dict:
    with db.get_conn() as conn:
        return _get_or_404(conn, question_id)


@router.post("", response_model=QuestionSaved, status_code=201)
def create_question(body: QuestionIn) -> QuestionSaved:
    with db.get_conn() as conn:
        _require_package(conn, body.package_id)
        return _saved(conn, db.insert_question(conn, body.model_dump()))


@router.put("/{question_id}", response_model=QuestionSaved)
def update_question(question_id: int, body: QuestionIn) -> QuestionSaved:
    with db.get_conn() as conn:
        old = _get_or_404(conn, question_id)
        _require_package(conn, body.package_id)
        db.update_question(conn, question_id, body.model_dump())
        if body.package_id != old["package_id"]:  # moved to another package: append at its end
            conn.execute(
                "UPDATE questions SET position = (SELECT COALESCE(MAX(position), 0) + 1 FROM questions "
                "WHERE package_id = ? AND id != ?) WHERE id = ?",
                (body.package_id, question_id, question_id),
            )
        remove_unused(conn, [old["handout_image"]])
        return _saved(conn, question_id)


@router.delete("/{question_id}", status_code=204)
def delete_question(question_id: int) -> Response:
    with db.get_conn() as conn:
        old = _get_or_404(conn, question_id)
        conn.execute("DELETE FROM questions WHERE id = ?", (question_id,))
        remove_unused(conn, [old["handout_image"]])
    return Response(status_code=204)


@router.post("/{question_id}/move", response_model=list[int])
def move_question(question_id: int, body: MoveIn) -> list[int]:
    """Swap with the neighbour inside the package and renumber positions 1..n. Returns the new id order."""
    with db.get_conn() as conn:
        question = _get_or_404(conn, question_id)
        ids = [r[0] for r in conn.execute(
            "SELECT id FROM questions WHERE package_id = ? ORDER BY position, id", (question["package_id"],))]
        i = ids.index(question_id)
        j = i - 1 if body.direction == "up" else i + 1
        if 0 <= j < len(ids):
            ids[i], ids[j] = ids[j], ids[i]
        conn.executemany("UPDATE questions SET position = ? WHERE id = ?",
                         [(pos, qid) for pos, qid in enumerate(ids, start=1)])
    return ids


@router.post("/{question_id}/reset-played", response_model=Question)
def reset_played(question_id: int) -> dict:
    with db.get_conn() as conn:
        _get_or_404(conn, question_id)
        conn.execute("UPDATE questions SET played_at = NULL WHERE id = ?", (question_id,))
        return db.get_question(conn, question_id)


@router.post("/{question_id}/mark-played", response_model=Question)
def mark_played(question_id: int) -> dict:
    """Play tab: called when the answer is revealed. The first time stays (repeat calls change nothing)."""
    with db.get_conn() as conn:
        _get_or_404(conn, question_id)
        conn.execute("UPDATE questions SET played_at = COALESCE(played_at, datetime('now')) WHERE id = ?",
                     (question_id,))
        return db.get_question(conn, question_id)
