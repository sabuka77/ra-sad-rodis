"""Handout images in data/uploads, named by the sha1 of their bytes (so copies share one file)."""
import base64
import binascii
import hashlib
import re
import sqlite3
from pathlib import Path
from typing import Iterable

from fastapi import APIRouter, HTTPException, UploadFile
from fastapi.responses import FileResponse

from app import db
from app.models import HANDOUT_IMAGE_PATTERN

router = APIRouter(prefix="/api/uploads", tags=["uploads"])

MAX_IMAGE_BYTES = 10 * 1024 * 1024
MIME = {"png": "image/png", "jpg": "image/jpeg", "gif": "image/gif", "webp": "image/webp"}


def uploads_dir() -> Path:
    return db.data_dir() / "uploads"


def image_ext(data: bytes) -> str | None:
    """Recognise the image type from its first bytes, not from the file name."""
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if data.startswith(b"\xff\xd8\xff"):
        return "jpg"
    if data.startswith((b"GIF87a", b"GIF89a")):
        return "gif"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "webp"
    return None


def save_image(data: bytes) -> str:
    """Store the bytes and return the file name; ValueError if they are not a supported image."""
    ext = image_ext(data)
    if ext is None or len(data) > MAX_IMAGE_BYTES:
        raise ValueError("unsupported image")
    name = f"{hashlib.sha1(data).hexdigest()}.{ext}"
    path = uploads_dir() / name
    if not path.exists():
        path.write_bytes(data)
    return name


def image_data_uri(name: str | None) -> str | None:
    path = uploads_dir() / name if name else None
    if not path or not path.is_file():
        return None
    return f"data:{MIME[name.rsplit('.', 1)[1]]};base64,{base64.b64encode(path.read_bytes()).decode()}"


def save_data_uri(uri: str) -> str:
    match = re.fullmatch(r"data:image/[\w.+-]+;base64,(.*)", uri, re.S)
    if not match:
        raise ValueError("not an image data URI")
    try:
        return save_image(base64.b64decode(match.group(1), validate=True))
    except binascii.Error as exc:
        raise ValueError("bad base64") from exc


def remove_unused(conn: sqlite3.Connection, names: Iterable[str | None]) -> None:
    """Delete image files that no question refers to any more."""
    for name in {n for n in names if n}:
        if not conn.execute("SELECT 1 FROM questions WHERE handout_image = ?", (name,)).fetchone():
            (uploads_dir() / name).unlink(missing_ok=True)


@router.post("")
async def upload_image(file: UploadFile) -> dict:
    data = await file.read(MAX_IMAGE_BYTES + 1)
    try:
        return {"name": save_image(data)}
    except ValueError:
        raise HTTPException(status_code=415, detail="unsupported_image")


@router.get("/{name}")
def get_image(name: str) -> FileResponse:
    path = uploads_dir() / name
    if not re.fullmatch(HANDOUT_IMAGE_PATTERN, name) or not path.is_file():
        raise HTTPException(status_code=404, detail="not_found")
    return FileResponse(path, media_type=MIME[name.rsplit(".", 1)[1]])
