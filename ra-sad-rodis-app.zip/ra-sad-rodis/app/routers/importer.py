"""Document import API: parse files into an editable preview (no writes), re-check warnings, commit."""
from typing import Annotated, Literal

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from pydantic import BaseModel, ConfigDict, model_validator

from app import db
from app.importer import ImportFailure, checks, pipeline
from app.models import Package, PackageIn, QuestionBody
from app.routers.packages import _get_or_404, _insert_package

router = APIRouter(prefix="/api/import", tags=["import"])

LEGACY = {"auto": None, "on": True, "off": False}


class CheckRow(BaseModel):
    model_config = ConfigDict(extra="ignore")

    text: str = ""
    answer: str = ""
    number_label: str | None = None
    tour: str | None = None
    file: int = 0


class CheckIn(BaseModel):
    rows: list[CheckRow]


class CommitIn(BaseModel):
    """Save into an existing package (package_id) or a new one (package)."""

    package_id: int | None = None
    package: PackageIn | None = None
    rows: list[QuestionBody]

    @model_validator(mode="after")
    def _one_target(self) -> "CommitIn":
        if (self.package_id is None) == (self.package is None):
            raise ValueError("give either package_id or package")
        if not self.rows:
            raise ValueError("nothing to save")
        return self


def _warnings(rows: list[dict]) -> list[list[dict]]:
    with db.get_conn() as conn:  # read-only: duplicate lookup
        return checks.compute(rows, conn)


@router.post("/parse")
async def parse_files(files: Annotated[list[UploadFile], File()],
                      legacy: Annotated[list[Literal["auto", "on", "off"]], Form()] = []) -> dict:
    """Preview only, nothing is saved. `legacy` (one per file, default auto) is the AcadNusx toggle."""
    out_files, rows = [], []
    for index, upload in enumerate(files):
        name = upload.filename or "file"
        mode = LEGACY[legacy[index]] if index < len(legacy) else None
        data = await upload.read()
        try:
            result = pipeline.parse(name, data, mode)
        except ImportFailure as exc:
            out_files.append({"name": name, "error": exc.code})
            continue
        out_files.append({"name": name, "error": None, "title": result["title"], "editor": result["editor"],
                          "legacy": result["legacy"], "count": len(result["questions"])})
        rows += [q | {"file": index} for q in result["questions"]]
    for row, found in zip(rows, _warnings(rows)):
        row["warnings"] = found
    return {"files": out_files, "rows": rows}


@router.post("/check")
def check_rows(body: CheckIn) -> dict:
    """Warnings for the preview rows after the host edited, merged or deleted some."""
    return {"warnings": _warnings([r.model_dump() for r in body.rows])}


@router.post("/commit", status_code=201)
def commit(body: CommitIn) -> dict:
    with db.get_conn() as conn:
        package_id = body.package_id
        if package_id is None:
            package_id = _insert_package(conn, body.package)
        else:
            _get_or_404(conn, package_id)
        for row in body.rows:
            db.insert_question(conn, row.model_dump() | {"package_id": package_id, "handout_image": None})
        package = Package.model_validate(_get_or_404(conn, package_id))
    return {"package": package.model_dump(), "added": len(body.rows)}
