"""Deterministic document import (no AI): readers → legacy fonts → cleanup → segmenter. See docs/spec-import.md."""
from dataclasses import dataclass, field


@dataclass
class Paragraph:
    """One paragraph (DOCX paragraph or table cell paragraph, PDF text block, TXT line).

    `runs` keeps (text, font name) pieces so legacy-font conversion can work per run/span; `text` is
    rebuilt from them after conversion. A `\n` inside the text is a line break. `wrapped` marks PDF
    blocks whose lines are only visual wraps of one paragraph (joined with spaces by the segmenter).
    """

    runs: list[tuple[str, str | None]]
    style: str | None = None
    is_heading: bool = False
    is_numbered: bool = False
    page: int | None = None
    table: tuple[int, int, int] | None = None  # (table index, row, column) for DOCX table cells
    images: list[str] = field(default_factory=list)  # DOCX relationship ids of inline images
    wrapped: bool = False
    text: str = ""

    def __post_init__(self) -> None:
        if not self.text:
            self.text = "".join(t for t, _ in self.runs)

    @property
    def fonts(self) -> list[str]:
        return sorted({f for _, f in self.runs if f})


class ImportFailure(Exception):
    """A file that cannot be imported. `code` is mapped to a Georgian message in ka.json (import.errors)."""

    MESSAGES = {
        "doc_format": "old .doc file: open it in Word and use 'Save as' .docx",
        "docx_encrypted": "password-protected Word file: remove the password first",
        "pdf_encrypted": "password-protected PDF",
        "pdf_no_text": "PDF has no text layer (scanned)",
        "txt_encoding": "text file is neither UTF-8 nor UTF-16",
        "unsupported_type": "only .docx, .pdf and .txt files can be imported",
        "unreadable": "file is damaged or not a real document of this type",
        "too_large": "file is larger than the limit",
    }

    def __init__(self, code: str) -> None:
        super().__init__(f"{code}: {self.MESSAGES.get(code, code)}")
        self.code = code
