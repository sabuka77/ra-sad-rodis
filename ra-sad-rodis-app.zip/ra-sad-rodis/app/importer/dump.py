"""Debug CLI: python -m app.importer.dump <file> [--legacy auto|on|off]

Prints the paragraphs (style / numbered / table / fonts) and then the parsed questions with warnings.
Use it instead of opening .docx/.pdf files directly. Read-only: never touches the database.
"""
import argparse
import sys
from pathlib import Path

from app.importer import ImportFailure, checks, pipeline


def _short(text: str, width: int = 110) -> str:
    text = text.replace("\n", " ⏎ ")
    return text if len(text) <= width else text[: width - 1] + "…"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("file", type=Path)
    parser.add_argument("--legacy", choices=["auto", "on", "off"], default="auto")
    args = parser.parse_args(argv)
    legacy = {"auto": None, "on": True, "off": False}[args.legacy]
    try:
        result = pipeline.parse(args.file.name, args.file.read_bytes(), legacy)
    except ImportFailure as exc:
        print(f"ERROR {exc}")
        return 1
    print(f"== {args.file.name}: {len(result['paragraphs'])} paragraphs, legacy fonts {result['legacy']}")
    for i, p in enumerate(result["paragraphs"]):
        flags = "".join(flag for flag, on in (("H", p.is_heading), ("N", p.is_numbered), ("W", p.wrapped)) if on)
        where = f"p{p.page}" if p.page else (f"t{p.table[0]}r{p.table[1]}c{p.table[2]}" if p.table else "")
        meta = " ".join(x for x in (where, flags, p.style or "", ",".join(p.fonts)) if x)
        print(f"[{i}] {meta} | {_short(p.text)}")
    questions = result["questions"]
    print(f"== title: {result['title']!r}  editor: {result['editor']!r}  questions: {len(questions)}")
    for line in result["skipped"]:
        print(f"skipped: {_short(line)}")
    warnings = checks.compute(questions)
    for q, found in zip(questions, warnings):
        print(f"-- #{q['number_label']} tour={q['tour']!r} warnings={[w['code'] for w in found]}")
        for name in ("text", "answer", "accepted", "not_accepted", "comment", "author", "handout_text"):
            if q[name]:
                print(f"   {name}: {_short(q[name])}")
        for source in q["sources"]:
            print(f"   source: {_short(source['text'], 80)} -> {source['url']}")
    return 0


if __name__ == "__main__":
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # the Windows console is often cp1252
    sys.exit(main())
