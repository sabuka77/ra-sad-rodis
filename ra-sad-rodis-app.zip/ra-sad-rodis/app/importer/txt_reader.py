"""TXT reader: UTF-8 (with or without BOM) or UTF-16; one line = one paragraph."""
import codecs

from app.importer import ImportFailure, Paragraph


def decode(data: bytes) -> str:
    try:
        return data.decode("utf-8-sig")
    except UnicodeDecodeError:
        pass
    # UTF-16 only with a BOM or NUL bytes (UTF-8 text never has those), so ANSI files fail clearly
    if data.startswith((codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE)) or b"\x00" in data:
        try:
            return data.decode("utf-16")
        except UnicodeDecodeError:
            pass
    raise ImportFailure("txt_encoding")


def read_txt(data: bytes) -> list[Paragraph]:
    return [Paragraph(runs=[(line, None)]) for line in decode(data).splitlines()]
