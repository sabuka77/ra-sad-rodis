"""Preview warnings per question (never blocking). Codes are turned into Georgian text by the UI."""
import sqlite3

from app.db import content_hash, find_duplicates

SHORT_TEXT = 15
LONG_TEXT = 1500
LONG_ANSWER = 300


def _number(label) -> int | None:
    label = str(label or "").strip()
    return int(label) if label.isdigit() else None


def compute(rows: list[dict], conn: sqlite3.Connection | None = None) -> list[list[dict]]:
    """rows: dicts with text, answer, number_label, tour and file (index of the source file)."""
    result: list[list[dict]] = [[] for _ in rows]
    first_with_hash: dict[str, int] = {}
    previous: dict = {}  # file → (tour, number) of the last numbered row
    for i, row in enumerate(rows):
        warnings = result[i]
        text, answer = (row.get("text") or "").strip(), (row.get("answer") or "").strip()
        if not answer:
            warnings.append({"code": "no_answer"})
        if len(text) < SHORT_TEXT:
            warnings.append({"code": "short_text"})
        if len(text) > LONG_TEXT:
            warnings.append({"code": "long_text"})
        if len(answer) > LONG_ANSWER:
            warnings.append({"code": "long_answer"})
        if text:
            hash_ = content_hash(text)
            if hash_ in first_with_hash:
                warnings.append({"code": "duplicate_batch", "row": first_with_hash[hash_] + 1})
            else:
                first_with_hash[hash_] = i
            if conn is not None:
                found = find_duplicates(conn, hash_)
                if found:
                    warnings.append({"code": "duplicate_db", "package": found[0]["package_title"],
                                     "number": found[0]["number_label"] or "", "count": len(found)})
        number = _number(row.get("number_label"))
        if number is None:
            continue
        key = row.get("file", 0)
        last = previous.get(key)
        if last and last[0] == row.get("tour"):
            if number == last[1]:
                warnings.append({"code": "numbering_repeat", "number": number})
            elif number < last[1]:
                warnings.append({"code": "numbering_order", "number": number, "previous": last[1]})
            elif number > last[1] + 1:
                warnings.append({"code": "numbering_gap", "number": number, "previous": last[1]})
        previous[key] = (row.get("tour"), number)
    return result
