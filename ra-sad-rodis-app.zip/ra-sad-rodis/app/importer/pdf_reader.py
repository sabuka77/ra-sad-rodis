"""PDF reader (pymupdf): text blocks top-to-bottom, span fonts, hyphenation repair, headers/footers dropped."""
import re
from collections import Counter

import pymupdf

from app.importer import ImportFailure, Paragraph
from app.importer.legacy_fonts import GEORGIAN, is_legacy_font

MARGIN = 0.12  # top and bottom share of the page where headers, footers and page numbers live
PAGE_NUMBER = re.compile(r"^[-–—\s]*\d{1,4}[-–—\s]*$")
MIN_CHARS_PER_PAGE = 20
HYPHENS = "-\u00ad\u2010\u2011"  # fonts often map the line-end hyphen to a soft hyphen


def _letter(char: str, font: str | None) -> bool:
    """A Georgian letter, or a Latin letter in a legacy font (it becomes Georgian after conversion)."""
    return bool(GEORGIAN.match(char)) or (char.isascii() and char.isalpha() and is_legacy_font(font))


def join_lines(lines: list[list[tuple[str, str | None]]]) -> list[tuple[str, str | None]]:
    """Runs of one block. Lines are separated by '\n'; a word hyphenated across two lines
    (Georgian letters on both sides) is joined back: 'საქარ-' + 'თველო' → 'საქართველო'."""
    runs: list[tuple[str, str | None]] = []
    for line in lines:
        line = [(t, f) for t, f in line if t]
        if not line:
            continue
        if runs:
            last_text, last_font = runs[-1]
            stripped = last_text.rstrip()
            first_text, first_font = line[0]
            if (len(stripped) > 1 and stripped[-1] in HYPHENS and _letter(stripped[-2], last_font)
                    and _letter(first_text.lstrip()[:1], first_font)):
                runs[-1] = (stripped[:-1], last_font)
                line[0] = (first_text.lstrip(), first_font)
            else:
                runs.append(("\n", None))
        runs += line
    return runs


def _blocks(page) -> list[tuple[str, list, bool]]:
    """(text, runs, in_margin) per text block."""
    height = page.rect.height
    out = []
    for block in page.get_text("dict", sort=True)["blocks"]:
        if block.get("type") != 0:
            continue
        lines = [[(s["text"], s.get("font")) for s in line["spans"]] for line in block["lines"]]
        runs = join_lines(lines)
        text = "".join(t for t, _ in runs).strip()
        if not text:
            continue
        y0, y1 = block["bbox"][1], block["bbox"][3]
        out.append((text, runs, y1 <= height * MARGIN or y0 >= height * (1 - MARGIN)))
    return out


def _key(text: str) -> str:
    return re.sub(r"\d+", "#", re.sub(r"\s+", " ", text))


def read_pdf(data: bytes) -> list[Paragraph]:
    try:
        document = pymupdf.open(stream=data, filetype="pdf")
    except Exception as exc:  # pymupdf raises its own FileDataError / RuntimeError types
        raise ImportFailure("unreadable") from exc
    with document:
        if document.needs_pass:
            raise ImportFailure("pdf_encrypted")
        pages = [_blocks(page) for page in document]
    if not pages or sum(len(text) for blocks in pages for text, _, _ in blocks) / len(pages) < MIN_CHARS_PER_PAGE:
        raise ImportFailure("pdf_no_text")
    # same margin text (digits ignored, so "გვერდი 3" counts too) on at least half of the pages
    counts = Counter(k for blocks in pages for k in {_key(t) for t, _, m in blocks if m})
    repeated = {k for k, n in counts.items() if len(pages) >= 2 and n >= max(2, (len(pages) + 1) // 2)}
    paragraphs = []
    for number, blocks in enumerate(pages, start=1):
        for text, runs, margin in blocks:
            if margin and (_key(text) in repeated or PAGE_NUMBER.match(text)):
                continue
            paragraphs.append(Paragraph(runs=runs, page=number, wrapped=True))
    return paragraphs
