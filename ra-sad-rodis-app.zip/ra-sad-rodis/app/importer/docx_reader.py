"""DOCX reader (python-docx): body paragraphs and table cells in document order, with run fonts."""
import io
import zipfile

from docx import Document
from docx.oxml.ns import qn
from docx.table import Table
from docx.text.hyperlink import Hyperlink

from app.importer import ImportFailure, Paragraph

OLE_MAGIC = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"  # old .doc, and also password-protected .docx


def _style_font(style) -> str | None:
    while style is not None:
        if style.font.name:
            return style.font.name
        style = style.base_style
    return None


def _run_font(run, fallback: str | None) -> str | None:
    if run.font.name:
        return run.font.name
    rpr = run._r.rPr
    fonts = rpr.rFonts if rpr is not None else None
    if fonts is not None:
        for attr in ("w:ascii", "w:hAnsi", "w:cs"):
            if fonts.get(qn(attr)):
                return fonts.get(qn(attr))
    return fallback


def _is_numbered(paragraph) -> bool:
    ppr = paragraph._p.pPr
    if ppr is not None and ppr.numPr is not None:
        return True
    style = paragraph.style
    while style is not None:  # numbering can also come from the paragraph style ("List Number")
        spr = style.element.pPr
        if spr is not None and spr.numPr is not None:
            return True
        style = style.base_style
    return False


def _paragraph(paragraph, table=None) -> Paragraph:
    style = paragraph.style
    fallback = _style_font(style)
    runs = []
    for item in paragraph.iter_inner_content():
        if isinstance(item, Hyperlink):
            runs += [(r.text, _run_font(r, fallback)) for r in item.runs]
            address = item.address or ""
            # a link whose visible text is not the URL: keep the URL so sources still get their link
            if address.startswith(("http://", "https://")) and address not in item.text:
                runs.append((f" {address}", None))
        else:
            runs.append((item.text, _run_font(item, fallback)))
    name = style.name if style is not None else None
    images = paragraph._p.xpath(".//a:blip/@r:embed")
    return Paragraph(runs=runs, style=name, is_heading=bool(name and name.startswith(("Heading", "Title"))),
                     is_numbered=_is_numbered(paragraph), table=table, images=list(images))


def read_docx(data: bytes) -> list[Paragraph]:
    if data.startswith(OLE_MAGIC):
        raise ImportFailure("docx_encrypted")
    try:
        document = Document(io.BytesIO(data))
    except (zipfile.BadZipFile, KeyError, ValueError) as exc:
        raise ImportFailure("unreadable") from exc
    paragraphs: list[Paragraph] = []
    table_index = 0
    for block in document.iter_inner_content():
        if not isinstance(block, Table):
            paragraphs.append(_paragraph(block))
            continue
        for r, row in enumerate(block.rows):
            seen = []  # merged cells appear once per spanned column
            for cell in row.cells:
                if any(cell._tc is tc for tc in seen):
                    continue
                seen.append(cell._tc)
                paragraphs += [_paragraph(p, (table_index, r, len(seen) - 1)) for p in cell.paragraphs]
        table_index += 1
    return paragraphs
