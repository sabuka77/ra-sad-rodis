"""Text cleanup: NFC, odd spaces → space, soft hyphens and zero-width characters removed, spaces collapsed."""
import re
import unicodedata

from app.importer import Paragraph

_SPACES = re.compile(r"[ \t\u00a0\u2000-\u200a\u202f\u205f\u3000]+")
_INVISIBLE = re.compile(r"[\u00ad\u200b-\u200d\u2060\ufeff]")


def clean_text(text: str) -> str:
    text = unicodedata.normalize("NFC", _INVISIBLE.sub("", text)).replace("\r\n", "\n").replace("\r", "\n")
    lines = [_SPACES.sub(" ", line).strip() for line in text.split("\n")]
    return "\n".join(lines).strip("\n")


def clean(paragraphs: list[Paragraph]) -> list[Paragraph]:
    for p in paragraphs:
        p.text = clean_text(p.text)
    return paragraphs
