"""file → reader → legacy-font conversion → cleanup → segmenter (spec §1)."""
from pathlib import Path

from app.importer import ImportFailure, Paragraph, cleanup, legacy_fonts, segmenter
from app.importer.docx_reader import read_docx
from app.importer.pdf_reader import read_pdf
from app.importer.txt_reader import read_txt

READERS = {".docx": read_docx, ".pdf": read_pdf, ".txt": read_txt}
MAX_BYTES = 50 * 1024 * 1024


def read(name: str, data: bytes) -> list[Paragraph]:
    suffix = Path(name).suffix.lower()
    if suffix == ".doc":
        raise ImportFailure("doc_format")
    if suffix not in READERS:
        raise ImportFailure("unsupported_type")
    if len(data) > MAX_BYTES:
        raise ImportFailure("too_large")
    return READERS[suffix](data)


def parse(name: str, data: bytes, legacy: bool | None = None) -> dict:
    """legacy: None = auto-detect, True/False = the host's choice for the conversion toggle.

    Returns {title, editor, questions, skipped, paragraphs, legacy: {detected, by_font, applied}}.
    """
    paragraphs = read(name, data)
    info = legacy_fonts.detect(paragraphs)
    applied = info["detected"] if legacy is None else legacy
    if applied:
        legacy_fonts.apply(paragraphs, info["by_font"])
    cleanup.clean(paragraphs)
    result = segmenter.segment(paragraphs, Path(name).stem)
    return result | {"paragraphs": paragraphs, "legacy": info | {"applied": applied}}
