"""Legacy Georgian fonts (AcadNusx, AcadMtavr, LitNusx, LitMtavr): Latin letters that only look Georgian.

Conversion uses the standard Georgian keyboard layout. URLs are never converted.
"""
import re

from app.importer import Paragraph

LEGACY_FONT = re.compile(r"acad|lit[\s_-]?(nusx|mtavr)", re.I)

_MAP = dict(zip(
    "abgdevzTiklmnopJrstufqRySCcZwWxjh",
    "აბგდევზთიკლმნოპჟრსტუფქღყშჩცძწჭხჯჰ",
))
# Uppercase letters without their own key use the lowercase mapping (A → ა).
for _upper in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
    _MAP.setdefault(_upper, _MAP[_upper.lower()])
_TABLE = str.maketrans(_MAP)

URL = re.compile(r"(?:https?://|www\.)\S+", re.I)
GEORGIAN = re.compile(r"[Ⴀ-ჿᲐ-Ჿⴀ-⴯]")
_LATIN = re.compile(r"[A-Za-z]")
_HINTS = re.compile(r"Svili|Tvel|ebi|aris|Si |ze ")


def is_legacy_font(name: str | None) -> bool:
    return bool(name and LEGACY_FONT.search(name))


def convert_text(text: str) -> str:
    """'saqarTvelo' → 'საქართველო'. Digits, punctuation and URLs stay unchanged."""
    parts, last = [], 0
    for m in URL.finditer(text):
        parts += [text[last:m.start()].translate(_TABLE), m.group()]
        last = m.end()
    parts.append(text[last:].translate(_TABLE))
    return "".join(parts)


def looks_like_acadnusx(text: str) -> bool:
    """No Georgian letters, > 70% Latin letters, at least two typical fragments (for files without font info)."""
    chars = [c for c in text if not c.isspace()]
    if not chars or GEORGIAN.search(text):
        return False
    latin = len(_LATIN.findall(text))
    return latin / len(chars) > 0.7 and len(_HINTS.findall(text + " ")) >= 2


def detect(paragraphs: list[Paragraph]) -> dict:
    """{'by_font': runs use a legacy font, 'detected': conversion should be pre-checked}."""
    by_font = any(is_legacy_font(f) for p in paragraphs for _, f in p.runs)
    detected = by_font or any(looks_like_acadnusx(p.text) for p in paragraphs)
    return {"by_font": by_font, "detected": detected}


def apply(paragraphs: list[Paragraph], by_font: bool) -> None:
    """Convert in place. With legacy fonts present only their runs change; without font info
    (TXT, or the host forced conversion) every run that has no Georgian letters is converted."""
    for p in paragraphs:
        runs = []
        for text, font in p.runs:
            if is_legacy_font(font) if by_font else not GEORGIAN.search(text):
                text = convert_text(text)
            runs.append((text, font))
        p.runs = runs
        p.text = "".join(t for t, _ in runs)
