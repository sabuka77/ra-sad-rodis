"""Label-driven segmenter: paragraphs → questions. Labels come from labels.json (spec §5–6)."""
import json
import re
from dataclasses import dataclass
from pathlib import Path

from app.importer import Paragraph

LABELS_PATH = Path(__file__).with_name("labels.json")
FIELD_OF = {"question": "text", "answer": "answer", "accepted": "accepted", "not_accepted": "not_accepted",
            "comment": "comment", "source": "sources", "author": "author", "handout": "handout_text"}
TEXT_FIELDS = ("text", "answer", "accepted", "not_accepted", "comment", "author", "handout_text")

NUMBERED = re.compile(r"^(\d{1,3})[.)]\s+(.*)$")
NEW_ITEM = re.compile(r"^(?:\d{1,3}[.)]\s|[-•–]\s|https?://|www\.)", re.I)  # never joined to the line above
NUMBER_HEADER = re.compile(r"^(?:№|#|N|No\.?|ნომერი|ნო)$", re.I)
_NUMBER_TAIL = re.compile(r"\s*(?:№|N(?=\s*\d)|#)?\s*(\d+)?\s*[:.)\-–—]?\s*(.*)$", re.S)
_PLAIN_TAIL = re.compile(r"\s*[:.)\-–—]?\s*(.*)$", re.S)
URL = re.compile(r"(?:https?://|www\.)[^\s<>\"«»“”]+", re.I)
_LEADING_NUMBER = re.compile(r"^\s*(?:\d{1,3}[.)]|[-•–])\s*")


def load_labels(path: Path = LABELS_PATH) -> "Labels":
    return Labels(json.loads(path.read_text(encoding="utf-8")))


class Labels:
    def __init__(self, table: dict[str, list[str]]) -> None:
        self.kind = {label.casefold(): kind for kind, labels in table.items() for label in labels}
        ordered = sorted(self.kind, key=len, reverse=True)  # longest first: "არ ჩაითვლება" before "ჩაითვლება"
        self.pattern = re.compile(
            r"^\s*(" + "|".join(re.escape(label) for label in ordered) + r")"
            r"(?=\s*(?:[№#\d:.)\-–—]|N\s*\d|$))", re.I)

    def match(self, line: str) -> tuple[str, str | None, str] | None:
        """(kind, number or None, rest of the line) when the line starts with a label."""
        m = self.pattern.match(line)
        if not m:
            return None
        kind = self.kind[m.group(1).casefold()]
        tail = line[m.end():]
        if kind in ("question", "tour"):
            number, rest = _NUMBER_TAIL.match(tail).groups()
            return kind, number, rest.strip()
        return kind, None, _PLAIN_TAIL.match(tail).group(1).strip()


@dataclass
class Line:
    text: str
    joiner: str  # "\n", or " " for a visual wrap inside a PDF block
    numbered: bool
    heading: bool
    table: tuple[int, int, int] | None


def to_lines(paragraphs: list[Paragraph]) -> list[Line]:
    lines = []
    for p in paragraphs:
        for k, part in enumerate(p.text.split("\n")):
            part = part.strip()
            if part:
                wrap = k > 0 and p.wrapped and not NEW_ITEM.match(part)
                lines.append(Line(part, " " if wrap else "\n", p.is_numbered and k == 0, p.is_heading, p.table))
    return lines


def _clean_url(url: str) -> str:
    url = url.rstrip(".,;:!?'’")
    while url and url[-1] in ")]" and url.count(url[-1]) > url.count("(" if url[-1] == ")" else "["):
        url = url[:-1].rstrip(".,;:!?'’")
    return url


def parse_sources(text: str) -> list[dict]:
    """One source per line (or per '; ' part when every part has a URL), numbering removed."""
    items = []
    for line in text.split("\n"):
        parts = line.split("; ")
        for part in parts if len(parts) > 1 and all(URL.search(p) for p in parts) else [line]:
            part = _LEADING_NUMBER.sub("", part).strip()
            if part:
                m = URL.search(part)
                items.append({"text": part, "url": _clean_url(m.group()) if m else None})
    return items


class _Builder:
    def __init__(self) -> None:
        self.questions: list[dict] = []
        self.current: dict | None = None
        self.field: str | None = None

    def start(self, number: str | None, tour: str | None) -> None:
        self.current = {"number_label": number, "tour": tour, "fields": {}}
        self.questions.append(self.current)
        self.field = "text"

    def add(self, text: str, joiner: str = "\n") -> None:
        if self.current is None or self.field is None or not text:
            return
        pieces = self.current["fields"].setdefault(self.field, [])
        pieces += [joiner, text] if pieces else [text]

    def finish(self) -> list[dict]:
        out = []
        for q in self.questions:
            fields = {name: "".join(pieces).strip() for name, pieces in q["fields"].items()}
            row = {"number_label": q["number_label"], "tour": q["tour"]}
            row |= {name: fields.get(name, "") for name in TEXT_FIELDS}
            row["sources"] = parse_sources(fields.get("sources", ""))
            out.append(row)
        return out


def _question_tables(lines: list[Line], labels: Labels) -> dict[int, dict]:
    """Tables whose first row has a question and an answer column: {table: {column: kind}}."""
    headers: dict[int, dict[int, list[str]]] = {}
    for line in lines:
        if line.table and line.table[1] == 0:
            headers.setdefault(line.table[0], {}).setdefault(line.table[2], []).append(line.text)
    found = {}
    for table, columns in headers.items():
        kinds = {}
        for column, texts in columns.items():
            text = " ".join(texts)
            m = labels.match(text)
            kinds[column] = "number" if NUMBER_HEADER.match(text) else (m[0] if m else f"other:{text}")
        if {"question", "answer"} <= set(kinds.values()):
            found[table] = kinds
    return found


def _table_rows(lines: list[Line], table: int, kinds: dict, tour: str | None, out: _Builder) -> None:
    rows: dict[int, dict[int, list[str]]] = {}
    for line in lines:
        if line.table and line.table[0] == table and line.table[1] > 0:
            rows.setdefault(line.table[1], {}).setdefault(line.table[2], []).append(line.text)
    for cells in rows.values():
        values = {c: "\n".join(texts) for c, texts in cells.items()}
        if not any(values.values()):
            continue
        number = next((v for c, v in values.items() if kinds.get(c) == "number"), None)
        out.start(number or None, tour)
        for column, value in values.items():
            kind = kinds.get(column, "other:")
            if kind.startswith("other:"):
                header = kind[6:]
                out.field = "comment"
                out.add(f"{header}: {value}" if header else value)
            elif kind == "tour":
                out.current["tour"] = value or tour
            elif kind in FIELD_OF:
                out.field = FIELD_OF[kind]
                out.add(value)
    out.current, out.field = None, None


def _numbered_starts(lines: list[Line], matches: list) -> set[int]:
    """Numbered lines that start a question: only when an answer label follows before the next one."""
    candidates = [i for i, line in enumerate(lines)
                  if not matches[i] and line.joiner == "\n" and (line.numbered or NUMBERED.match(line.text))]
    starts = set()
    for c, nxt in zip(candidates, candidates[1:] + [len(lines)]):
        if any(matches[j] and matches[j][0] == "answer" for j in range(c + 1, nxt)):
            starts.add(c)
    return starts


def segment(paragraphs: list[Paragraph], filename: str, labels: Labels | None = None) -> dict:
    """{'title', 'editor', 'questions': [row dicts], 'skipped': lines that went nowhere}."""
    labels = labels or load_labels()
    lines = to_lines(paragraphs)
    tables = _question_tables(lines, labels)
    in_table = [bool(line.table and line.table[0] in tables) for line in lines]
    matches = [None if in_table[i] else labels.match(line.text) for i, line in enumerate(lines)]
    labelled = any(m and m[0] == "question" for m in matches)
    starts = set() if labelled else _numbered_starts(lines, matches)

    out, header, skipped = _Builder(), [], []
    tour = editor = None
    expect_editor = False
    auto_number = 0
    done_tables: set[int] = set()
    for i, line in enumerate(lines):
        if in_table[i]:
            if line.table[0] not in done_tables:
                done_tables.add(line.table[0])
                _table_rows(lines, line.table[0], tables[line.table[0]], tour, out)
            continue
        m = matches[i]
        if m:
            kind, number, rest = m
            expect_editor = False
            if kind == "question":
                out.start(number, tour)
                out.add(rest)
            elif kind == "tour":
                tour, out.field = number or rest or None, None
            elif kind == "editor":
                editor = rest or editor
                expect_editor = not rest
            elif out.current is None:
                header.append(line)
            else:
                out.field = FIELD_OF[kind]
                out.add(rest)
        elif i in starts:
            numbered = NUMBERED.match(line.text)
            if not numbered:
                auto_number += 1
            out.start(numbered.group(1) if numbered else str(auto_number), tour)
            out.add(numbered.group(2) if numbered else line.text)
        elif expect_editor:
            editor, expect_editor = line.text, False
        elif out.current is None:
            header.append(line)
        elif line.heading or out.field is None:
            out.field = None  # a heading between questions closes the current field
            skipped.append(line.text)
        else:
            out.add(line.text, line.joiner)

    heading = next((h.text for h in header if h.heading), None)
    title = heading or (header[0].text if header else None) or filename
    return {"title": title[:300], "editor": editor, "questions": out.finish(), "skipped": skipped}
