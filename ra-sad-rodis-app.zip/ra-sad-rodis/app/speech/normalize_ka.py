"""Georgian text normalizer: turns digits, Roman numerals, units and abbreviations into words.

Order per sentence (docs/spec-georgian-speech.md §1): pronunciation dictionary → unit symbols →
times → Roman numerals → ordinals → ranges → case suffixes → plain numbers → clean-up.
Every expanded number is wrapped in NUM_START … NUM_END so segments.py can find it;
`normalize()` strips the markers.
"""
import logging
import re
from collections.abc import Iterable
from functools import lru_cache

from app.speech import numbers_ka as nk

log = logging.getLogger(__name__)

NUM_START, NUM_END = "", ""
GEO = "ა-ჰ"
SP = r"[   ]"
# A number token: "15 000" (space thousands) or digits with optional , . groups ("1,500", "3,5")
NUM = rf"(?<![0-9])(?:[0-9]{{1,3}}(?:{SP}[0-9]{{3}})+(?![0-9])|[0-9]+(?:[.,][0-9]+)*)"
DASH = "[–—-]"
SUFFIX = rf"(?:-(?P<suf>[{GEO}]+))?"
COMMA_THOUSANDS = re.compile(r"[1-9][0-9]{0,2}(?:,[0-9]{3})+")  # "0,125" stays a decimal

SEED_DICTIONARY = [
    ("ე.წ.", "ეგრეთ წოდებული"),
    ("ა.შ.", "ასე შემდეგ"),
    ("ძვ. წ.", "ძველი წელთაღრიცხვით"),
    ("ჩვ. წ.", "ჩვენი წელთაღრიცხვით"),
    ("ქ.", "ქალაქი"),  # only before a word, see _key_pattern
    ("№", "ნომერი"),
    ("§", "პარაგრაფი"),
]

UNITS = {
    "%": "პროცენტი", "°C": "გრადუსი ცელსიუსით", "°": "გრადუსი",
    "$": "დოლარი", "€": "ევრო", "₾": "ლარი",
    "კმ": "კილომეტრი", "სმ": "სანტიმეტრი", "მმ": "მილიმეტრი", "კგ": "კილოგრამი",
    "მ": "მეტრი", "ტ": "ტონა", "ლ": "ლიტრი",
}


def _wrap(words: str) -> str:
    return f"{NUM_START}{words}{NUM_END}"


def number_words(token: str) -> str:
    """Words for one NUM token (thousands separators, decimals, leading zeros)."""
    token = re.sub(SP, "", token)
    if COMMA_THOUSANDS.fullmatch(token):
        return nk.integer(token.replace(",", ""))
    parts = re.split(r"[.,]", token)
    if len(parts) == 1:
        return nk.integer(token)
    if len(parts) == 2:
        return nk.decimal(*parts)
    return " ".join(nk.integer(p) for p in parts)  # e.g. a dotted date: each group on its own


def _inflect(words: str, suffix: str | None) -> str:
    return nk.attach_suffix(words, suffix) if suffix else words


_NEXT_WORD = re.compile(rf"{SP}+([{GEO}]+)")


def _before_next(words: str, rest: str) -> str:
    """Attributive rule: look at the next Georgian word after the number."""
    m = _NEXT_WORD.match(rest)
    return nk.attributive(words, m.group(1)) if m else words


# --- 1. pronunciation dictionary -------------------------------------------------------------

def _key_pattern(written: str) -> str:
    out = []
    for i, ch in enumerate(written):
        if ch.isspace():
            if not out or out[-1] != r"\s*":
                out.append(r"\s*")
            continue
        out.append(re.escape(ch))
        if ch == "." and i < len(written) - 1 and not written[i + 1].isspace():
            out.append(r"\s*")  # "ე.წ." also matches "ე. წ."
    pattern = "".join(out)
    if written[0].isalnum():
        pattern = r"(?<!\w)" + pattern
    if written[-1].isalnum():
        pattern += r"(?!\w)"
    if written == "ქ.":
        pattern += rf"(?=\s*[{GEO}])"
    return pattern


@lru_cache(maxsize=16)
def _dictionary_regex(entries: tuple[tuple[str, str], ...]) -> tuple[re.Pattern, list[str]]:
    ordered = sorted(entries, key=lambda e: len(e[0]), reverse=True)  # longest match first
    regex = re.compile("|".join(f"({_key_pattern(w)})" for w, _ in ordered))
    return regex, [s for _, s in ordered]


def merged_dictionary(user: Iterable | None) -> tuple[tuple[str, str], ...]:
    """Seed entries plus the user's (dicts, models or pairs); a user entry overrides a seed key."""
    merged = dict(SEED_DICTIONARY)
    for entry in user or ():
        if isinstance(entry, dict):
            written, spoken = entry["written"], entry["spoken"]
        elif isinstance(entry, tuple):
            written, spoken = entry
        else:
            written, spoken = entry.written, entry.spoken
        if written.strip():
            merged[written.strip()] = spoken
    return tuple(merged.items())


_JOIN = ""  # marks a replacement followed by a hyphenated Georgian suffix (ФИФА-ს → ფიფას)


def apply_dictionary(text: str, entries: tuple[tuple[str, str], ...]) -> str:
    regex, spoken = _dictionary_regex(entries)

    def replace(m: re.Match) -> str:  # a space only where the replacement would glue to a word/number
        left = " " if m.start() and text[m.start() - 1].isalnum() else ""
        if text[m.end():m.end() + 1] == "-" and re.match(f"[{GEO}]", text[m.end() + 1:m.end() + 2]):
            return left + spoken[m.lastindex - 1] + _JOIN
        right = " " if m.end() < len(text) and text[m.end()].isalnum() else ""
        return left + spoken[m.lastindex - 1] + right

    return regex.sub(replace, text).replace(_JOIN + "-", "")


# --- 2. units and symbols --------------------------------------------------------------------

_CURRENCY_FIRST = re.compile(rf"(?P<sym>[$€₾]){SP}?(?P<num>{NUM})")
_UNIT_AFTER = re.compile(
    rf"(?<=[0-9]){SP}?(?P<unit>%|°{SP}?C|°|[$€₾]|კმ|სმ|მმ|კგ|მ|ტ|ლ)(?![{GEO}A-Za-z]){SUFFIX}"
)


def _units(text: str) -> str:
    text = _CURRENCY_FIRST.sub(lambda m: f"{m['num']} {UNITS[m['sym']]}", text)

    def unit(m: re.Match) -> str:
        key = "°C" if m["unit"].startswith("°") and m["unit"].endswith("C") else m["unit"]
        return " " + _inflect(UNITS[key], m["suf"])

    return _UNIT_AFTER.sub(unit, text)


# --- 3. times --------------------------------------------------------------------------------

_TIME = re.compile(rf"(?<![0-9:])(?P<h>[01]?[0-9]|2[0-3]):(?P<m>[0-5][0-9])(?![0-9:]){SUFFIX}")


def _time(m: re.Match) -> str:
    words = f"{nk.cardinal(int(m['h']))} საათი"
    if int(m["m"]):
        words += f" და {nk.cardinal(int(m['m']))} წუთი"
    return _wrap(_inflect(words, m["suf"]))


# --- 4. Roman numerals -----------------------------------------------------------------------

_ROMAN_VALID = re.compile(r"(XC|XL|L?X{0,3})(IX|IV|V?I{0,3})")
_ROMAN_VALUES = {"I": 1, "V": 5, "X": 10, "L": 50}
_CENTURY = re.compile(
    rf"(?<![A-Za-z])(?P<a>[IVXL]+)(?:{SP}*{DASH}{SP}*(?P<b>[IVXL]+))?(?![A-Za-z])"
    rf"(?P<gap>{SP}+)(?P<cent>საუკუნ|სს\.(?![{GEO}])|ს\.(?![{GEO}])){SUFFIX}"
)
_AFTER_WORD = re.compile(rf"(?<=[{GEO}]{SP})(?P<a>[IVXL]+)(?![A-Za-z0-9]){SUFFIX}")


def roman_value(text: str) -> int | None:
    """Value of a Roman numeral made of I V X L; a single letter counts only for I, V, X."""
    if not text or not _ROMAN_VALID.fullmatch(text) or text == "L":
        return None
    total = 0
    for i, ch in enumerate(text):
        value = _ROMAN_VALUES[ch]
        total += -value if i + 1 < len(text) and _ROMAN_VALUES[text[i + 1]] > value else value
    return total


def _century(m: re.Match) -> str:
    a, b = roman_value(m["a"]), roman_value(m["b"]) if m["b"] else None
    if a is None or (m["b"] and b is None):
        return m[0]
    words = nk.ordinal(a) + (f"–{nk.ordinal(b)}" if b else "")
    cent = {"საუკუნ": "საუკუნ", "სს.": "საუკუნეები", "ს.": "საუკუნე"}[m["cent"]]
    return _wrap(words) + m["gap"] + _inflect(cent, m["suf"])


def _roman_after_word(m: re.Match) -> str:
    value = roman_value(m["a"])
    return m[0] if value is None else _wrap(_inflect(nk.ordinal(value), m["suf"]))


# --- 5. ordinals, ranges, case suffixes, plain numbers ---------------------------------------

_ORD_ME = re.compile(rf"(?<![{GEO}])მე-(?P<n>[0-9]+){SUFFIX}")
_ORD_E = re.compile(rf"(?<![0-9])(?P<n>[0-9]+)-ე(?![{GEO}])")
_ORD_FIRST = re.compile(rf"(?<![0-9])1-ლ(?P<i>ი?)(?![{GEO}])")
_RANGE = re.compile(rf"(?P<a>{NUM}){SP}*{DASH}{SP}*(?P<b>{NUM})(?P<year>{SP}+წ\.)?{SUFFIX}")
_CASE = re.compile(rf"(?P<n>{NUM})-(?P<suf>[{GEO}]+)")
_PLAIN = re.compile(rf"(?P<minus>(?:(?<=\s)|^)[-−])?(?P<n>{NUM})(?P<year>{SP}+წ\.)?")


def _ordinal_me(m: re.Match) -> str:
    return _wrap(_inflect(nk.ordinal_words(nk.integer(m["n"])), m["suf"]))


def _ordinal_first(m: re.Match) -> str:
    words = "პირველი" if m["i"] else "პირველ"
    return _wrap(_before_next(words, m.string[m.end():]) if m["i"] else words)


def _with_next(words: str, m: re.Match) -> str:
    """Year abbreviation, hyphenated suffix or the attributive rule for the last number."""
    if m["year"]:
        return nk.truncate(words) + " წელს"
    if m.groupdict().get("suf"):
        return nk.attach_suffix(words, m["suf"])
    return _before_next(words, m.string[m.end():])


def _range(m: re.Match) -> str:
    return _wrap(f"{number_words(m['a'])} – {_with_next(number_words(m['b']), m)}")


def _plain(m: re.Match) -> str:
    words = _with_next(number_words(m["n"]), m)
    return _wrap(("მინუს " if m["minus"] else "") + words)


# --- pipeline ---------------------------------------------------------------------------------

def _cleanup(text: str) -> str:
    text = re.sub(r"\s+", " ", text).strip()
    text = re.sub(r" ([,.;:!?…)\]»“])", r"\1", text)
    text = re.sub(r"([(\[«„]) ", r"\1", text)
    if re.search(r"[0-9]", text):
        log.warning("digits left after normalization: %r", text)
        text = re.sub(r"[0-9]+", lambda m: nk.digits(m[0]), text)
    return text


def normalize_marked(text: str, dictionary: Iterable | None = None) -> str:
    """Normalized text with every expanded number wrapped in NUM_START … NUM_END."""
    text = apply_dictionary(text, merged_dictionary(dictionary))
    text = _units(text)
    text = _TIME.sub(_time, text)
    text = _CENTURY.sub(_century, text)
    text = _AFTER_WORD.sub(_roman_after_word, text)
    text = _ORD_ME.sub(_ordinal_me, text)
    text = _ORD_E.sub(lambda m: _wrap(nk.ordinal_words(nk.integer(m["n"]))), text)
    text = _ORD_FIRST.sub(_ordinal_first, text)
    text = _RANGE.sub(_range, text)
    text = _CASE.sub(lambda m: _wrap(nk.attach_suffix(number_words(m["n"]), m["suf"])), text)
    text = _PLAIN.sub(_plain, text)
    return _cleanup(text)


def strip_markers(text: str) -> str:
    return text.replace(NUM_START, "").replace(NUM_END, "")


def normalize(text: str, dictionary: Iterable | None = None) -> str:
    """Text ready for TTS: no digits, Roman numerals or unit symbols left."""
    return strip_markers(normalize_marked(text, dictionary))
