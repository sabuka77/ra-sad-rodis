"""Audio cache: data/audio/<sha1(provider|voice|rate|text)>.mp3, synthesized lazily on first request.

`register()` (called by /api/tts/prepare) remembers what a key stands for; `get_audio()` serves the
cached file or synthesizes it with a concurrency limit, a timeout and retries.
"""
import asyncio
import hashlib
import logging
import os
import uuid
from dataclasses import dataclass
from pathlib import Path

from app import db
from app.speech.providers import ProviderConfigError, ProviderError, get_provider, rate_string

CONCURRENCY = 3
RETRIES = 2  # extra attempts after the first one
TIMEOUT_S = 20.0
RETRY_DELAY_S = 0.5
FALLBACK_PROVIDER = "edge"  # chosen provider → edge here on the server; the browser voice is the frontend's last resort

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class Job:
    provider: str
    voice: str
    rate_pct: int
    text: str


def cache_key(provider: str, voice: str, rate_pct: int, text: str) -> str:
    return hashlib.sha1(f"{provider}|{voice}|{rate_string(rate_pct)}|{text}".encode("utf-8")).hexdigest()


_jobs: dict[str, Job] = {}  # key → what to synthesize; in memory, filled by prepare
_inflight: dict[str, asyncio.Task] = {}
_semaphore_for: tuple[asyncio.AbstractEventLoop, asyncio.Semaphore] | None = None


def register(job: Job) -> str:
    key = cache_key(job.provider, job.voice, job.rate_pct, job.text)
    _jobs[key] = job
    return key


def audio_dir() -> Path:
    return db.data_dir() / "audio"


def audio_path(key: str) -> Path:
    return audio_dir() / f"{key}.mp3"


def _semaphore() -> asyncio.Semaphore:
    """One semaphore per event loop (tests run several loops in one process)."""
    global _semaphore_for
    loop = asyncio.get_running_loop()
    if _semaphore_for is None or _semaphore_for[0] is not loop:
        _semaphore_for = (loop, asyncio.Semaphore(CONCURRENCY))
    return _semaphore_for[1]


async def synthesize(job: Job) -> bytes:
    """Provider audio with at most CONCURRENCY calls at once, TIMEOUT_S each, RETRIES retries."""
    provider = get_provider(job.provider)
    last: Exception | None = None
    for attempt in range(RETRIES + 1):
        if attempt:
            await asyncio.sleep(RETRY_DELAY_S * attempt)
        try:
            async with _semaphore():
                data = await asyncio.wait_for(provider.synthesize(job.text, job.voice, job.rate_pct), TIMEOUT_S)
            if data:
                return data
            last = ProviderError("empty audio")
        except ProviderConfigError as exc:
            log.warning("TTS %s is not usable: %s", job.provider, exc)
            raise
        except Exception as exc:  # network errors, service changes, timeouts
            last = exc
        log.warning("TTS %s attempt %d failed: %r", job.provider, attempt + 1, last)
    raise ProviderError(f"{job.provider}: {last!r}") from last


async def _produce(job: Job, path: Path) -> Path:
    data = await synthesize(job)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f"{path.stem}.{uuid.uuid4().hex}.part")
    tmp.write_bytes(data)
    os.replace(tmp, path)
    return path


async def _cached_or_produce(key: str, job: Job) -> Path:
    path = audio_path(key)
    if path.exists():
        return path
    task = _inflight.get(key)
    if task is None:
        task = asyncio.ensure_future(_produce(job, path))
        _inflight[key] = task
        task.add_done_callback(lambda _t: _inflight.pop(key, None))
    return await asyncio.shield(task)  # a closed browser tab must not cancel a shared synthesis


async def get_audio(key: str) -> Path | None:
    """Cached file for `key`, synthesizing it first if needed; None when the key is unknown.

    When the chosen provider fails, the same segment is synthesized (or taken from the cache) with edge.
    """
    path = audio_path(key)
    if path.exists():
        return path
    job = _jobs.get(key)
    if job is None:
        return None
    try:
        return await _cached_or_produce(key, job)
    except ProviderError:
        if job.provider == FALLBACK_PROVIDER:
            raise
        fallback = Job(FALLBACK_PROVIDER, job.voice, job.rate_pct, job.text)
        log.warning("TTS %s failed, falling back to %s", job.provider, FALLBACK_PROVIDER)
        return await _cached_or_produce(register(fallback), fallback)


def cache_info() -> dict:
    files = list(audio_dir().glob("*.mp3"))
    return {"files": len(files), "bytes": sum(f.stat().st_size for f in files)}


def clear_cache() -> dict:
    deleted = 0
    for f in audio_dir().glob("*.mp3"):
        try:
            f.unlink()
            deleted += 1
        except OSError:  # a file being served right now (Windows) stays
            pass
    return {"deleted": deleted, **cache_info()}
