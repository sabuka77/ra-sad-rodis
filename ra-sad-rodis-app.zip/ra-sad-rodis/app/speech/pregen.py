"""Pre-generate every audio segment of a package (question text and answer) in the background.

Afterwards the game needs no network: prepare gives the same cache keys and the files are on disk.
One job at a time; progress is kept in memory and read by GET /api/tts/pregenerate.
"""
import asyncio
from dataclasses import asdict, dataclass

from app.speech import cache


@dataclass
class Progress:
    package_id: int | None = None
    total: int = 0
    done: int = 0
    failed: int = 0
    running: bool = False
    cancelled: bool = False


_progress = Progress()
_task: asyncio.Task | None = None


def status() -> dict:
    return asdict(_progress)


def _busy() -> bool:
    # a task from an event loop that is gone (tests) doesn't count
    return _task is not None and not _task.done() and _task.get_loop() is asyncio.get_running_loop()


def start(package_id: int, keys: list[str]) -> dict:
    """Start synthesizing `keys` (already registered in the cache). RuntimeError when a job is running."""
    global _progress, _task
    if _busy():
        raise RuntimeError("busy")
    _progress = Progress(package_id=package_id, total=len(keys), running=bool(keys))
    if keys:
        _task = asyncio.ensure_future(_run(list(reversed(keys)), _progress))  # workers pop() from the end
    return status()


async def _run(keys: list[str], progress: Progress) -> None:
    async def worker() -> None:
        while keys:
            key = keys.pop()
            try:
                if await cache.get_audio(key) is None:
                    progress.failed += 1
            except Exception:  # provider failure after the fallback; counted, the rest go on
                progress.failed += 1
            progress.done += 1

    try:  # a few workers, so cancelling stops new syntheses quickly
        await asyncio.gather(*(worker() for _ in range(cache.CONCURRENCY)))
    finally:
        progress.running = False


def cancel() -> dict:
    if _busy():
        _task.cancel()
        _progress.cancelled = True
        _progress.running = False
    return status()
