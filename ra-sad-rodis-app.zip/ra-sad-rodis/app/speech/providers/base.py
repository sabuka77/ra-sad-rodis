"""Provider interface: every TTS provider turns one text segment into MP3 bytes."""
from typing import Protocol


class ProviderError(Exception):
    """Synthesis failed (network, service change, timeout, empty audio)."""


class ProviderConfigError(ProviderError):
    """The provider can't work as configured (missing or rejected key/region): retrying won't help."""


class TTSProvider(Protocol):
    name: str

    async def synthesize(self, text: str, voice: str, rate_pct: int) -> bytes:
        """MP3 audio for `text`; `rate_pct` is relative to normal speed (-25 → 25 % slower)."""
        ...


def rate_string(rate_pct: int) -> str:
    """-25 → "-25%", 0 → "+0%" (the format edge-tts and SSML prosody expect)."""
    return f"{rate_pct:+d}%"
