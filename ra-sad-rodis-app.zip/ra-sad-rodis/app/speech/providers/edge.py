"""edge-tts provider: Microsoft Edge read-aloud voices (no key, needs internet, unofficial service)."""
import edge_tts

from app.speech.providers.base import rate_string


class EdgeProvider:
    name = "edge"

    async def synthesize(self, text: str, voice: str, rate_pct: int) -> bytes:
        communicate = edge_tts.Communicate(text, voice, rate=rate_string(rate_pct))
        chunks = [chunk["data"] async for chunk in communicate.stream() if chunk["type"] == "audio"]
        return b"".join(chunks)
