"""Server-side TTS providers by name. The browser provider lives in the frontend (player.js)."""
from app.speech.providers.azure import AzureProvider
from app.speech.providers.base import ProviderConfigError, ProviderError, TTSProvider, rate_string
from app.speech.providers.edge import EdgeProvider

PROVIDERS: dict[str, TTSProvider] = {"edge": EdgeProvider(), "azure": AzureProvider()}


def get_provider(name: str) -> TTSProvider:
    return PROVIDERS[name]


__all__ = ["PROVIDERS", "ProviderConfigError", "ProviderError", "TTSProvider", "get_provider", "rate_string"]
