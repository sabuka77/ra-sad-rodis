"""Azure Speech provider: the official REST API with SSML prosody. Key and region come from settings.

The key is sent only in the request header: it never goes into exceptions, log lines or responses.
"""
from xml.sax.saxutils import escape, quoteattr

import httpx

from app import db
from app.speech.providers.base import ProviderConfigError, ProviderError, rate_string

OUTPUT_FORMAT = "audio-24khz-48kbitrate-mono-mp3"
TIMEOUT_S = 20.0


def endpoint(region: str) -> str:
    return f"https://{region}.tts.speech.microsoft.com/cognitiveservices/v1"


def ssml(text: str, voice: str, rate_pct: int) -> str:
    return (f'<speak version="1.0" xml:lang="ka-GE"><voice name={quoteattr(voice)}>'
            f'<prosody rate="{rate_string(rate_pct)}">{escape(text)}</prosody></voice></speak>')


class AzureProvider:
    name = "azure"

    async def synthesize(self, text: str, voice: str, rate_pct: int) -> bytes:
        settings = db.load_settings()
        if not settings.azure_key or not settings.azure_region:
            raise ProviderConfigError("azure: key or region is not set")
        headers = {
            "Ocp-Apim-Subscription-Key": settings.azure_key,
            "Content-Type": "application/ssml+xml",
            "X-Microsoft-OutputFormat": OUTPUT_FORMAT,
            "User-Agent": "ra-sad-rodis",
        }
        try:
            async with httpx.AsyncClient(timeout=TIMEOUT_S) as client:
                res = await client.post(endpoint(settings.azure_region),
                                        content=ssml(text, voice, rate_pct).encode("utf-8"), headers=headers)
        except httpx.HTTPError as exc:
            raise ProviderError(f"azure: {type(exc).__name__}") from None  # no request details in the message
        if res.status_code in (400, 401, 403, 404):  # wrong key, region or voice: retrying won't help
            raise ProviderConfigError(f"azure: HTTP {res.status_code}")
        if res.status_code != 200:
            raise ProviderError(f"azure: HTTP {res.status_code}")
        return res.content
