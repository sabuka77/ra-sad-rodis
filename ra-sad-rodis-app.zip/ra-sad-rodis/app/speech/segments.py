"""Sentence split on the original text (with offsets) and speech segments for TTS.

Each sentence is normalized on its own. With number emphasis on, every expanded number plus the
word after it becomes its own segment with is_number=True. All segments of a sentence carry the
sentence's (start, end) offsets in the original text, so the player highlights the whole sentence.
"""
import re
from collections.abc import Iterable
from dataclasses import asdict, dataclass

from app.speech.normalize_ka import NUM_END, NUM_START, merged_dictionary, normalize_marked, strip_markers

_TERMINATOR = re.compile(r"[.!?…]+[\"'»“)\]]*(?=\s)")
_INITIALS = re.compile(r"(?:[ა-ჰ]\.)+")  # ე.წ., ა.შ., ს., წ., initials like ი.
_OPENERS = "(«„\"'["
_NUMBER_CHUNK = re.compile(rf"{NUM_START}([^{NUM_END}]*){NUM_END}(\s+[^\s{NUM_START}]+|[^\s{NUM_START}]+)?")
_CLAUSE = re.compile(r"(?<=[;:])\s+")


@dataclass
class Segment:
    spoken: str
    start: int  # offsets of the parent sentence in the original text
    end: int
    is_number: bool = False
    pause_after_ms: int = 0

    def to_dict(self) -> dict:
        return asdict(self)


def _abbreviations(dictionary: Iterable | None) -> set[str]:
    """Words ending in a dot that never end a sentence (dictionary keys and a few fixed ones)."""
    words = {"სს.", "ძვ.", "ჩვ."}
    for written, _ in merged_dictionary(dictionary):
        words.update(w for w in written.split() if w.endswith("."))
    return words


def _is_abbreviation(text: str, end: int, abbreviations: set[str]) -> bool:
    """True when the dot ending at `end` belongs to an abbreviation followed by a lowercase word."""
    token = re.search(r"\S+$", text[:end])[0].lstrip(_OPENERS)
    if token not in abbreviations and not _INITIALS.fullmatch(token):
        return False
    following = text[end:].lstrip()[:1]
    return following.islower() or following.isdigit()  # Georgian Mkhedruli letters are lowercase


def split_sentences(text: str, dictionary: Iterable | None = None) -> list[tuple[int, int]]:
    """(start, end) offsets of each sentence in `text`, surrounding whitespace excluded."""
    abbreviations = _abbreviations(dictionary)
    spans, start = [], 0
    for m in _TERMINATOR.finditer(text):
        if m[0] == "." and _is_abbreviation(text, m.end(), abbreviations):
            continue
        spans.append((start, m.end()))
        start = m.end()
    spans.append((start, len(text)))
    result = []
    for a, b in spans:
        chunk = text[a:b]
        if chunk.strip():
            a += len(chunk) - len(chunk.lstrip())
            b -= len(chunk) - len(chunk.rstrip())
            result.append((a, b))
    return result


def _chunks(clause: str, number_emphasis: bool) -> list[tuple[str, bool]]:
    """Split a normalized clause into (text, is_number) chunks; punctuation-only chunks are merged."""
    if not number_emphasis:
        raw = [(clause, False)]
    else:
        raw, pos = [], 0
        for m in _NUMBER_CHUNK.finditer(clause):
            raw += [(clause[pos:m.start()], False), (m[1] + (m[2] or ""), True)]
            pos = m.end()
        raw.append((clause[pos:], False))
    chunks: list[tuple[str, bool]] = []
    for text, is_number in raw:
        text = strip_markers(text).strip()
        if not text:
            continue
        if chunks and not any(c.isalpha() for c in text):
            chunks[-1] = (chunks[-1][0] + text, chunks[-1][1])
        else:
            chunks.append((text, is_number))
    return chunks


def build_segments(
    text: str,
    dictionary: Iterable | None = None,
    number_emphasis: bool = True,
    sentence_pause_ms: int = 600,
    number_pause_ms: int = 250,
) -> list[Segment]:
    """Speech segments for `text`. `;` and `:` end a clause with half the sentence pause."""
    segments: list[Segment] = []
    for start, end in split_sentences(text, dictionary):
        clauses = _CLAUSE.split(normalize_marked(text[start:end], dictionary))
        for c, clause in enumerate(clauses):
            clause_pause = sentence_pause_ms if c == len(clauses) - 1 else sentence_pause_ms // 2
            chunks = _chunks(clause, number_emphasis)
            for i, (spoken, is_number) in enumerate(chunks):
                if is_number and i > 0:
                    segments[-1].pause_after_ms = max(segments[-1].pause_after_ms, number_pause_ms)
                pause = number_pause_ms if is_number else 0
                if i == len(chunks) - 1:
                    pause = max(pause, clause_pause)
                segments.append(Segment(spoken, start, end, is_number, pause))
    if segments:
        segments[-1].pause_after_ms = 0
    return segments


def spoken_text(segments: list[Segment]) -> str:
    return " ".join(s.spoken for s in segments)
