"""Georgian number words: cardinals, decimals, ordinals and the inflection of the last word.

Only the last word of a compound number is ever inflected; every helper below works on the
whole phrase and changes its last word only.
"""

ONES = [
    "ნული", "ერთი", "ორი", "სამი", "ოთხი", "ხუთი", "ექვსი", "შვიდი", "რვა", "ცხრა",
    "ათი", "თერთმეტი", "თორმეტი", "ცამეტი", "თოთხმეტი", "თხუთმეტი", "თექვსმეტი",
    "ჩვიდმეტი", "თვრამეტი", "ცხრამეტი",
]
TWENTIES = ["", "ოც", "ორმოც", "სამოც", "ოთხმოც"]  # vigesimal bases 20, 40, 60, 80
HUNDREDS = ["", "ას", "ორას", "სამას", "ოთხას", "ხუთას", "ექვსას", "შვიდას", "რვაას", "ცხრაას"]
SCALES = ((10**9, "მილიარდ"), (10**6, "მილიონ"), (1000, "ათას"))
MAX_CARDINAL = 10**12 - 1
FRACTION_WORDS = {1: "მეათედი", 2: "მეასედი", 3: "მეათასედი"}
VOWELS = "აეიოუ"


def _below_1000(n: int) -> str:
    if n < 20:
        return ONES[n]
    if n < 100:
        base, rest = TWENTIES[n // 20], n % 20
        return base + "ი" if rest == 0 else base + "და" + ONES[rest]
    prefix, rest = HUNDREDS[n // 100], n % 100
    return prefix + "ი" if rest == 0 else f"{prefix} {_below_1000(rest)}"


_SMALL = [_below_1000(n) for n in range(1000)]  # table makes the 0..1,000,000 sweep fast


def cardinal(n: int) -> str:
    """Full (nominative) cardinal, e.g. 1921 → ათას ცხრაას ოცდაერთი."""
    if n < 1000:
        return _SMALL[n]
    if n > MAX_CARDINAL:
        raise ValueError("number too large")
    for value, word in SCALES:
        if n >= value:
            count, rest = divmod(n, value)
            head = word if count == 1 else f"{cardinal(count)} {word}"
            return head + "ი" if rest == 0 else f"{head} {cardinal(rest)}"
    raise AssertionError  # unreachable


def digits(text: str) -> str:
    """Digit by digit: 007 → ნული ნული შვიდი."""
    return " ".join(ONES[int(c)] for c in text)


def integer(text: str) -> str:
    """An integer written with digits only. Leading zeros and huge numbers are read digit by digit."""
    if len(text) > 1 and text[0] == "0" or int(text) > MAX_CARDINAL:
        return digits(text)
    return cardinal(int(text))


def decimal(int_part: str, frac_part: str) -> str:
    """3,5 → სამი მთელი ხუთი მეათედი. More than 3 fraction digits are read digit by digit."""
    head = f"{integer(int_part)} მთელი"
    if len(frac_part) in FRACTION_WORDS:
        return f"{head} {cardinal(int(frac_part))} {FRACTION_WORDS[len(frac_part)]}"
    return f"{head} {digits(frac_part)}"


def _split_last(words: str) -> tuple[str, str]:
    head, _, last = words.rpartition(" ")
    return (head + " " if head else ""), last


def ordinal_words(words: str) -> str:
    """Ordinal from cardinal words: ერთი → პირველი, ოცდაერთი → ოცდამეერთე, ასი → მეასე."""
    head, last = _split_last(words)
    if last == "ერთი":
        return head + "პირველი"
    before, sep, unit = last.rpartition("და")  # "…და…" compound: მე goes after და
    stem = unit[:-1] if unit[-1] in "ია" else unit
    return head + before + sep + "მე" + stem + "ე"


def ordinal(n: int) -> str:
    return ordinal_words(cardinal(n))


def truncate(words: str) -> str:
    """Attributive form before a dative/adverbial noun: drop a final ი (ა and ე stay)."""
    return words[:-1] if words.endswith("ი") else words


def ergative(words: str) -> str:
    """Attributive form before an ergative noun: ი-final → …მა (ხუთმა); vowel-final stays (რვა კაცმა, მეხუთე)."""
    return words[:-1] + "მა" if words.endswith("ი") else words


def attach_suffix(words: str, suffix: str) -> str:
    """Join a hyphenated case suffix to the last word: 1921-ში → …ოცდაერთში, 8-ის → რვის."""
    head, last = _split_last(words)
    final = last[-1]
    if suffix.startswith("ი"):  # -ის, -ით, -იანი, -იდან …: a vowel-initial suffix drops ი, ა or ე
        joined = (last[:-1] if final in "იაე" else last) + suffix
    elif suffix.startswith("დან"):
        joined = (last[:-1] if final in "იაე" else last) + "ი" + suffix
    elif suffix.startswith("მდე"):
        joined = (last[:-1] + "ა" if final == "ი" else last) + suffix
    elif suffix.startswith("მა") or suffix == "მ":
        joined = last[:-1] + "მა" + suffix[2:] if final == "ი" else last + "მ" + suffix[2:]
    elif suffix.startswith("თან") and final != "ი":
        joined = last + "ს" + suffix  # vowel stems take the dative ს: რვასთან, მეოცესთან
    else:  # -ში, -ზე, -თან, -ს, -ჯერ, -კაციანი …
        joined = truncate(last) + suffix
    return head + joined


def is_dative(word: str) -> bool:
    """Next word in the dative or adverbial case (truncated number before it)."""
    return word.endswith(("ში", "ზე", "თან", "მდე", "ად")) or (word.endswith("ს") and not word.endswith("ის"))


def is_ergative(word: str) -> bool:
    """Next word in the ergative: …მა with a consonant before მ and a vowel in the stem (კაცმა, not ძმა),
    or a vowel stem + მ (ძმამ, ქვეყანამ; the two-letter pronouns ამ / იმ are not nouns)."""
    if word.endswith("მ"):
        return len(word) >= 3 and word[-2] in VOWELS
    stem = word[:-2]
    return word.endswith("მა") and len(stem) > 1 and stem[-1] not in VOWELS and any(v in stem for v in VOWELS)


def attributive(words: str, next_word: str) -> str:
    """Number words in front of `next_word` (Georgian letters only)."""
    if is_dative(next_word):
        return truncate(words)
    if is_ergative(next_word):
        return ergative(words)
    return words
