# რა? სად? როდის? — Georgian quiz host app

You are building a local web app that a quiz host runs on a Windows laptop (often connected to a TV or projector) to run games of the Georgian intellectual quiz **"რა? სად? როდის?"** (What? Where? When?). The app reads Georgian questions aloud **slowly**, speaks **every number clearly as Georgian words**, runs the discussion timer, and reveals answers with sources. Questions come from Word/PDF files imported by a **deterministic parser** (no AI at runtime, ever) or are typed in by hand.

## Hard rules

- **No LLM/AI API calls anywhere in the app.** Import, parsing and speech preparation are plain deterministic code.
- All UI text is Georgian and lives in one file: `app/static/i18n/ka.json`.
- Starts with one double-click: `start.bat` (Windows) / `start.sh`. Python 3.11+ only. No Node, no build step, no Docker.
- Works offline except text-to-speech generation. Audio for a whole package can be pre-generated while online, then played offline.
- Binds to `127.0.0.1:8000` by default.

## Stack (fixed, do not re-evaluate)

- Backend: FastAPI + Uvicorn, SQLite through stdlib `sqlite3` (no ORM), Pydantic models.
- Documents: `python-docx` (.docx), `pymupdf` (PDF text plus the font name of each span), plain .txt.
- Speech: `edge-tts` (Microsoft neural voices `ka-GE-EkaNeural` female and `ka-GE-GiorgiNeural` male) as the default provider behind a small provider interface. Optional Azure Speech (REST via `httpx`, SSML). Browser Web Speech API as the last fallback.
- Frontend: plain HTML + CSS + vanilla JS ES modules served by FastAPI from `app/static/`. No framework, no bundler. Timer sounds come from the Web Audio API (no sound files).
- Tests: pytest.

## Layout

```
app/
  main.py                 FastAPI app, static mount, routers
  db.py                   schema (created on startup, idempotent) + small data helpers
  models.py               Pydantic schemas
  routers/                packages.py questions.py importer.py tts.py settings.py speech.py
  importer/               docx_reader.py pdf_reader.py txt_reader.py legacy_fonts.py
                          cleanup.py segmenter.py labels.json dump.py
  speech/                 numbers_ka.py normalize_ka.py segments.py cache.py
                          providers/ (base.py edge.py azure.py)
  static/                 index.html css/app.css i18n/ka.json
                          js/ app.js api.js play.js timer.js player.js scoreboard.js
                              editor.js importer.js settings.js
data/                     (git-ignored) quiz.db  audio/<sha1>.mp3  uploads/
docs/                     spec-georgian-speech.md  spec-import.md  FORMAT_GUIDE_ka.md
samples/                  sample_package.docx (generated)  real/ (the host's own documents)
scripts/                  make_sample.py
tests/
start.bat  start.sh  requirements.txt  README.md  PROGRESS.md
```

## Data model (SQLite)

```
packages(id, title, source_file, editor, notes, created_at)
questions(id, package_id, position, tour, number_label, text, spoken_override,
          answer, accepted, not_accepted, comment, sources_json, author,
          handout_text, handout_image, played_at, content_hash, created_at, updated_at)
settings(key PRIMARY KEY, value_json)
```

- `sources_json` is a list of `{"text": str, "url": str | null}`.
- `content_hash` = sha1 of the question text lowercased with whitespace and punctuation removed (used for duplicate warnings).

## Features

### 1. Play tab (თამაში), the main screen

- Pick a package. Play in order or shuffled; option to skip questions already played. Shows "N / total".
- Question text is large and readable on a projector (at least 32px, A−/A+ buttons, size remembered). Toggle "show text while reading" (default on). Handout text or image is shown above the question.
- Speech controls: **▶ წაკითხვა** (read), **🔁 თავიდან წაკითხვა** (read again, always restarts from the beginning), ⏸/▶ pause and resume, ⏹ stop, speed slider. The sentence being spoken is highlighted; clicking any sentence re-reads just that sentence.
- Timer: big countdown, default 60 s, presets 60 / 30 / 20 (blitz). Buttons: დაწყება/პაუზა (start/pause), გადატვირთვა (reset), **+10 წმ** and **+30 წმ** (extra time; values configurable). Extra time works while running, while paused, and after reaching 0 (the countdown restarts from the added amount). Short beep at 10 s left, a distinct end signal at 0, colour moves normal → amber (≤10 s) → red (0) with the text "დრო ამოიწურა!". Optional auto-start when reading finishes (setting, default off). Remaining time is computed from `performance.now()`, never by decrementing per tick, so it stays accurate when the tab is in the background.
- The answer stays hidden until the host clicks **პასუხის ჩვენება** (show answer). The answer panel shows: answer, ჩაითვლება (accepted variants), არ ჩაითვლება (not accepted), კომენტარი (comment), **წყარო** (sources) as a numbered list with clickable links opening in a new tab, and ავტორი (author). `[1]`-style markers in the comment link to the matching source. A 🔊 button reads the answer aloud. The panel can be hidden again (პასუხის დამალვა).
- Prev / next, jump to a number. A question is marked played automatically when its answer is revealed.
- Keyboard: Space = timer start/pause, R = read again, S = stop speech, A = show/hide answer, → / ← = next/prev, + = add 10 s, F = fullscreen, ? = shortcut cheat-sheet.
- When a question opens, prepare and preload its audio; prefetch the next question's audio in the background.

### 2. Scoreboard (collapsible panel in the Play tab)

- TV mode: მცოდნეები vs ტელემაყურებლები (names editable), +1/−1, first to 6 shows a winner banner.
- Teams mode: N named teams, tick who answered each question correctly, totals table.
- Persisting the current game in `localStorage` is fine.

### 3. Import tab (იმპორტი)

- Drag and drop or pick .docx / .pdf / .txt files (several at once). Parsing is deterministic and defined in `docs/spec-import.md`.
- Before anything is saved, show a **preview table**: number, question, answer, sources, with per-row warnings (no answer, very short or very long text, possible merge of two questions, duplicate of an existing question, numbering gap). Every field is editable inline; rows can be deleted or merged with the next row.
- Per-file toggle "ძველი ქართული შრიფტი (AcadNusx) → Unicode", auto-detected, the host can override.
- Save into a new package (name prefilled from the document) or append to an existing one.
- Clear Georgian error messages for: scanned PDF without a text layer, .doc files (ask to save as .docx), password-protected PDF, unreadable file.
- JSON export and import of whole packages (backup and sharing).

### 4. Questions tab (კითხვები), manual entry and editing

- Form fields: package (select or create), ტური (tour), number, კითხვა, პასუხი, ჩაითვლება, არ ჩაითვლება, კომენტარი, წყარო (repeatable rows: text + optional URL), ავტორი, დარიგება (handout text), handout image upload, and a collapsed advanced field "წასაკითხი ტექსტი" (spoken-text override: when filled, TTS reads it instead of the question text).
- "მოსმენა" (preview speech) shows the normalized text that will be spoken and plays it.
- შენახვა / შენახვა და ახალი / დუბლირება / წაშლა (delete asks for confirmation). Question and answer are required.
- List with search over question and answer text, filter by package, reorder with ↑/↓, played status with a reset button.

### 5. Settings tab (პარამეტრები)

- Voice: ეკა (female) / გიორგი (male). Base speech rate (default **−25%**, range −50%…0%). Extra slowdown for number segments (default −15%). Pause between sentences (default 600 ms). Pause around numbers (default 250 ms). "Number emphasis" on/off (default on).
- TTS provider: edge (default) / azure (key + region) / browser. "ხმის ტესტი" button reads a sample sentence containing a year, a date, a percentage and an ordinal.
- Pronunciation dictionary: editable table "written → spoken" (abbreviations, foreign names), applied before number expansion.
- Timer default and +time button values; font size; theme (dark default, light).
- "Pre-generate audio for package" with a progress bar (for offline games); cache size display and "clear audio cache".

## Speech pipeline (details in `docs/spec-georgian-speech.md`)

Original text (or spoken override) → split into sentences **on the original text, keeping character offsets** → per sentence: pronunciation dictionary → number / ordinal / Roman-century / unit expansion into Georgian words → number sub-segments marked `is_number` → each segment synthesized (number segments slower) → MP3 cached at `data/audio/<sha1(provider|voice|rate|text)>.mp3` → the frontend plays the segment list with the configured gaps and highlights the original sentence being read.

## Phases

Build in this order. One phase per session.

0. Skeleton: layout, requirements, start scripts, FastAPI serving the Georgian tab shell, SQLite schema, settings API, PROGRESS.md.
1. Questions tab: packages and questions CRUD, JSON export/import.
2. Georgian speech normalizer (numbers, ordinals, centuries, case suffixes, units, dictionary) with exhaustive tests.
3. TTS: provider interface, edge-tts provider, segment cache, endpoints, frontend player, voice settings, speech preview.
4. Play tab: question flow, timer with extra time and signals, answer reveal with sources, shortcuts, fullscreen, prefetch.
5. Import: docx/pdf/txt readers, legacy-font conversion, label-driven segmenter, preview/edit UI, sample package, Georgian format guide, fixture tests.
6. Scoreboard, offline pre-generation, Azure provider and fallback chain, pronunciation dictionary editor.
7. QA and polish: end-to-end walkthrough, bug fixes, README (Georgian + English).

## Working rules for Claude (fixed budget of about $130 for the whole project)

- Do **only the current phase**. At the end: run pytest, update `PROGRESS.md` (done / next / known issues / decisions), and reply with a summary of at most 10 lines. Then stop.
- Be economical with context: use grep and targeted reads; don't re-read files you just wrote; don't print large files into the chat.
- Keep files small (under about 300 lines) and focused. No speculative abstractions, no features outside this spec.
- Never open PDF/DOCX files directly to look at them. Inspect them with the project's own extractor (`python -m app.importer.dump <file>`) and read at most ~150 lines of its output per file.
- Don't add dependencies beyond `requirements.txt` without one line explaining why.
- Run pytest after each meaningful change and fix failures before moving on.
- If the spec is ambiguous, pick the simplest option that satisfies the feature, record it under "decisions" in `PROGRESS.md`, and continue. Only stop to ask when the phase is truly blocked.
- If an expected Georgian value in a spec looks linguistically wrong, never change it silently: mark the test `xfail` with a reason and list it in `PROGRESS.md` for the host to decide.
