"""Creates samples/sample_package.docx: 5 DEMO questions in the canonical import format.

Question 5 is typed in the legacy AcadNusx font (Latin letters) to exercise the conversion.
Run: .venv/Scripts/python.exe scripts/make_sample.py [output.docx]
"""
import sys
from pathlib import Path

from docx import Document

ROOT = Path(__file__).resolve().parent.parent

TO_ACADNUSX = dict(zip("აბგდევზთიკლმნოპჟრსტუფქღყშჩცძწჭხჯჰ", "abgdevzTiklmnopJrstufqRySCcZwWxjh"))

QUESTIONS = [
    {
        "text": ["ლეგენდის თანახმად, მეფე ვახტანგ გორგასალმა აქ ნადირობისას თბილი წყაროები აღმოაჩინა.",
                 "V საუკუნეში მან ამ ადგილას ქალაქი გააშენა. დაასახელეთ ქალაქი."],
        "answer": "თბილისი", "accepted": "ტფილისი",
        "comment": "სადემონსტრაციო კითხვა. ქალაქის სახელი სიტყვა „თბილს“ უკავშირდება [1].",
        "sources": ["https://ka.wikipedia.org/wiki/თბილისი"],
    },
    {
        "text": ["1918 წლის 26 მაისს თბილისში საქართველოს ეროვნულმა საბჭომ ისტორიული აქტი მიიღო.",
                 "რა გამოცხადდა ამ დღეს?"],
        "answer": "საქართველოს დამოუკიდებლობა", "accepted": "დამოუკიდებლობა",
        "not_accepted": "რესპუბლიკა",
        "comment": "სადემონსტრაციო კითხვა. 26 მაისი დღესაც დამოუკიდებლობის დღედ აღინიშნება [1].",
        "sources": ["https://ka.wikipedia.org/wiki/საქართველოს_დამოუკიდებლობის_აქტი",
                    "საქართველოს ისტორია, ტ. IV, გვ. 120"],
    },
    {
        "text": ["ბერძნული მითის მიხედვით, ამ კავკასიურ მწვერვალზე იყო მიჯაჭვული პრომეთე.",
                 "დაასახელეთ მწვერვალი, რომლის სიმაღლე 5000 მეტრს აღემატება."],
        "answer": "მყინვარწვერი", "accepted": "ყაზბეგი; ყაზბეგის მწვერვალი", "not_accepted": "შხარა",
        "comment": "სადემონსტრაციო კითხვა.\nშხარა საქართველოს უმაღლესი მწვერვალია, მაგრამ მითი მყინვარწვერს უკავშირდება [1].",
        "sources": ["https://ka.wikipedia.org/wiki/მყინვარწვერი"],
    },
    {
        "text": ["ეს ქალაქი აჭარის დედაქალაქია და ზღვის სანაპიროზე მდებარეობს. რომელ ზღვაზე?"],
        "answer": "შავი ზღვა", "comment": "სადემონსტრაციო კითხვა: ქალაქი ბათუმია.",
        "sources": ["https://ka.wikipedia.org/wiki/ბათუმი"],
    },
    {  # typed in AcadNusx
        "text": ["რამდენი ასოა თანამედროვე ქართულ ანბანში?"],
        "answer": "33 ასო", "accepted": "ოცდაცამეტი",
        "comment": "სადემონსტრაციო კითხვა, აკრეფილია ძველი ქართული შრიფტით.",
        "sources": ["https://en.wikipedia.org/wiki/Georgian_scripts"],
        "acadnusx": True,
    },
]

LABELS = [("answer", "პასუხი"), ("accepted", "ჩაითვლება"), ("not_accepted", "არ ჩაითვლება"),
          ("comment", "კომენტარი")]


def _para(document, text: str, legacy: bool = False) -> None:
    paragraph = document.add_paragraph()
    if legacy:
        paragraph.add_run("".join(TO_ACADNUSX.get(c, c) for c in text)).font.name = "AcadNusx"
    else:
        paragraph.add_run(text)


def build(path: Path) -> Path:
    document = Document()
    document.add_heading("დემო პაკეტი: სადემონსტრაციო კითხვები", level=0)
    document.add_paragraph("რედაქტორი: დემო რედაქტორი")
    document.add_paragraph("ეს არის სადემონსტრაციო ფაილი იმპორტის შესამოწმებლად. კითხვები ნიმუშია.")
    document.add_paragraph("ტური 1")
    for number, q in enumerate(QUESTIONS, start=1):
        legacy = q.get("acadnusx", False)
        _para(document, f"შეკითხვა {number}.", legacy)
        for line in q["text"]:
            _para(document, line, legacy)
        for key, label in LABELS:
            if key in q:
                first, *more = q[key].split("\n")
                _para(document, f"{label}: {first}", legacy)
                for line in more:
                    _para(document, line, legacy)
        _para(document, "წყარო:", legacy)
        for i, source in enumerate(q["sources"], start=1):
            _para(document, f"{i}. {source}", legacy)
        _para(document, "ავტორი: დემო ავტორი", legacy)
        document.add_paragraph()
    path.parent.mkdir(parents=True, exist_ok=True)
    document.save(path)
    return path


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "samples" / "sample_package.docx"
    print(f"written: {build(target).name}")
